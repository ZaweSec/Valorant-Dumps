// BlueprintGeneratedClass WidgetComponent_InWorldUsable.WidgetComponent_InWorldUsable_C
// Size: 0x6c8 (Inherited: 0x6c0)
struct UWidgetComponent_InWorldUsable_C : UWidgetComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x6c0(0x08)

	void DestroySelf(); // Function WidgetComponent_InWorldUsable.WidgetComponent_InWorldUsable_C.DestroySelf // (BlueprintCallable|BlueprintEvent) // @ game+0x3c7c8e0
	void ExecuteUbergraph_WidgetComponent_InWorldUsable(int32_t EntryPoint); // Function WidgetComponent_InWorldUsable.WidgetComponent_InWorldUsable_C.ExecuteUbergraph_WidgetComponent_InWorldUsable // (Final|UbergraphFunction) // @ game+0x3c7c8e0
};

