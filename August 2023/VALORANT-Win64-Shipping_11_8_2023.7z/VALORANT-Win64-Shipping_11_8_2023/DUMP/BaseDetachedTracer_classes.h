// BlueprintGeneratedClass BaseDetachedTracer.BaseDetachedTracer_C
// Size: 0x668 (Inherited: 0x660)
struct ABaseDetachedTracer_C : AAresDetachedTracer {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x660(0x08)

	void StartEffect(struct AActor* Target, struct UObject* Context, float StartTime, bool FirstPerson); // Function BaseDetachedTracer.BaseDetachedTracer_C.StartEffect // (Event|Public|BlueprintEvent) // @ game+0x3c7c8e0
	void ExecuteUbergraph_BaseDetachedTracer(int32_t EntryPoint); // Function BaseDetachedTracer.BaseDetachedTracer_C.ExecuteUbergraph_BaseDetachedTracer // (Final|UbergraphFunction) // @ game+0x3c7c8e0
};

