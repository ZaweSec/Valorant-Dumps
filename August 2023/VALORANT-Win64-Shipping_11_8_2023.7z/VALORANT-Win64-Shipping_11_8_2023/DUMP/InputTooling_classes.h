// Class InputTooling.AimToolingTracker
// Size: 0xf8 (Inherited: 0xe8)
struct UAimToolingTracker : UActorComponent {
	char pad_E8[0x10]; // 0xe8(0x10)
};

// Class InputTooling.BaseInputToolingComponent
// Size: 0xf0 (Inherited: 0xe8)
struct UBaseInputToolingComponent : UActorComponent {
	struct APlayerController* OwningPC; // 0xe8(0x08)
};

// Class InputTooling.AimToolingComponent
// Size: 0x760 (Inherited: 0xf0)
struct UAimToolingComponent : UBaseInputToolingComponent {
	char pad_F0[0x460]; // 0xf0(0x460)
	struct TArray<bool> FeaturesEnabledValues; // 0x550(0x10)
	struct TArray<float> FeatureConfigValues; // 0x560(0x10)
	struct TArray<struct UCurveFloat*> FeatureConfigCurves; // 0x570(0x10)
	char pad_580[0x10]; // 0x580(0x10)
	struct FAimToolingCachedProjectionData CachedProjectionData; // 0x590(0x120)
	struct FAimToolingDecelerationState DecelerationState; // 0x6b0(0x40)
	bool bAimToolingEnabled; // 0x6f0(0x01)
	char pad_6F1[0x3]; // 0x6f1(0x03)
	float CurrentAimAccelerationDelayScale; // 0x6f4(0x04)
	struct FVector2D GamepadPreviousWalkStickVector; // 0x6f8(0x08)
	struct TArray<struct FAimToolingTarget> Targets; // 0x700(0x10)
	struct FAimToolingTarget PreviousTarget; // 0x710(0x28)
	float PreviousTargetLostTime; // 0x738(0x04)
	float NewTargetAcquiredTime; // 0x73c(0x04)
	char pad_740[0x20]; // 0x740(0x20)

	bool IsFeatureEnabled(enum class EAimToolingFeature Feature, struct UAimToolingTargetComponentBase* TargetComponent); // Function InputTooling.AimToolingComponent.IsFeatureEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x63e8ea0
	bool IsAimToolingEnabled(); // Function InputTooling.AimToolingComponent.IsAimToolingEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x63e8e70
};

// Class InputTooling.AimToolingControllerInterface
// Size: 0x30 (Inherited: 0x30)
struct UAimToolingControllerInterface : UInterface {
};

// Class InputTooling.AimToolingFlashingTargetComponent
// Size: 0x2a0 (Inherited: 0x290)
struct UAimToolingFlashingTargetComponent : USceneComponent {
	bool ShouldAffectAllies; // 0x288(0x01)
	struct AActor* OwningActor; // 0x290(0x08)
	char pad_299[0x7]; // 0x299(0x07)
};

// Class InputTooling.AimToolingTargetComponentBase
// Size: 0x2c0 (Inherited: 0x290)
struct UAimToolingTargetComponentBase : USceneComponent {
	struct TArray<enum class EAimToolingFeature> DisabledFeatures; // 0x288(0x10)
	struct FString TuningOverrideTag; // 0x298(0x10)
	struct FString TuningOverrideTagADS; // 0x2a8(0x10)
	char TargetId; // 0x2b8(0x01)
};

// Class InputTooling.AimToolingPointsTargetComponent
// Size: 0x2f0 (Inherited: 0x2c0)
struct UAimToolingPointsTargetComponent : UAimToolingTargetComponentBase {
	struct FName CenterTargetPointName; // 0x2c0(0x0c)
	char pad_2CC[0x4]; // 0x2cc(0x04)
	struct TArray<struct UActorComponent*> AimToolingTargetPoints; // 0x2d0(0x10)
	struct AActor* OwningActor; // 0x2e0(0x08)
	char pad_2E8[0x8]; // 0x2e8(0x08)
};

// Class InputTooling.AimToolingSkeletalTargetComponent
// Size: 0x300 (Inherited: 0x2c0)
struct UAimToolingSkeletalTargetComponent : UAimToolingTargetComponentBase {
	struct TArray<struct FAimToolingBoneDef> AimToolingBones; // 0x2c0(0x10)
	struct FAimToolingAxis AimToolingAxis; // 0x2d0(0x24)
	char pad_2F4[0xc]; // 0x2f4(0x0c)
};

// Class InputTooling.AimToolingStatics
// Size: 0x30 (Inherited: 0x30)
struct UAimToolingStatics : UBlueprintFunctionLibrary {
};

// Class InputTooling.AimToolingTargetManager
// Size: 0x150 (Inherited: 0xe8)
struct UAimToolingTargetManager : UActorComponent {
	char LastUsedTargetID; // 0xe8(0x01)
	char pad_E9[0x7]; // 0xe9(0x07)
	struct TArray<struct UAimToolingTargetComponentBase*> TrackedTargets; // 0xf0(0x10)
	struct TSet<struct AActor*> FlashingTargets; // 0x100(0x50)
};

// Class InputTooling.AimToolingTargetPoint
// Size: 0x2a0 (Inherited: 0x290)
struct UAimToolingTargetPoint : USceneComponent {
	struct FAimToolingTargetPointDef TargetPoint; // 0x288(0x14)
};

// Class InputTooling.BaseInputToolingControllerInterface
// Size: 0x30 (Inherited: 0x30)
struct UBaseInputToolingControllerInterface : UInterface {
};

// Class InputTooling.MovementToolingComponent
// Size: 0x160 (Inherited: 0xf0)
struct UMovementToolingComponent : UBaseInputToolingComponent {
	struct TArray<bool> FeaturesEnabledValues; // 0xf0(0x10)
	struct TArray<float> FeatureConfigValues; // 0x100(0x10)
	bool bMovementToolingEnabled; // 0x110(0x01)
	char pad_111[0x3]; // 0x111(0x03)
	struct FVector2D FastStrafingPreviousInputVector; // 0x114(0x08)
	float FastStrafeDirection; // 0x11c(0x04)
	bool bInitialFastStrafingActive; // 0x120(0x01)
	char pad_121[0x3f]; // 0x121(0x3f)

	bool IsMovementToolingEnabled(); // Function InputTooling.MovementToolingComponent.IsMovementToolingEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x35f6e00
	bool IsFeatureEnabled(enum class EMovementToolingFeature Feature); // Function InputTooling.MovementToolingComponent.IsFeatureEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x63efa60
};

// Class InputTooling.MovementToolingControllerInterface
// Size: 0x30 (Inherited: 0x30)
struct UMovementToolingControllerInterface : UInterface {
};

// Class InputTooling.MovementToolingStatics
// Size: 0x30 (Inherited: 0x30)
struct UMovementToolingStatics : UBlueprintFunctionLibrary {
};

