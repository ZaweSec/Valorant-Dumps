// BlueprintGeneratedClass TestBranch_HasCharge_StateComponent.TestBranch_HasCharge_StateComponent_C
// Size: 0x310 (Inherited: 0x310)
struct UTestBranch_HasCharge_StateComponent_C : UTestBranch_StateComponent_C {

	bool StateTest(struct UStateTransitionContext* StateTransitionContext); // Function TestBranch_HasCharge_StateComponent.TestBranch_HasCharge_StateComponent_C.StateTest // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x3c7c8e0
};

