// UserDefinedStruct Struct_Ability_Timer_Info.Struct_Ability_Timer_Info
// Size: 0x29 (Inherited: 0x00)
struct FStruct_Ability_Timer_Info {
	float MaxTime_10_94F9EAAA491703DC1D86C19DC0C3F426; // 0x00(0x04)
	float CurrentTime_11_6C1D4F384841BBCE4EDF36A33AF035A2; // 0x04(0x04)
	bool AutomaticallyRemove_12_539907E24E9A176BAFDB82B8EBE1684C; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct FText TimerText_13_D92F6CEE4011B19CFBC5B280429A4F45; // 0x10(0x18)
	bool ShowExpireWarning_17_FBF5ACAF4A665723A2D156BDB7B0B264; // 0x28(0x01)
};

