// WidgetBlueprintGeneratedClass Ping_GunSpotted_MinimapWidget.Ping_GunSpotted_MinimapWidget_C
// Size: 0x3e0 (Inherited: 0x3c0)
struct UPing_GunSpotted_MinimapWidget_C : UMissingMinimapWidget_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3c0(0x08)
	struct UWidgetAnimation* Pulse; // 0x3c8(0x08)
	struct UImage* Icon; // 0x3d0(0x08)
	struct UImage* pulseRing; // 0x3d8(0x08)

	void Construct(); // Function Ping_GunSpotted_MinimapWidget.Ping_GunSpotted_MinimapWidget_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3c7c8e0
	void ExecuteUbergraph_Ping_GunSpotted_MinimapWidget(int32_t EntryPoint); // Function Ping_GunSpotted_MinimapWidget.Ping_GunSpotted_MinimapWidget_C.ExecuteUbergraph_Ping_GunSpotted_MinimapWidget // (Final|UbergraphFunction) // @ game+0x3c7c8e0
};

