// UserDefinedEnum VOEmoteEnum.VOEmoteEnum
enum class VOEmoteEnum : uint8 {
	NewEnumerator17 = 0,
	NewEnumerator2 = 1,
	NewEnumerator4 = 2,
	NewEnumerator5 = 3,
	NewEnumerator8 = 4,
	NewEnumerator9 = 5,
	NewEnumerator15 = 6,
	NewEnumerator16 = 7,
	VOEmoteEnum_MAX = 8
};

