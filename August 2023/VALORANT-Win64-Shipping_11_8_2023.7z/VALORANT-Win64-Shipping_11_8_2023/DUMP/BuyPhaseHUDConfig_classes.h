// BlueprintGeneratedClass BuyPhaseHUDConfig.BuyPhaseHUDConfig_C
// Size: 0xc0 (Inherited: 0xc0)
struct UBuyPhaseHUDConfig_C : UGameStateHUDConfig {
};

