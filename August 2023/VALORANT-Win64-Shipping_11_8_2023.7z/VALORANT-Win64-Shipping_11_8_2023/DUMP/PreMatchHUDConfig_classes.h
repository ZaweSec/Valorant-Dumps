// BlueprintGeneratedClass PreMatchHUDConfig.PreMatchHUDConfig_C
// Size: 0xc0 (Inherited: 0xc0)
struct UPreMatchHUDConfig_C : UGameStateHUDConfig {
};

