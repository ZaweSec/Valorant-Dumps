// UserDefinedStruct GameStateInfo.GameStateInfo
// Size: 0x01 (Inherited: 0x00)
struct FGameStateInfo {
	bool IsBombGameState_1_CC2B1E8841895339CD5B4F96A0130080; // 0x00(0x01)
};

