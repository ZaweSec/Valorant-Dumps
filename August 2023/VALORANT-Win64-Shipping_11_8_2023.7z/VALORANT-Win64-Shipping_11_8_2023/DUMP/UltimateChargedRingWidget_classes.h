// WidgetBlueprintGeneratedClass UltimateChargedRingWidget.UltimateChargedRingWidget_C
// Size: 0x348 (Inherited: 0x348)
struct UUltimateChargedRingWidget_C : UStaticRingNotificationWidget_C {
};

