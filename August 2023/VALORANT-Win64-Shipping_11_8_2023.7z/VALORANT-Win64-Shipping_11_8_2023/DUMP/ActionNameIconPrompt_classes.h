// WidgetBlueprintGeneratedClass ActionNameIconPrompt.ActionNameIconPrompt_C
// Size: 0x5d0 (Inherited: 0x310)
struct UActionNameIconPrompt_C : UInputIconController_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct FName ActionName; // 0x318(0x0c)
	enum class EIconPromptType Button Type; // 0x324(0x01)
	char pad_325[0x3]; // 0x325(0x03)
	struct FTextBlockStyle TextStyle; // 0x328(0x290)
	struct UTextBlock* TextLabel_ref; // 0x5b8(0x08)
	struct UInputChordWidgetBase_C* InputChord_ref; // 0x5c0(0x08)
	struct UCoordinatedHUDElement* KeyboardBtn_ref; // 0x5c8(0x08)

	void SetTextColorAndOpacity(struct FSlateColor ColorOpacity); // Function ActionNameIconPrompt.ActionNameIconPrompt_C.SetTextColorAndOpacity // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c8e0
	void OverrideText(struct FText TextToOverride); // Function ActionNameIconPrompt.ActionNameIconPrompt_C.OverrideText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c8e0
	void UpdateActionName(struct FName NewActionName); // Function ActionNameIconPrompt.ActionNameIconPrompt_C.UpdateActionName // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c8e0
	void Construct(); // Function ActionNameIconPrompt.ActionNameIconPrompt_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3c7c8e0
	void Destruct(); // Function ActionNameIconPrompt.ActionNameIconPrompt_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3c7c8e0
	void OnPresetChanged(enum class EAresIntSettingName SettingName, int32_t OldValue, int32_t NewValue); // Function ActionNameIconPrompt.ActionNameIconPrompt_C.OnPresetChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x3c7c8e0
	void EventOnIconChange(); // Function ActionNameIconPrompt.ActionNameIconPrompt_C.EventOnIconChange // (BlueprintCallable|BlueprintEvent) // @ game+0x3c7c8e0
	void PreConstruct(bool IsDesignTime); // Function ActionNameIconPrompt.ActionNameIconPrompt_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3c7c8e0
	void ExecuteUbergraph_ActionNameIconPrompt(int32_t EntryPoint); // Function ActionNameIconPrompt.ActionNameIconPrompt_C.ExecuteUbergraph_ActionNameIconPrompt // (Final|UbergraphFunction|HasDefaults) // @ game+0x3c7c8e0
};

