// BlueprintGeneratedClass Projectile_BasePistol.Projectile_BasePistol_C
// Size: 0x540 (Inherited: 0x540)
struct AProjectile_BasePistol_C : AProjectile_Gun_C {
};

