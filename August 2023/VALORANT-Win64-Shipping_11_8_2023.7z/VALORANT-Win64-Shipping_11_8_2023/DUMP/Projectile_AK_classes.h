// BlueprintGeneratedClass Projectile_AK.Projectile_AK_C
// Size: 0x540 (Inherited: 0x540)
struct AProjectile_AK_C : AProjectile_Gun_C {
};

