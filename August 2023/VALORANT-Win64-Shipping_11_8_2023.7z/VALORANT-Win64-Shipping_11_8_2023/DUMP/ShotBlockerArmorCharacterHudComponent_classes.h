// BlueprintGeneratedClass ShotBlockerArmorCharacterHudComponent.ShotBlockerArmorCharacterHudComponent_C
// Size: 0x101 (Inherited: 0x100)
struct UShotBlockerArmorCharacterHudComponent_C : UCharacterHudComponent {
	bool BlockerBroken; // 0x100(0x01)

	void GetCharacterHudDrawValues(struct FCharacterHudDrawValues& Out); // Function ShotBlockerArmorCharacterHudComponent.ShotBlockerArmorCharacterHudComponent_C.GetCharacterHudDrawValues // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3c7c8e0
};

