// UserDefinedStruct AbilityTelemetryStasticParameters.AbilityTelemetryStasticParameters
// Size: 0x10 (Inherited: 0x00)
struct FAbilityTelemetryStasticParameters {
	enum class ECharacterAbilityStatisticList Stat_5_F1E5FF2F4629F68A930A11B2E090ACA6; // 0x00(0x01)
	enum class EAresAlliance Alliance_7_50924D9C43164531EADCEFBCF0D0A971; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	float Value_14_E1B35D9646798BBD0F6EEEA2A80A0B80; // 0x04(0x04)
	struct AShooterCharacter* AffectedCharacter_13_6F7CCE1045C668600D7EC6B62F2CB887; // 0x08(0x08)
};

