// BlueprintGeneratedClass Interface_Cooldown.Interface_Cooldown_C
// Size: 0x30 (Inherited: 0x30)
struct UInterface_Cooldown_C : UInterface {

	void CooldownStatus(bool& OnCooldown, float& TimeRemaining); // Function Interface_Cooldown.Interface_Cooldown_C.CooldownStatus // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3c7c8e0
};

