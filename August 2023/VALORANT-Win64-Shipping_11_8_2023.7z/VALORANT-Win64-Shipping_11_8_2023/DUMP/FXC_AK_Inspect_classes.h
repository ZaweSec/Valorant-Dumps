// BlueprintGeneratedClass FXC_AK_Inspect.FXC_AK_Inspect_C
// Size: 0x582 (Inherited: 0x582)
struct AFXC_AK_Inspect_C : AFXC_Gun_Emote_C {
};

