// BlueprintGeneratedClass KillBannerData_Base.KillBannerData_Base_C
// Size: 0xe0 (Inherited: 0xe0)
struct UKillBannerData_Base_C : UKillBannerData_Parent_C {
};

