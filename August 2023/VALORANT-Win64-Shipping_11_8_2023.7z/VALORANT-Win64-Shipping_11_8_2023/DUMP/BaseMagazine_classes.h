// BlueprintGeneratedClass BaseMagazine.BaseMagazine_C
// Size: 0x588 (Inherited: 0x570)
struct ABaseMagazine_C : ABaseEjectable_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x570(0x08)
	struct URotatingMovementComponent* RotatingMovement; // 0x578(0x08)
	bool bDebugBounceVelocity; // 0x580(0x01)
	char pad_581[0x3]; // 0x581(0x03)
	float Rotational Velocity Init Scale; // 0x584(0x04)

	void GetFirstPersonMesh(struct USkeletalMeshComponent*& Mesh); // Function BaseMagazine.BaseMagazine_C.GetFirstPersonMesh // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c8e0
	void GetThirdPersonMesh(struct USkeletalMeshComponent*& Mesh); // Function BaseMagazine.BaseMagazine_C.GetThirdPersonMesh // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c8e0
	void GetFirstPersonCosmeticMesh(struct USkeletalMeshComponent*& Mesh); // Function BaseMagazine.BaseMagazine_C.GetFirstPersonCosmeticMesh // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c8e0
	void GetBulletComponent(struct UBulletComponent_C*& BulletComponent); // Function BaseMagazine.BaseMagazine_C.GetBulletComponent // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c8e0
	void EventSpawned(); // Function BaseMagazine.BaseMagazine_C.EventSpawned // (Event|Public|BlueprintEvent) // @ game+0x3c7c8e0
	void EventApplyRotationalVelocity(struct FRotator& rotRate); // Function BaseMagazine.BaseMagazine_C.EventApplyRotationalVelocity // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x3c7c8e0
	void EventDespawned(); // Function BaseMagazine.BaseMagazine_C.EventDespawned // (Event|Public|BlueprintEvent) // @ game+0x3c7c8e0
	void ReceiveBeginPlay(); // Function BaseMagazine.BaseMagazine_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x3c7c8e0
	void MagazineBounce(struct FHitResult& ImpactResult, struct FVector& ImpactVelocity); // Function BaseMagazine.BaseMagazine_C.MagazineBounce // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c8e0
	void MagazineStop(struct FHitResult& ImpactResult); // Function BaseMagazine.BaseMagazine_C.MagazineStop // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c8e0
	void ExecuteUbergraph_BaseMagazine(int32_t EntryPoint); // Function BaseMagazine.BaseMagazine_C.ExecuteUbergraph_BaseMagazine // (Final|UbergraphFunction|HasDefaults) // @ game+0x3c7c8e0
};

