// BlueprintGeneratedClass FXC_Impact_Melee_Alt.FXC_Impact_Melee_Alt_C
// Size: 0x654 (Inherited: 0x654)
struct AFXC_Impact_Melee_Alt_C : AFXC_Impact_Melee_C {
};

