// BlueprintGeneratedClass TapHoldDropItemsActionTraits.TapHoldDropItemsActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UTapHoldDropItemsActionTraits_C : UActionTraits {
};

