// BlueprintGeneratedClass Comp_GameMode_KillVO.Comp_GameMode_KillVO_C
// Size: 0xf8 (Inherited: 0xe8)
struct UComp_GameMode_KillVO_C : UActorComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xe8(0x08)
	bool Throttle Kill VO; // 0xf0(0x01)
	char pad_F1[0x3]; // 0xf1(0x03)
	int32_t Kill VO Chance; // 0xf4(0x04)

	void OnPlayerKilled(struct AOwnerExclusivePlayerInfo* Killer, struct AOwnerExclusivePlayerInfo* Victim, struct APawn* KilledPawn, struct UDamageResponse* Response, struct TArray<struct FAresAssist>& AssistList, struct UDamageType* DamageType); // Function Comp_GameMode_KillVO.Comp_GameMode_KillVO_C.OnPlayerKilled // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c8e0
	void ReceiveBeginPlay(); // Function Comp_GameMode_KillVO.Comp_GameMode_KillVO_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x3c7c8e0
	void ExecuteUbergraph_Comp_GameMode_KillVO(int32_t EntryPoint); // Function Comp_GameMode_KillVO.Comp_GameMode_KillVO_C.ExecuteUbergraph_Comp_GameMode_KillVO // (Final|UbergraphFunction) // @ game+0x3c7c8e0
};

