// BlueprintGeneratedClass DmgType_RifleBase.DmgType_RifleBase_C
// Size: 0x170 (Inherited: 0x170)
struct UDmgType_RifleBase_C : UDmgType_GunBase_C {
};

