// BlueprintGeneratedClass ObserverKeybindMinimapComponent.ObserverKeybindMinimapComponent_C
// Size: 0x548 (Inherited: 0x540)
struct UObserverKeybindMinimapComponent_C : UShooterCharacterMinimapComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x540(0x08)

	bool IsVisibleOverride(bool bSuperIsVisible); // Function ObserverKeybindMinimapComponent.ObserverKeybindMinimapComponent_C.IsVisibleOverride // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3c7c8e0
	void UpdateWidget(struct UUserWidget* Widget, bool bForce); // Function ObserverKeybindMinimapComponent.ObserverKeybindMinimapComponent_C.UpdateWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c8e0
	void ExecuteUbergraph_ObserverKeybindMinimapComponent(int32_t EntryPoint); // Function ObserverKeybindMinimapComponent.ObserverKeybindMinimapComponent_C.ExecuteUbergraph_ObserverKeybindMinimapComponent // (Final|UbergraphFunction) // @ game+0x3c7c8e0
};

