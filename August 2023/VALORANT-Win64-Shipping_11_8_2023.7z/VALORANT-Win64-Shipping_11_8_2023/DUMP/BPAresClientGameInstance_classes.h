// BlueprintGeneratedClass BPAresClientGameInstance.BPAresClientGameInstance_C
// Size: 0x800 (Inherited: 0x800)
struct UBPAresClientGameInstance_C : UAresClientGameInstance {
};

