// BlueprintGeneratedClass TimeoutYesOption.TimeoutYesOption_C
// Size: 0x168 (Inherited: 0x160)
struct UTimeoutYesOption_C : UGameplayVoteOptionBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x160(0x08)

	void OnSelected(); // Function TimeoutYesOption.TimeoutYesOption_C.OnSelected // (Event|Public|BlueprintEvent) // @ game+0x3c7c8e0
	void ExecuteUbergraph_TimeoutYesOption(int32_t EntryPoint); // Function TimeoutYesOption.TimeoutYesOption_C.ExecuteUbergraph_TimeoutYesOption // (Final|UbergraphFunction|HasDefaults) // @ game+0x3c7c8e0
};

