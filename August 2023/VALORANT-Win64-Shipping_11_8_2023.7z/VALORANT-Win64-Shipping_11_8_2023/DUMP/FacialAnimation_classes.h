// Class FacialAnimation.AudioCurveSourceComponent
// Size: 0x950 (Inherited: 0x910)
struct UAudioCurveSourceComponent : UAudioComponent {
	char pad_910[0x8]; // 0x910(0x08)
	struct FName CurveSourceBindingName; // 0x918(0x0c)
	float CurveSyncOffset; // 0x924(0x04)
	char pad_928[0x28]; // 0x928(0x28)
};

