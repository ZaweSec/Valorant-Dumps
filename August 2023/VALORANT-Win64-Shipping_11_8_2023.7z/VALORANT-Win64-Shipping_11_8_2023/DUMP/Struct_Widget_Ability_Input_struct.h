// UserDefinedStruct Struct_Widget_Ability_Input.Struct_Widget_Ability_Input
// Size: 0x38 (Inherited: 0x00)
struct FStruct_Widget_Ability_Input {
	enum class Enum_AbilityInputs MounseInput_2_88A0D62A4694903C7842EBB3A9E63237; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FName BindingName_21_5FDFA94A44D999FD54DF0E8583A3D472; // 0x04(0x0c)
	struct UTexture2D* InputImage_8_8BF21A634BDA5BE54D8999AF5C2425C1; // 0x10(0x08)
	struct FLinearColor InputColor_15_8EBFC16C4DBCCC83C733C6B336DFEB4F; // 0x18(0x10)
	struct FLinearColor ImageColor_16_6F9B48764FEFC256F724ED90C5D24EE8; // 0x28(0x10)
};

