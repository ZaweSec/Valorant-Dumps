// BlueprintGeneratedClass AnimInterruptFrame.AnimInterruptFrame_C
// Size: 0x40 (Inherited: 0x40)
struct UAnimInterruptFrame_C : UAnimNotify {

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimInterruptFrame.AnimInterruptFrame_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3c7c8e0
};

