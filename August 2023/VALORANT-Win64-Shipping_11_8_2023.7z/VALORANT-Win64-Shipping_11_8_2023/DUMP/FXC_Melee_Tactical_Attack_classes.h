// BlueprintGeneratedClass FXC_Melee_Tactical_Attack.FXC_Melee_Tactical_Attack_C
// Size: 0x580 (Inherited: 0x560)
struct AFXC_Melee_Tactical_Attack_C : AFXC_Melee_Parent_C {
	struct UMeleeEffectComponent_C* MeleeEffectComponent; // 0x560(0x08)
	struct UPlayerMelee_Particle_Component_C* PlayerMelee_Particle_Component; // 0x568(0x08)
	struct UComp_FXC_AudioBasic_C* Comp_FXC_AudioBasic; // 0x570(0x08)
	struct UComp_FXC_PlayAnimation_ShooterCharacter_C* Core_Melee_S0_Attack1_Animation; // 0x578(0x08)
};

