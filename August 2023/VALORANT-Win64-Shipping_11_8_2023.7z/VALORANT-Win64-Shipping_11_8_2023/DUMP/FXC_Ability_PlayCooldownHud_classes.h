// BlueprintGeneratedClass FXC_Ability_PlayCooldownHud.FXC_Ability_PlayCooldownHud_C
// Size: 0x550 (Inherited: 0x540)
struct AFXC_Ability_PlayCooldownHud_C : AEffectContainer {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x540(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x548(0x08)

	void StartEffect(struct AActor* Target, struct UObject* Context, float StartTime, bool FirstPerson); // Function FXC_Ability_PlayCooldownHud.FXC_Ability_PlayCooldownHud_C.StartEffect // (Event|Public|BlueprintEvent) // @ game+0x3c7c8e0
	void ExecuteUbergraph_FXC_Ability_PlayCooldownHud(int32_t EntryPoint); // Function FXC_Ability_PlayCooldownHud.FXC_Ability_PlayCooldownHud_C.ExecuteUbergraph_FXC_Ability_PlayCooldownHud // (Final|UbergraphFunction|HasDefaults) // @ game+0x3c7c8e0
};

