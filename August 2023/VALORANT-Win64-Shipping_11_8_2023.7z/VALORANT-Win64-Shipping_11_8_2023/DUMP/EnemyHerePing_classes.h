// BlueprintGeneratedClass EnemyHerePing.EnemyHerePing_C
// Size: 0x6d0 (Inherited: 0x6d0)
struct AEnemyHerePing_C : ABasePing_C {
};

