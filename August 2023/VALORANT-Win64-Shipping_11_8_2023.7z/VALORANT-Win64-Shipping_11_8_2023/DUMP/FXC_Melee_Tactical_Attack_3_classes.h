// BlueprintGeneratedClass FXC_Melee_Tactical_Attack_3.FXC_Melee_Tactical_Attack_2_C
// Size: 0x580 (Inherited: 0x580)
struct AFXC_Melee_Tactical_Attack_2_C : AFXC_Melee_Tactical_Attack_C {
};

