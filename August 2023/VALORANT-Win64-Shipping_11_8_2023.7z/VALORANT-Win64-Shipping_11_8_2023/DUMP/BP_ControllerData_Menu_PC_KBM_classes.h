// BlueprintGeneratedClass BP_ControllerData_Menu_PC_KBM.BP_ControllerData_Menu_PC_KBM_C
// Size: 0xc0 (Inherited: 0xc0)
struct UBP_ControllerData_Menu_PC_KBM_C : UCommonInputBaseControllerData {
};

