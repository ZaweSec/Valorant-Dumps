// UserDefinedEnum BubbleDownVOEnum.BubbleDownVOEnum
enum class BubbleDownVOEnum : uint8 {
	NewEnumerator11 = 0,
	NewEnumerator0 = 1,
	NewEnumerator7 = 2,
	BubbleDownVOEnum_MAX = 3
};

