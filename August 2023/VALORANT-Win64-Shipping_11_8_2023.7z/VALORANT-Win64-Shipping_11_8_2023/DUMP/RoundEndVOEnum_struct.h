// UserDefinedEnum RoundEndVOEnum.RoundEndVOEnum
enum class RoundEndVOEnum : uint8 {
	NewEnumerator16 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	NewEnumerator9 = 4,
	NewEnumerator10 = 5,
	NewEnumerator12 = 6,
	NewEnumerator13 = 7,
	NewEnumerator14 = 8,
	NewEnumerator15 = 9,
	NewEnumerator17 = 10,
	RoundEndVOEnum_MAX = 11
};

