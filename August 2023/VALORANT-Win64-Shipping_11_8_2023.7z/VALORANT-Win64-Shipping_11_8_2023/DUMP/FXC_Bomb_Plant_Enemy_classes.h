// BlueprintGeneratedClass FXC_Bomb_Plant_Enemy.FXC_Bomb_Plant_Enemy_C
// Size: 0x550 (Inherited: 0x540)
struct AFXC_Bomb_Plant_Enemy_C : AEffectContainer {
	struct UComp_FXC_Audio_Team_C* Comp_FXC_Audio_Enemy; // 0x540(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x548(0x08)
};

