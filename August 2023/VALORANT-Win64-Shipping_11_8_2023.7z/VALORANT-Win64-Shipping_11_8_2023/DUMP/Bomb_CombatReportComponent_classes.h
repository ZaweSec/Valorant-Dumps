// BlueprintGeneratedClass Bomb_CombatReportComponent.Bomb_CombatReportComponent_C
// Size: 0x180 (Inherited: 0x180)
struct UBomb_CombatReportComponent_C : UCombatReportComponent {

	bool DamageIsVisionDeferrable(struct AActor* DamageCauser); // Function Bomb_CombatReportComponent.Bomb_CombatReportComponent_C.DamageIsVisionDeferrable // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c8e0
};

