// BlueprintGeneratedClass ObserverFollowNextActionTraits.ObserverFollowNextActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UObserverFollowNextActionTraits_C : UActionTraits {
};

