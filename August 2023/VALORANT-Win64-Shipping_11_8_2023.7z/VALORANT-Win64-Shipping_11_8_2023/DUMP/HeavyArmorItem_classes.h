// BlueprintGeneratedClass HeavyArmorItem.HeavyArmorItem_C
// Size: 0x461 (Inherited: 0x461)
struct AHeavyArmorItem_C : ABasicArmorItem_C {
};

