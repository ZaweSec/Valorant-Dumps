// WidgetBlueprintGeneratedClass PlantedBombMinimapWidget.PlantedBombMinimapWidget_C
// Size: 0x3a1 (Inherited: 0x3a1)
struct UPlantedBombMinimapWidget_C : UAresMinimapWidget_C {
};

