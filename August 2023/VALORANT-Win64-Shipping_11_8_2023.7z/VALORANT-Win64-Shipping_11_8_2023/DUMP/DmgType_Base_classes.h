// BlueprintGeneratedClass DmgType_Base.DmgType_Base_C
// Size: 0x167 (Inherited: 0x148)
struct UDmgType_Base_C : UShooterDamageType {
	bool ShouldPlayVO_Pain; // 0x148(0x01)
	bool ShowDamageDirection; // 0x149(0x01)
	bool ShowNormalDamageIndicators; // 0x14a(0x01)
	char pad_14B[0x5]; // 0x14b(0x05)
	struct TArray<enum class DirectionEnum> CustomDirectionalDamageBlurs; // 0x150(0x10)
	enum class DirectionEnum CustomHUD_ShakeDirection; // 0x160(0x01)
	bool ShowCustomShake; // 0x161(0x01)
	bool bReportDamageDone; // 0x162(0x01)
	bool bReportKills; // 0x163(0x01)
	enum class EAresItemSlot EquippableSlot; // 0x164(0x01)
	bool bKillGivesUltPoint; // 0x165(0x01)
	bool PreventsHealing; // 0x166(0x01)

	bool ShouldReportDamage(struct UObject* Instigator, struct UDamageResponse* Response); // Function DmgType_Base.DmgType_Base_C.ShouldReportDamage // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3c7c8e0
	struct UCharacterAbilityStatisticsComponent_C* GetGameStatisticsComponent(struct UDamageResponse* Response, int32_t& CastIndex); // Function DmgType_Base.DmgType_Base_C.GetGameStatisticsComponent // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3c7c8e0
	void RespondToDamage(struct UDamageResponse* DamageResponse); // Function DmgType_Base.DmgType_Base_C.RespondToDamage // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3c7c8e0
};

