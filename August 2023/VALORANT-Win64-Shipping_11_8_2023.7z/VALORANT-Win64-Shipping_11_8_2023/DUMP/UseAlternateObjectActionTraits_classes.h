// BlueprintGeneratedClass UseAlternateObjectActionTraits.UseAlternateObjectActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UUseAlternateObjectActionTraits_C : UActionTraits {
};

