// BlueprintGeneratedClass SideSwitchHUDConfig.SideSwitchHUDConfig_C
// Size: 0xc0 (Inherited: 0xc0)
struct USideSwitchHUDConfig_C : UGameStateHUDConfig {
};

