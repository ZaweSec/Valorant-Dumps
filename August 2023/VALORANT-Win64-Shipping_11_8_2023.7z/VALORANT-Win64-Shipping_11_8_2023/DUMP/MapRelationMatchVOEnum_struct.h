// UserDefinedEnum MapRelationMatchVOEnum.MapRelationMatchVOEnum
enum class MapRelationMatchVOEnum : uint8 {
	NewEnumerator5 = 0,
	NewEnumerator0 = 1,
	NewEnumerator6 = 2,
	MapRelationMatchVOEnum_MAX = 3
};

