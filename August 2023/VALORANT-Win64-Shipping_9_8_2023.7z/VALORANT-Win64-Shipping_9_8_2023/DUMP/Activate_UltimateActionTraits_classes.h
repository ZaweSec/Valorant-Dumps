// BlueprintGeneratedClass Activate_UltimateActionTraits.Activate_UltimateActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UActivate_UltimateActionTraits_C : UActionTraits {
};

