// BlueprintGeneratedClass DisconnectedBuff.DisconnectedBuff_C
// Size: 0x990 (Inherited: 0x990)
struct UDisconnectedBuff_C : UAresGameplayBuff {
};

