// BlueprintGeneratedClass FXC_AK_WhileEquipped_1P_Smoke.FXC_AK_WhileEquipped_1P_Smoke_C
// Size: 0x5a6 (Inherited: 0x5a6)
struct AFXC_AK_WhileEquipped_1P_Smoke_C : AFXC_Gun_WhileEquipped_1P_Base_C {
};

