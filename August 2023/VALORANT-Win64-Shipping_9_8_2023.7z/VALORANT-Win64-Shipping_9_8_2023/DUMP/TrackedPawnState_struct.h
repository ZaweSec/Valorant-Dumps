// UserDefinedStruct TrackedPawnState.TrackedPawnState
// Size: 0x20 (Inherited: 0x00)
struct FTrackedPawnState {
	struct FVector Position_2_256D447145E52E680EF57389877245A6; // 0x00(0x0c)
	struct FRotator Rotation_5_7754B83044BEA03BA49E2EBB72254DD8; // 0x0c(0x0c)
	float Health_8_E8AA7F164E929784233087BAE7B3C04B; // 0x18(0x04)
	float TimeStamp_11_3B6112BF460F0F32E415CB9708065D76; // 0x1c(0x04)
};

