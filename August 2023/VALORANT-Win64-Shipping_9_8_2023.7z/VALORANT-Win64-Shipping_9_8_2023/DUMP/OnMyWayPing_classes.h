// BlueprintGeneratedClass OnMyWayPing.OnMyWayPing_C
// Size: 0x6d0 (Inherited: 0x6d0)
struct AOnMyWayPing_C : ABasePing_C {

	void RemoveOtherPingsOfType(); // Function OnMyWayPing.OnMyWayPing_C.RemoveOtherPingsOfType // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3c7d030
};

