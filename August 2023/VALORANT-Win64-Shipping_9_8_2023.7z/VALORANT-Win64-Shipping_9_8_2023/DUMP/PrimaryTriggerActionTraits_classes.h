// BlueprintGeneratedClass PrimaryTriggerActionTraits.PrimaryTriggerActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UPrimaryTriggerActionTraits_C : UActionTraits {
};

