// BlueprintGeneratedClass CommMenuOption8ActionTraits.CommMenuOption8ActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UCommMenuOption8ActionTraits_C : UActionTraits {
};

