// BlueprintGeneratedClass Buff_Global_Concuss_Ramping_Prototype.Buff_Global_Concuss_Ramping_Prototype_C
// Size: 0x990 (Inherited: 0x990)
struct UBuff_Global_Concuss_Ramping_Prototype_C : UAresGameplayBuff {
};

