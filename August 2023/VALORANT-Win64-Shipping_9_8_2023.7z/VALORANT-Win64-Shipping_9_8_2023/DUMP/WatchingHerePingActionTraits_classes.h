// BlueprintGeneratedClass WatchingHerePingActionTraits.WatchingHerePingActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UWatchingHerePingActionTraits_C : UActionTraits {
};

