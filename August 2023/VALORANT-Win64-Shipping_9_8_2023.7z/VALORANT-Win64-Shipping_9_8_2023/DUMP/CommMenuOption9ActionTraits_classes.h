// BlueprintGeneratedClass CommMenuOption9ActionTraits.CommMenuOption9ActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UCommMenuOption9ActionTraits_C : UActionTraits {
};

