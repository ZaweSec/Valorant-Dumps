// UserDefinedEnum Enum_AttenuationVisualization.Enum_AttenuationVisualization
enum class Enum_AttenuationVisualization : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	Enum_MAX = 3
};

