// UserDefinedEnum GunEjectableType.GunEjectableType
enum class GunEjectableType : uint8 {
	NewEnumerator1 = 0,
	NewEnumerator2 = 1,
	GunEjectableType_MAX = 2
};

