// UserDefinedStruct MatchResultRoundPenaltyEvent.MatchResultRoundPenaltyEvent
// Size: 0x18 (Inherited: 0x00)
struct FMatchResultRoundPenaltyEvent {
	int32_t RoundNum_23_C23A08A8434C2B9B7312D6B95D362861; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString Subject_35_B672429647AE143BDBDA498327D8E3A0; // 0x08(0x10)
};

