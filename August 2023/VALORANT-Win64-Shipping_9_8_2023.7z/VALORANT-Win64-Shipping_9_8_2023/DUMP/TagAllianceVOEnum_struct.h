// UserDefinedEnum TagAllianceVOEnum.TagAllianceVOEnum
enum class TagAllianceVOEnum : uint8 {
	NewEnumerator8 = 0,
	NewEnumerator5 = 1,
	NewEnumerator6 = 2,
	TagAllianceVOEnum_MAX = 3
};

