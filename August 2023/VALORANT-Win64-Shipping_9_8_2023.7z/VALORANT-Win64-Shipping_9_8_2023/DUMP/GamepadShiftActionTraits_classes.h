// BlueprintGeneratedClass GamepadShiftActionTraits.GamepadShiftActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UGamepadShiftActionTraits_C : UActionTraits {
};

