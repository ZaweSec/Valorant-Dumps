// BlueprintGeneratedClass BombSpawnLocation.BombSpawnLocation_C
// Size: 0x40c (Inherited: 0x408)
struct ABombSpawnLocation_C : AGameObject {
	int32_t RotatingSpawnLoc; // 0x408(0x04)
};

