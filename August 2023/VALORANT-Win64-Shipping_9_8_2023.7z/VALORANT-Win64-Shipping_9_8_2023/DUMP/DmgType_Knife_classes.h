// BlueprintGeneratedClass DmgType_Knife.DmgType_Knife_C
// Size: 0x167 (Inherited: 0x167)
struct UDmgType_Knife_C : UDmgType_Base_C {

	void PlayHitConfirmSound(struct AShooterCharacter* FirstPersonShooterCharacter, struct AShooterCharacter* ShooterCharacterInstigator, struct AActor* HitActor, enum class EAresHitConfirmLocality HitLocality, enum class EAresRegionalDamage RegionalDamage, bool bLocalPlayerCanSeeVictim, float FalloffMultiplier, struct UDamageResponse* DamageResponse, bool bDied); // Function DmgType_Knife.DmgType_Knife_C.PlayHitConfirmSound // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3c7d030
};

