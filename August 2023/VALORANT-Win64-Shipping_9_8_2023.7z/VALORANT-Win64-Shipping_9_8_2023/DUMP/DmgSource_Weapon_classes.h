// BlueprintGeneratedClass DmgSource_Weapon.DmgSource_Weapon_C
// Size: 0x3d8 (Inherited: 0x3d0)
struct ADmgSource_Weapon_C : ADamageSource {
	struct USceneComponent* DefaultSceneRoot; // 0x3d0(0x08)
};

