// UserDefinedStruct AresMinimapSlotConfig.AresMinimapSlotConfig
// Size: 0x29 (Inherited: 0x00)
struct FAresMinimapSlotConfig {
	enum class EAresMinimapLayer MinimapLayer_3_0C95BDB449D354C3692AE186A3FC6787; // 0x00(0x01)
	enum class EAresMinimapPositionSpace MinimapPositionSpace_6_E2EBA3684EFB7E62A44DBBB431ED35AA; // 0x01(0x01)
	enum class EAresMinimapRotationSpace MinimapRotationSpace_9_D9E1E2514E74012B5A4ED29DF4C9DF9E; // 0x02(0x01)
	enum class EAresMinimapSizeSpace MinimapSizeSpace_12_FB64695F412FD04445E3C7BC033F69FB; // 0x03(0x01)
	struct FVector MinimapPosition_15_8D756A244D07B61E4BD101914BF44966; // 0x04(0x0c)
	float MinimapRotation_26_DA3B1C84434750D549593FBE004648C8; // 0x10(0x04)
	struct FVector MinimapSize_17_0DBDAAD3431CB22959A8659818FFD829; // 0x14(0x0c)
	struct FVector2D Alignment_20_66FB95794581B6B514B5258655CFD34E; // 0x20(0x08)
	bool DrawOffMap_23_F893772B4CBB85C3D3160B951B703D85; // 0x28(0x01)
};

