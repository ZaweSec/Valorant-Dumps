// BlueprintGeneratedClass SniperTracerTrailLever_3P.SniperTracerTrailLever_3P_C
// Size: 0x648 (Inherited: 0x640)
struct ASniperTracerTrailLever_3P_C : AAresContrailTracer {
	struct UAudioComponent* Audio; // 0x640(0x08)
};

