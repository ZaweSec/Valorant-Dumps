// UserDefinedEnum KillsVOEnum.KillsVOEnum
enum class KillsVOEnum : uint8 {
	NewEnumerator16 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	NewEnumerator9 = 4,
	NewEnumerator10 = 5,
	NewEnumerator11 = 6,
	NewEnumerator12 = 7,
	NewEnumerator13 = 8,
	NewEnumerator17 = 9,
	NewEnumerator18 = 10,
	NewEnumerator19 = 11,
	NewEnumerator20 = 12,
	NewEnumerator21 = 13,
	NewEnumerator22 = 14,
	KillsVOEnum_MAX = 15
};

