// BlueprintGeneratedClass BaseDeathReactions.BaseDeathReactions_C
// Size: 0x48 (Inherited: 0x48)
struct UBaseDeathReactions_C : UAresHitReactions {
};

