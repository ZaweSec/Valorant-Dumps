// BlueprintGeneratedClass KeyNameOverrides.KeyNameOverrides_C
// Size: 0x80 (Inherited: 0x30)
struct UKeyNameOverrides_C : UObject {
	struct TMap<struct FKey, struct FText> Mapping; // 0x30(0x50)
};

