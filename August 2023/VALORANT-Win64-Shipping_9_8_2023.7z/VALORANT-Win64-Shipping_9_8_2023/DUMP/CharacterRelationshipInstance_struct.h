// UserDefinedStruct CharacterRelationshipInstance.CharacterRelationshipInstance
// Size: 0x50 (Inherited: 0x00)
struct FCharacterRelationshipInstance {
	struct TMap<enum class CharacterID, struct UAkAudioEvent*> RelatedCharacters_31_62A290044E042E5DB253F39990A7375E; // 0x00(0x50)
};

