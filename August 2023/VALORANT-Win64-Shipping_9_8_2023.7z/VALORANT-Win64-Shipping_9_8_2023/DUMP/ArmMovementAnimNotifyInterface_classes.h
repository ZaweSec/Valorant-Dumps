// BlueprintGeneratedClass ArmMovementAnimNotifyInterface.ArmMovementAnimNotifyInterface_C
// Size: 0x30 (Inherited: 0x30)
struct UArmMovementAnimNotifyInterface_C : UInterface {

	void OnArmMovementAnimNotify(struct UAnimSequenceBase* AnimSequence, struct USkeletalMeshComponent* SkelMeshComp, enum class ArmMovementType MovementType); // Function ArmMovementAnimNotifyInterface.ArmMovementAnimNotifyInterface_C.OnArmMovementAnimNotify // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3c7d030
};

