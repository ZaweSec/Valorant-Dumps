// UserDefinedEnum GunEmote.GunEmote
enum class GunEmote : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	GunEmote_MAX = 2
};

