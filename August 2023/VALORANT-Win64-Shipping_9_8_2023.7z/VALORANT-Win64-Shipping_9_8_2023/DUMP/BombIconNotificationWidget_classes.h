// WidgetBlueprintGeneratedClass BombIconNotificationWidget.BombIconNotificationWidget_C
// Size: 0x338 (Inherited: 0x320)
struct UBombIconNotificationWidget_C : UBaseBombNotificationWidget_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x320(0x08)
	struct UImage* BombIcon; // 0x328(0x08)
	struct UTexture2D* IconTexture; // 0x330(0x08)

	void PreConstruct(bool IsDesignTime); // Function BombIconNotificationWidget.BombIconNotificationWidget_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3c7d030
	void ExecuteUbergraph_BombIconNotificationWidget(int32_t EntryPoint); // Function BombIconNotificationWidget.BombIconNotificationWidget_C.ExecuteUbergraph_BombIconNotificationWidget // (Final|UbergraphFunction) // @ game+0x3c7d030
};

