// BlueprintGeneratedClass Buff_TimeoutFreeze.Buff_TimeoutFreeze_C
// Size: 0x990 (Inherited: 0x990)
struct UBuff_TimeoutFreeze_C : UAresGameplayBuff {
};

