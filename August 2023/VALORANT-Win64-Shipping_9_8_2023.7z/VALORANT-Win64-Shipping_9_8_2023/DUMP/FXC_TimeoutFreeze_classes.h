// BlueprintGeneratedClass FXC_TimeoutFreeze.FXC_TimeoutFreeze_C
// Size: 0x550 (Inherited: 0x540)
struct AFXC_TimeoutFreeze_C : AEffectContainer {
	struct UPostProcessComponent* PostProcess; // 0x540(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x548(0x08)
};

