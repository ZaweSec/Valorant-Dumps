// BlueprintGeneratedClass BombPlayerState.BombPlayerState_C
// Size: 0xb40 (Inherited: 0xb38)
struct ABombPlayerState_C : ABasePlayerState_C {
	struct UBombTeamComponent* BombTeam; // 0xb38(0x08)
};

