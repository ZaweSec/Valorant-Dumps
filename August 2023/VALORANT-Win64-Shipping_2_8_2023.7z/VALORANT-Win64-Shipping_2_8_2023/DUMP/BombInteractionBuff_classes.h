// BlueprintGeneratedClass BombInteractionBuff.BombInteractionBuff_C
// Size: 0x990 (Inherited: 0x990)
struct UBombInteractionBuff_C : UAresGameplayBuff {
};

