// BlueprintGeneratedClass SimpleMinimapComponent.SimpleMinimapComponent_C
// Size: 0x500 (Inherited: 0x500)
struct USimpleMinimapComponent_C : UAresMinimapComponent {
};

