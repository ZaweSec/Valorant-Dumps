// BlueprintGeneratedClass CharacterPortraitMinimapComponent.CharacterPortraitMinimapComponent_C
// Size: 0x551 (Inherited: 0x540)
struct UCharacterPortraitMinimapComponent_C : UShooterCharacterMinimapComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x540(0x08)
	struct UTexture* CharacterIcon; // 0x548(0x08)
	bool Enable; // 0x550(0x01)

	void ReceiveBeginPlay(); // Function CharacterPortraitMinimapComponent.CharacterPortraitMinimapComponent_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x3bfde40
	void OnCharacterDeath(struct AShooterCharacter* Character, struct UDamageResponse* Response); // Function CharacterPortraitMinimapComponent.CharacterPortraitMinimapComponent_C.OnCharacterDeath // (BlueprintCallable|BlueprintEvent) // @ game+0x3bfde40
	void OnRoundEnd(int32_t RoundNumberEnded); // Function CharacterPortraitMinimapComponent.CharacterPortraitMinimapComponent_C.OnRoundEnd // (BlueprintCallable|BlueprintEvent) // @ game+0x3bfde40
	void InPerilStarted(struct UAresAbilitySystemComponent* AbilitySystem); // Function CharacterPortraitMinimapComponent.CharacterPortraitMinimapComponent_C.InPerilStarted // (BlueprintCallable|BlueprintEvent) // @ game+0x3bfde40
	void InPerilEndedDelegate(struct UAresAbilitySystemComponent* AbilitySystem); // Function CharacterPortraitMinimapComponent.CharacterPortraitMinimapComponent_C.InPerilEndedDelegate // (BlueprintCallable|BlueprintEvent) // @ game+0x3bfde40
	void ExecuteUbergraph_CharacterPortraitMinimapComponent(int32_t EntryPoint); // Function CharacterPortraitMinimapComponent.CharacterPortraitMinimapComponent_C.ExecuteUbergraph_CharacterPortraitMinimapComponent // (Final|UbergraphFunction|HasDefaults) // @ game+0x3bfde40
};

