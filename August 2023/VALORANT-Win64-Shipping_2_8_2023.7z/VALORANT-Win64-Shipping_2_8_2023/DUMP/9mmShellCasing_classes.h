// BlueprintGeneratedClass 9mmShellCasing.9mmShellCasing_C
// Size: 0x568 (Inherited: 0x568)
struct A9mmShellCasing_C : ABaseShellCasing_C {
};

