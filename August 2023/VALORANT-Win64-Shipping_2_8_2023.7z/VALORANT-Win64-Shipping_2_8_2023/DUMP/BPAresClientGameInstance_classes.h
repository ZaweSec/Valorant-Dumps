// BlueprintGeneratedClass BPAresClientGameInstance.BPAresClientGameInstance_C
// Size: 0x7d8 (Inherited: 0x7d8)
struct UBPAresClientGameInstance_C : UAresClientGameInstance {
};

