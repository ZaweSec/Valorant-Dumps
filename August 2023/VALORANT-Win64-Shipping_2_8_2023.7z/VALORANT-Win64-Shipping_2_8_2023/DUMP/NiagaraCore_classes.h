// Class NiagaraCore.NiagaraMergeable
// Size: 0x30 (Inherited: 0x30)
struct UNiagaraMergeable : UObject {
};

// Class NiagaraCore.NiagaraDataInterfaceBase
// Size: 0x30 (Inherited: 0x30)
struct UNiagaraDataInterfaceBase : UNiagaraMergeable {
};

