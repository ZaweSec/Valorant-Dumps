// BlueprintGeneratedClass Buff_ExtraGrenade.Buff_ExtraGrenade_C
// Size: 0x990 (Inherited: 0x990)
struct UBuff_ExtraGrenade_C : UAresGameplayBuff {
};

