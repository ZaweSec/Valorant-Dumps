// BlueprintGeneratedClass Comp_Actor_Crushable.Comp_Actor_Crushable_C
// Size: 0x140 (Inherited: 0xe8)
struct UComp_Actor_Crushable_C : UActorComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xe8(0x08)
	struct FClassInclusionExclusionFilter CrushingActorFilter; // 0xf0(0x50)

	void AuthApplyCrushDamage(struct AActor* CrushingObject, float DamageAmount); // Function Comp_Actor_Crushable.Comp_Actor_Crushable_C.AuthApplyCrushDamage // (BlueprintCallable|BlueprintEvent) // @ game+0x3bfde40
	void ExecuteUbergraph_Comp_Actor_Crushable(int32_t EntryPoint); // Function Comp_Actor_Crushable.Comp_Actor_Crushable_C.ExecuteUbergraph_Comp_Actor_Crushable // (Final|UbergraphFunction) // @ game+0x3bfde40
};

