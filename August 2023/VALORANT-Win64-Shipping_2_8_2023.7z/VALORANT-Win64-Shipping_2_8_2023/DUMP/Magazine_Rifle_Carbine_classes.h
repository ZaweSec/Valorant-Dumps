// BlueprintGeneratedClass Magazine_Rifle_Carbine.Magazine_Rifle_Carbine_C
// Size: 0x580 (Inherited: 0x580)
struct AMagazine_Rifle_Carbine_C : AMagazine_Rifle_AK_C {
};

