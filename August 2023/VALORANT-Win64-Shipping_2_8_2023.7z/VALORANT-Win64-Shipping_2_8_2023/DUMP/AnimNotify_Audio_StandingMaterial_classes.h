// BlueprintGeneratedClass AnimNotify_Audio_StandingMaterial.AnimNotify_Audio_StandingMaterial_C
// Size: 0x48 (Inherited: 0x40)
struct UAnimNotify_Audio_StandingMaterial_C : UAnimNotify {
	struct UAkAudioEvent* Event; // 0x40(0x08)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotify_Audio_StandingMaterial.AnimNotify_Audio_StandingMaterial_C.Received_Notify // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3bfde40
};

