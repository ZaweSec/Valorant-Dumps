// WidgetBlueprintGeneratedClass AbilityIconPrompt.AbilityIconPrompt_C
// Size: 0x318 (Inherited: 0x310)
struct UAbilityIconPrompt_C : UInputIconController_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)

	void Construct(); // Function AbilityIconPrompt.AbilityIconPrompt_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3bfde40
	void EventOnIconChange(); // Function AbilityIconPrompt.AbilityIconPrompt_C.EventOnIconChange // (BlueprintCallable|BlueprintEvent) // @ game+0x3bfde40
	void ExecuteUbergraph_AbilityIconPrompt(int32_t EntryPoint); // Function AbilityIconPrompt.AbilityIconPrompt_C.ExecuteUbergraph_AbilityIconPrompt // (Final|UbergraphFunction) // @ game+0x3bfde40
};

