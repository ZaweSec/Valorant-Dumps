// WidgetBlueprintGeneratedClass LeaveMatchConfirmationModal.LeaveMatchConfirmationModal_C
// Size: 0x548 (Inherited: 0x510)
struct ULeaveMatchConfirmationModal_C : UConfirmationModal_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)
	struct FText InMatchText; // 0x518(0x18)
	struct FText PreGameText; // 0x530(0x18)

	void OnExitConfirmed(); // Function LeaveMatchConfirmationModal.LeaveMatchConfirmationModal_C.OnExitConfirmed // (BlueprintCallable|BlueprintEvent) // @ game+0x3bfde40
	void OnExitCanceled(); // Function LeaveMatchConfirmationModal.LeaveMatchConfirmationModal_C.OnExitCanceled // (BlueprintCallable|BlueprintEvent) // @ game+0x3bfde40
	void OnInitialized(); // Function LeaveMatchConfirmationModal.LeaveMatchConfirmationModal_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3bfde40
	void Destruct(); // Function LeaveMatchConfirmationModal.LeaveMatchConfirmationModal_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3bfde40
	void Construct(); // Function LeaveMatchConfirmationModal.LeaveMatchConfirmationModal_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3bfde40
	void ExecuteUbergraph_LeaveMatchConfirmationModal(int32_t EntryPoint); // Function LeaveMatchConfirmationModal.LeaveMatchConfirmationModal_C.ExecuteUbergraph_LeaveMatchConfirmationModal // (Final|UbergraphFunction|HasDefaults) // @ game+0x3bfde40
};

