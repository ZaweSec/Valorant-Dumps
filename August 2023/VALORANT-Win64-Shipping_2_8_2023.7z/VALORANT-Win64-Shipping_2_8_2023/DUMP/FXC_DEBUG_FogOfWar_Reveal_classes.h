// BlueprintGeneratedClass FXC_DEBUG_FogOfWar_Reveal.FXC_DEBUG_FogOfWar_Reveal_C
// Size: 0x618 (Inherited: 0x609)
struct AFXC_DEBUG_FogOfWar_Reveal_C : AFXC_Global_Reveal_HiddenWhenVisible_C {
	char pad_609[0x7]; // 0x609(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x610(0x08)

	void ReceiveTick(float DeltaSeconds); // Function FXC_DEBUG_FogOfWar_Reveal.FXC_DEBUG_FogOfWar_Reveal_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x3bfde40
	void ExecuteUbergraph_FXC_DEBUG_FogOfWar_Reveal(int32_t EntryPoint); // Function FXC_DEBUG_FogOfWar_Reveal.FXC_DEBUG_FogOfWar_Reveal_C.ExecuteUbergraph_FXC_DEBUG_FogOfWar_Reveal // (Final|UbergraphFunction) // @ game+0x3bfde40
};

