// BlueprintGeneratedClass FXC_BasePistol_Equip.FXC_BasePistol_Equip_C
// Size: 0x580 (Inherited: 0x580)
struct AFXC_BasePistol_Equip_C : AFXC_Gun_Equip_C {
};

