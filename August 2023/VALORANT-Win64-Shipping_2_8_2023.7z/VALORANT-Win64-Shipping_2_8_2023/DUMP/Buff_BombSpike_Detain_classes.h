// BlueprintGeneratedClass Buff_BombSpike_Detain.Buff_BombSpike_Detain_C
// Size: 0x990 (Inherited: 0x990)
struct UBuff_BombSpike_Detain_C : UAresGameplayBuff {
};

