// UserDefinedEnum DeathMatchVOEnum.DeathMatchVOEnum
enum class DeathMatchVOEnum : uint8 {
	NewEnumerator16 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator18 = 3,
	DeathMatchVOEnum_MAX = 4
};

