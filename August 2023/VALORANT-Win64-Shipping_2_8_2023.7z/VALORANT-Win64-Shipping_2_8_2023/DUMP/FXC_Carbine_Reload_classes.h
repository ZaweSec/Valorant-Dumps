// BlueprintGeneratedClass FXC_Carbine_Reload.FXC_Carbine_Reload_C
// Size: 0x588 (Inherited: 0x588)
struct AFXC_Carbine_Reload_C : AFXC_Gun_Reload_C {
};

