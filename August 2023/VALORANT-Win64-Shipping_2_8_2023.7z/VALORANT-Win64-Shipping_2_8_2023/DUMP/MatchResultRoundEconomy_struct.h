// UserDefinedStruct MatchResultRoundEconomy.MatchResultRoundEconomy
// Size: 0x14 (Inherited: 0x00)
struct FMatchResultRoundEconomy {
	struct TArray<struct FMatchResultPlayerEconomy> playerEconomies_3_CB6936D8421227488F2CB086B9D11507; // 0x00(0x10)
	int32_t round_7_ADF6D5FC43C580BE17511AADDCE30278; // 0x10(0x04)
};

