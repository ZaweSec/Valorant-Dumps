// BlueprintGeneratedClass CommMenuOption1ActionTraits.CommMenuOption1ActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UCommMenuOption1ActionTraits_C : UActionTraits {
};

