// UserDefinedEnum Struct_ParticleStopBehavior.Struct_ParticleStopBehavior
enum class Struct_ParticleStopBehavior : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	Struct_MAX = 2
};

