// BlueprintGeneratedClass ObservePlayer6ActionTraits.ObservePlayer6ActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UObservePlayer6ActionTraits_C : UActionTraits {
};

