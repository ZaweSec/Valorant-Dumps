// WidgetBlueprintGeneratedClass Widget_Ability_Element_ChargeItem.Widget_Ability_Element_ChargeItem_C
// Size: 0x2d0 (Inherited: 0x2c8)
struct UWidget_Ability_Element_ChargeItem_C : UUserWidget {
	struct UImage* Rect; // 0x2c8(0x08)
};

