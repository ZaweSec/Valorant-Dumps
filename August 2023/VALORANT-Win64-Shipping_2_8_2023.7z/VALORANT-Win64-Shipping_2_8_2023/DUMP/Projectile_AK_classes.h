// BlueprintGeneratedClass Projectile_AK.Projectile_AK_C
// Size: 0x530 (Inherited: 0x530)
struct AProjectile_AK_C : AProjectile_Gun_C {
};

