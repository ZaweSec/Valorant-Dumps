// UserDefinedStruct MatchResultPlayerEconomy.MatchResultPlayerEconomy
// Size: 0x40 (Inherited: 0x00)
struct FMatchResultPlayerEconomy {
	struct FString Subject_15_9CA928D44A801927BFAD0794F8AA1C7F; // 0x00(0x10)
	int32_t LoadoutValue_14_D89F9DE14795868F74C48AA7FF2F88F2; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FString Weapon_13_55387BEC4CD6928999F6D48620484554; // 0x18(0x10)
	struct FString Armor_12_A949E66E47F370772865CEB9E1934A41; // 0x28(0x10)
	int32_t Remaining_11_55BFFE4C4293F42F5D340583CFB2DF1E; // 0x38(0x04)
	int32_t Spent_18_C23A08A8434C2B9B7312D6B95D362861; // 0x3c(0x04)
};

