// WidgetBlueprintGeneratedClass InputStructIconPrompt.InputStructIconPrompt_C
// Size: 0x358 (Inherited: 0x310)
struct UInputStructIconPrompt_C : UInputIconController_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct FStruct_Widget_Ability_Input InputStruct; // 0x318(0x38)
	struct UUserWidget* SharedUserWidget; // 0x350(0x08)

	void UpdateInputStruct(struct FStruct_Widget_Ability_Input New Input Struct); // Function InputStructIconPrompt.InputStructIconPrompt_C.UpdateInputStruct // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3bfde40
	void Construct(); // Function InputStructIconPrompt.InputStructIconPrompt_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3bfde40
	void Destruct(); // Function InputStructIconPrompt.InputStructIconPrompt_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3bfde40
	void OnPresetChanged(enum class EAresIntSettingName SettingName, int32_t OldValue, int32_t NewValue); // Function InputStructIconPrompt.InputStructIconPrompt_C.OnPresetChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x3bfde40
	void EventOnIconChange(); // Function InputStructIconPrompt.InputStructIconPrompt_C.EventOnIconChange // (BlueprintCallable|BlueprintEvent) // @ game+0x3bfde40
	void ExecuteUbergraph_InputStructIconPrompt(int32_t EntryPoint); // Function InputStructIconPrompt.InputStructIconPrompt_C.ExecuteUbergraph_InputStructIconPrompt // (Final|UbergraphFunction|HasDefaults) // @ game+0x3bfde40
};

