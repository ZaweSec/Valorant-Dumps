// BlueprintGeneratedClass GhostActionTraits.GhostActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UGhostActionTraits_C : UActionTraits {
};

