// BlueprintGeneratedClass FastSemiCrosshairHud.FastSemiCrosshairHud_C
// Size: 0x220 (Inherited: 0x220)
struct UFastSemiCrosshairHud_C : ULineCrosshairHudElement {
};

