// BlueprintGeneratedClass NavpointComponent.NavpointComponent_C
// Size: 0x6e0 (Inherited: 0x6e0)
struct UNavpointComponent_C : UNavPointComponent {
};

