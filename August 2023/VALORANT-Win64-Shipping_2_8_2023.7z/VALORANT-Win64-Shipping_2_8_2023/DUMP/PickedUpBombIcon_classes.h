// WidgetBlueprintGeneratedClass PickedUpBombIcon.PickedUpBombIcon_C
// Size: 0x338 (Inherited: 0x338)
struct UPickedUpBombIcon_C : UBombIconNotificationWidget_C {
};

