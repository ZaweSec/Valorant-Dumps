// UserDefinedEnum CharacterRelationRoundStartVOEnum.CharacterRelationRoundStartVOEnum
enum class CharacterRelationRoundStartVOEnum : uint8 {
	NewEnumerator8 = 0,
	NewEnumerator5 = 1,
	NewEnumerator6 = 2,
	NewEnumerator7 = 3,
	CharacterRelationRoundStartVOEnum_MAX = 4
};

