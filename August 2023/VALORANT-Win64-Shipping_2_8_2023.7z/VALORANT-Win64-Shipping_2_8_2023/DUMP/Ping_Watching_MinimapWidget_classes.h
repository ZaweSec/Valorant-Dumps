// WidgetBlueprintGeneratedClass Ping_Watching_MinimapWidget.Ping_Watching_MinimapWidget_C
// Size: 0x3d8 (Inherited: 0x3c0)
struct UPing_Watching_MinimapWidget_C : UMissingMinimapWidget_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3c0(0x08)
	struct UWidgetAnimation* Pulse; // 0x3c8(0x08)
	struct UImage* Icon; // 0x3d0(0x08)

	void Construct(); // Function Ping_Watching_MinimapWidget.Ping_Watching_MinimapWidget_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3bfde40
	void ExecuteUbergraph_Ping_Watching_MinimapWidget(int32_t EntryPoint); // Function Ping_Watching_MinimapWidget.Ping_Watching_MinimapWidget_C.ExecuteUbergraph_Ping_Watching_MinimapWidget // (Final|UbergraphFunction) // @ game+0x3bfde40
};

