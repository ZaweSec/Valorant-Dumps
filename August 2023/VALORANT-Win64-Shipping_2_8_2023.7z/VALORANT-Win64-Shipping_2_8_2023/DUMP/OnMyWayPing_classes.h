// BlueprintGeneratedClass OnMyWayPing.OnMyWayPing_C
// Size: 0x6c8 (Inherited: 0x6c8)
struct AOnMyWayPing_C : ABasePing_C {

	void RemoveOtherPingsOfType(); // Function OnMyWayPing.OnMyWayPing_C.RemoveOtherPingsOfType // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3bfde40
};

