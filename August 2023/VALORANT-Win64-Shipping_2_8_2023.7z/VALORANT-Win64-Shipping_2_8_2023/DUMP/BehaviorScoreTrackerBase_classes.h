// BlueprintGeneratedClass BehaviorScoreTrackerBase.BehaviorScoreTrackerBase_C
// Size: 0x450 (Inherited: 0x450)
struct ABehaviorScoreTrackerBase_C : ABehaviorScoreTracker {
};

