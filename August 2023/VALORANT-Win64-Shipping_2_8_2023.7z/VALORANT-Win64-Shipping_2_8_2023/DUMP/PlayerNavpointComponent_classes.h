// BlueprintGeneratedClass PlayerNavpointComponent.PlayerNavpointComponent_C
// Size: 0x6e0 (Inherited: 0x6e0)
struct UPlayerNavpointComponent_C : UNavpointComponent_C {
};

