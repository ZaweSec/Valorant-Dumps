// UserDefinedStruct MatchResultMapLocation.MatchResultMapLocation
// Size: 0x08 (Inherited: 0x00)
struct FMatchResultMapLocation {
	int32_t x_7_A9B1780A47FFCD05F8D1C98DA886EA2D; // 0x00(0x04)
	int32_t y_8_A016DED54C5E6F9038F214B4AA19C45F; // 0x04(0x04)
};

