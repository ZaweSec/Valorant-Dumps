// BlueprintGeneratedClass BaseShooterCamera.BaseShooterCamera_C
// Size: 0x2f60 (Inherited: 0x2f60)
struct ABaseShooterCamera_C : AShooterCamera {
};

