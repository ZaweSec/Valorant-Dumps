// BlueprintGeneratedClass Comp_PlayerState_InPerilHandler.Comp_PlayerState_InPerilHandler_C
// Size: 0x130 (Inherited: 0x130)
struct UComp_PlayerState_InPerilHandler_C : UInPerilHandlerComponent {
};

