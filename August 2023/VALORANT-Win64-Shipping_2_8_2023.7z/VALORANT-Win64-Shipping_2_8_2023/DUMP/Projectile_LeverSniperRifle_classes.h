// BlueprintGeneratedClass Projectile_LeverSniperRifle.Projectile_LeverSniperRifle_C
// Size: 0x530 (Inherited: 0x530)
struct AProjectile_LeverSniperRifle_C : AProjectile_Gun_C {
};

