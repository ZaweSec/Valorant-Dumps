// UserDefinedEnum Enum_AscenderMovementType.Enum_AscenderMovementType
enum class Enum_AscenderMovementType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	Enum_MAX = 3
};

