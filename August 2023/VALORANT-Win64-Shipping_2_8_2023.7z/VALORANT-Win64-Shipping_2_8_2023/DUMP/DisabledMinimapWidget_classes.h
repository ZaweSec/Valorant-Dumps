// WidgetBlueprintGeneratedClass DisabledMinimapWidget.DisabledMinimapWidget_C
// Size: 0x3b0 (Inherited: 0x3a1)
struct UDisabledMinimapWidget_C : UAresMinimapWidget_C {
	char pad_3A1[0x7]; // 0x3a1(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3a8(0x08)

	void Update Minimap Center and Zoom(); // Function DisabledMinimapWidget.DisabledMinimapWidget_C.Update Minimap Center and Zoom // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3bfde40
	void Construct(); // Function DisabledMinimapWidget.DisabledMinimapWidget_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3bfde40
	void ExecuteUbergraph_DisabledMinimapWidget(int32_t EntryPoint); // Function DisabledMinimapWidget.DisabledMinimapWidget_C.ExecuteUbergraph_DisabledMinimapWidget // (Final|UbergraphFunction) // @ game+0x3bfde40
};

