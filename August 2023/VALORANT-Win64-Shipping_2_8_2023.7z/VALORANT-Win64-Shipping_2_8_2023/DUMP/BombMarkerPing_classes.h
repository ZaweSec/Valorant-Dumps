// BlueprintGeneratedClass BombMarkerPing.BombMarkerPing_C
// Size: 0x6c8 (Inherited: 0x6c8)
struct ABombMarkerPing_C : ABasePing_C {
};

