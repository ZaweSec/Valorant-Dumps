// BlueprintGeneratedClass BombPlantedHUDConfig.BombPlantedHUDConfig_C
// Size: 0xc0 (Inherited: 0xc0)
struct UBombPlantedHUDConfig_C : UGameStateHUDConfig {
};

