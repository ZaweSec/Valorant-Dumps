// BlueprintGeneratedClass EnemyHerePing.EnemyHerePing_C
// Size: 0x6c8 (Inherited: 0x6c8)
struct AEnemyHerePing_C : ABasePing_C {
};

