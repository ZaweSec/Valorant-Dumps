// BlueprintGeneratedClass BPAresSettingsManager.BPAresSettingsManager_C
// Size: 0x428 (Inherited: 0x428)
struct UBPAresSettingsManager_C : UAresSettingsManager {
};

