// BlueprintGeneratedClass FXC_BasePistol_Inspect_Emote.FXC_BasePistol_Inspect_Emote_C
// Size: 0x582 (Inherited: 0x582)
struct AFXC_BasePistol_Inspect_Emote_C : AFXC_Gun_Emote_C {
};

