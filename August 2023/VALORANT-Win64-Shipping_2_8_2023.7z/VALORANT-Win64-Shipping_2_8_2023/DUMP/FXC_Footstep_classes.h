// BlueprintGeneratedClass FXC_Footstep.FXC_Footstep_C
// Size: 0x578 (Inherited: 0x578)
struct AFXC_Footstep_C : AFXC_GroundSound_C {
};

