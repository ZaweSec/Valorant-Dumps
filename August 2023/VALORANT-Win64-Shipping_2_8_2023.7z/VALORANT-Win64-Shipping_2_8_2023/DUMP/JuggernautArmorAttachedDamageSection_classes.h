// BlueprintGeneratedClass JuggernautArmorAttachedDamageSection.JuggernautArmorAttachedDamageSection_C
// Size: 0x150 (Inherited: 0x150)
struct UJuggernautArmorAttachedDamageSection_C : UAttachedDamageSectionComponent {

	float AuthApplyDamage(float Damage, struct UDamageType* DamageType, struct AController* EventInstigator, struct AActor* DamageCauser, struct ADamageSource* DamageSource, enum class EAresRegionalDamage RegionalDamage, float& DamageApplied, float& DamageRemaining, bool bSimulation); // Function JuggernautArmorAttachedDamageSection.JuggernautArmorAttachedDamageSection_C.AuthApplyDamage // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3bfde40
};

