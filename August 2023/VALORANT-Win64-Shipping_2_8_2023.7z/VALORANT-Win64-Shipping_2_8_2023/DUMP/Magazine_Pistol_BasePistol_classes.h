// BlueprintGeneratedClass Magazine_Pistol_BasePistol.Magazine_Pistol_BasePistol_C
// Size: 0x580 (Inherited: 0x580)
struct AMagazine_Pistol_BasePistol_C : ABaseMagazine_C {
};

