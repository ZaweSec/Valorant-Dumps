// BlueprintGeneratedClass SecondaryTriggerActionTraits.SecondaryTriggerActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct USecondaryTriggerActionTraits_C : UActionTraits {
};

