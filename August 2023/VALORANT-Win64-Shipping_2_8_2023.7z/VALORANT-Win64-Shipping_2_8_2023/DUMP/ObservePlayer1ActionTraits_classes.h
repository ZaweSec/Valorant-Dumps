// BlueprintGeneratedClass ObservePlayer1ActionTraits.ObservePlayer1ActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UObservePlayer1ActionTraits_C : UActionTraits {
};

