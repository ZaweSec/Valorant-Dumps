// BlueprintGeneratedClass FXC_RedDot_VFX.FXC_RedDot_VFX_C
// Size: 0x550 (Inherited: 0x540)
struct AFXC_RedDot_VFX_C : AEffectContainer {
	struct UReflex_Particle_Component_C* GunSkin_Reflex_Particle_Component; // 0x540(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x548(0x08)
};

