// BlueprintGeneratedClass Interface_Widget_Ability.Interface_Widget_Ability_C
// Size: 0x30 (Inherited: 0x30)
struct UInterface_Widget_Ability_C : UInterface {

	void HasInputPrompt(bool& Has Input Prompt); // Function Interface_Widget_Ability.Interface_Widget_Ability_C.HasInputPrompt // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void SetInputPromptVisibility(enum class ESlateVisibility Visible); // Function Interface_Widget_Ability.Interface_Widget_Ability_C.SetInputPromptVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void InputPromptRemoved(); // Function Interface_Widget_Ability.Interface_Widget_Ability_C.InputPromptRemoved // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void AddInputPrompt(struct UUserWidget* InInputPromptWidget); // Function Interface_Widget_Ability.Interface_Widget_Ability_C.AddInputPrompt // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void AddTimer(struct UUserWidget* InTimerWidget); // Function Interface_Widget_Ability.Interface_Widget_Ability_C.AddTimer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
};

