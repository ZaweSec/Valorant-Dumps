// BlueprintGeneratedClass GameplayVoteOptionBase.GameplayVoteOptionBase_C
// Size: 0x160 (Inherited: 0x158)
struct UGameplayVoteOptionBase_C : UGameplayVoteOptionComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x158(0x08)

	void AuthNotifyAllParticipants(struct FText NotificationText); // Function GameplayVoteOptionBase.GameplayVoteOptionBase_C.AuthNotifyAllParticipants // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void OnSelected(); // Function GameplayVoteOptionBase.GameplayVoteOptionBase_C.OnSelected // (Event|Public|BlueprintEvent) // @ game+0x3c7c9e0
	void ExecuteUbergraph_GameplayVoteOptionBase(int32_t EntryPoint); // Function GameplayVoteOptionBase.GameplayVoteOptionBase_C.ExecuteUbergraph_GameplayVoteOptionBase // (Final|UbergraphFunction) // @ game+0x3c7c9e0
};

