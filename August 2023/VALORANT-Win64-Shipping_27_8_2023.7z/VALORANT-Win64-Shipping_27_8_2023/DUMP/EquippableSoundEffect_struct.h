// UserDefinedStruct EquippableSoundEffect.EquippableSoundEffect
// Size: 0x15 (Inherited: 0x00)
struct FEquippableSoundEffect {
	struct UAkAudioEvent* SoundEvent_2_BF66D53C458E6CF5A20F918FC95C8F89; // 0x00(0x08)
	struct FName AttachPointName_9_D6A4EE874FAF65DC3176CC8DF8AE7F77; // 0x08(0x0c)
	bool bSoundFollowsAttachPoint_8_E0FAD374487FFC4917A3AFBA8FBF35AB; // 0x14(0x01)
};

