// BlueprintGeneratedClass SurrenderYesOption.SurrenderYesOption_C
// Size: 0x168 (Inherited: 0x160)
struct USurrenderYesOption_C : UGameplayVoteOptionBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x160(0x08)

	void AuthUpdateVotesNeeded(); // Function SurrenderYesOption.SurrenderYesOption_C.AuthUpdateVotesNeeded // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void OnSelected(); // Function SurrenderYesOption.SurrenderYesOption_C.OnSelected // (Event|Public|BlueprintEvent) // @ game+0x3c7c9e0
	void ExecuteUbergraph_SurrenderYesOption(int32_t EntryPoint); // Function SurrenderYesOption.SurrenderYesOption_C.ExecuteUbergraph_SurrenderYesOption // (Final|UbergraphFunction|HasDefaults) // @ game+0x3c7c9e0
};

