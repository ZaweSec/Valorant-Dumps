// BlueprintGeneratedClass BombInteractionBlockEquipping.BombInteractionBlockEquipping_C
// Size: 0x990 (Inherited: 0x990)
struct UBombInteractionBlockEquipping_C : UAresGameplayBuff {
};

