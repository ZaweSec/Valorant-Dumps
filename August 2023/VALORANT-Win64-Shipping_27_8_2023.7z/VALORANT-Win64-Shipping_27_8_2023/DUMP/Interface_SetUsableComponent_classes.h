// BlueprintGeneratedClass Interface_SetUsableComponent.Interface_SetUsableComponent_C
// Size: 0x30 (Inherited: 0x30)
struct UInterface_SetUsableComponent_C : UInterface {

	void UpdateUsability(bool NewUsability); // Function Interface_SetUsableComponent.Interface_SetUsableComponent_C.UpdateUsability // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void UpdateInUse(bool NewInUse); // Function Interface_SetUsableComponent.Interface_SetUsableComponent_C.UpdateInUse // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void SetUsableComponent(struct UUsableComponent* InUsableComponent, struct UWidgetComponent* InWidgetComponent, bool CurrentlyUsable, bool CurrentlyInUse, bool ShowUsableTime, bool ShowThirds, struct USceneComponent* PivotComponent, bool ShowProgressBar, bool ShowOwnerName, bool ShowCannotUseText); // Function Interface_SetUsableComponent.Interface_SetUsableComponent_C.SetUsableComponent // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
};

