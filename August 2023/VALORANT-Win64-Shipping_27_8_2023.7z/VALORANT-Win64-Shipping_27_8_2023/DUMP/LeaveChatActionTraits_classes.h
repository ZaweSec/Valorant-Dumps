// BlueprintGeneratedClass LeaveChatActionTraits.LeaveChatActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct ULeaveChatActionTraits_C : UActionTraits {
};

