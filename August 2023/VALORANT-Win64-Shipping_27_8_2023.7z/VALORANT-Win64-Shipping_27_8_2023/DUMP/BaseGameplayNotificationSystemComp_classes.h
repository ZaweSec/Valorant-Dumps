// BlueprintGeneratedClass BaseGameplayNotificationSystemComp.BaseGameplayNotificationSystemComp_C
// Size: 0x108 (Inherited: 0x108)
struct UBaseGameplayNotificationSystemComp_C : UGameplayNotificationSystemComponent {
};

