// BlueprintGeneratedClass Projectile_ACR.Projectile_ACR_C
// Size: 0x540 (Inherited: 0x540)
struct AProjectile_ACR_C : AProjectile_Gun_C {
};

