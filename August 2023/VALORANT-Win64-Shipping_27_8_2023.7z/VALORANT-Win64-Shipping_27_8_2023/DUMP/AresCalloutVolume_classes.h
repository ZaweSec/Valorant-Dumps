// BlueprintGeneratedClass AresCalloutVolume.AresCalloutVolume_C
// Size: 0x410 (Inherited: 0x410)
struct AAresCalloutVolume_C : AAresCalloutVolume {
};

