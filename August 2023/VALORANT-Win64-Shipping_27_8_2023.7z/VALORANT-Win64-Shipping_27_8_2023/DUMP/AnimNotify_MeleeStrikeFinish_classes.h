// BlueprintGeneratedClass AnimNotify_MeleeStrikeFinish.AnimNotify_MeleeStrikeFinish_C
// Size: 0x40 (Inherited: 0x40)
struct UAnimNotify_MeleeStrikeFinish_C : UAnimNotify {
};

