// BlueprintGeneratedClass SurrenderNoOption.SurrenderNoOption_C
// Size: 0x168 (Inherited: 0x160)
struct USurrenderNoOption_C : UGameplayVoteOptionBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x160(0x08)

	void AuthUpdateVotesNeeded(); // Function SurrenderNoOption.SurrenderNoOption_C.AuthUpdateVotesNeeded // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void OnSelected(); // Function SurrenderNoOption.SurrenderNoOption_C.OnSelected // (Event|Public|BlueprintEvent) // @ game+0x3c7c9e0
	void ExecuteUbergraph_SurrenderNoOption(int32_t EntryPoint); // Function SurrenderNoOption.SurrenderNoOption_C.ExecuteUbergraph_SurrenderNoOption // (Final|UbergraphFunction|HasDefaults) // @ game+0x3c7c9e0
};

