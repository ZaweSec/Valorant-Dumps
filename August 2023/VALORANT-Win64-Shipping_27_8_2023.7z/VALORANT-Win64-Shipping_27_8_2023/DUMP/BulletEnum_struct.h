// UserDefinedEnum BulletEnum.BulletEnum
enum class BulletEnum : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator5 = 1,
	NewEnumerator1 = 2,
	NewEnumerator6 = 3,
	NewEnumerator7 = 4,
	NewEnumerator2 = 5,
	NewEnumerator3 = 6,
	NewEnumerator8 = 7,
	NewEnumerator9 = 8,
	NewEnumerator4 = 9,
	NewEnumerator10 = 10,
	NewEnumerator11 = 11,
	NewEnumerator12 = 12,
	NewEnumerator13 = 13,
	BulletEnum_MAX = 14
};

