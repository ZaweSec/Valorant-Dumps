// BlueprintGeneratedClass FXC_Bomb_Minimap_Explosion.FXC_Bomb_Minimap_Explosion_C
// Size: 0x550 (Inherited: 0x540)
struct AFXC_Bomb_Minimap_Explosion_C : AEffectContainer {
	struct UBaseMinimapComponent_AlwaysVisible_C* BaseMinimapComponent_AlwaysVisible; // 0x540(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x548(0x08)
};

