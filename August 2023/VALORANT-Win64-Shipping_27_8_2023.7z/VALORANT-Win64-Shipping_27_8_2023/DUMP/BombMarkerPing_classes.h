// BlueprintGeneratedClass BombMarkerPing.BombMarkerPing_C
// Size: 0x6d0 (Inherited: 0x6d0)
struct ABombMarkerPing_C : ABasePing_C {
};

