// UserDefinedStruct SiteRushWeaponPool.SiteRushWeaponPool
// Size: 0x18 (Inherited: 0x00)
struct FSiteRushWeaponPool {
	struct TArray<struct AAresItem*> Weapons_3_AC2EDCA447E381DC5C1F3A9AB5E43D78; // 0x00(0x10)
	struct AAresItem* Armor_6_5D5AD23348CE98A97132A99B21FED08D; // 0x10(0x08)
};

