// BlueprintGeneratedClass BombDefusePing.BombDefusePing_C
// Size: 0x6d0 (Inherited: 0x6d0)
struct ABombDefusePing_C : ABasePing_C {
};

