// BlueprintGeneratedClass Debuff_GrievousWounds.Debuff_GrievousWounds_C
// Size: 0x990 (Inherited: 0x990)
struct UDebuff_GrievousWounds_C : UAresGameplayBuff {
};

