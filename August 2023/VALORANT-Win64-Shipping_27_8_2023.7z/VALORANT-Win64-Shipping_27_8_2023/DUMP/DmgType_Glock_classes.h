// BlueprintGeneratedClass DmgType_Glock.DmgType_Glock_C
// Size: 0x170 (Inherited: 0x170)
struct UDmgType_Glock_C : UDmgType_PistolBase_C {
};

