// UserDefinedEnum CharacterRelationMatchVOEnum.CharacterRelationMatchVOEnum
enum class CharacterRelationMatchVOEnum : uint8 {
	NewEnumerator5 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	CharacterRelationMatchVOEnum_MAX = 3
};

