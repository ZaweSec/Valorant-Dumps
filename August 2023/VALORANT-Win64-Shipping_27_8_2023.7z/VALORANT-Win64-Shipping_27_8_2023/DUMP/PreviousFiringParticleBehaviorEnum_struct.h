// UserDefinedEnum PreviousFiringParticleBehaviorEnum.PreviousFiringParticleBehaviorEnum
enum class PreviousFiringParticleBehaviorEnum : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	PreviousFiringParticleBehaviorEnum_MAX = 3
};

