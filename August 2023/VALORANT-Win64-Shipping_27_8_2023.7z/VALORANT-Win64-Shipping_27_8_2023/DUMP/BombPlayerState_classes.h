// BlueprintGeneratedClass BombPlayerState.BombPlayerState_C
// Size: 0xb58 (Inherited: 0xb50)
struct ABombPlayerState_C : ABasePlayerState_C {
	struct UBombTeamComponent* BombTeam; // 0xb50(0x08)
};

