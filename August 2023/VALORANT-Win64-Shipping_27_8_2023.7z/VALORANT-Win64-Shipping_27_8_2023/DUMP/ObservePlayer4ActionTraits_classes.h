// BlueprintGeneratedClass ObservePlayer4ActionTraits.ObservePlayer4ActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UObservePlayer4ActionTraits_C : UActionTraits {
};

