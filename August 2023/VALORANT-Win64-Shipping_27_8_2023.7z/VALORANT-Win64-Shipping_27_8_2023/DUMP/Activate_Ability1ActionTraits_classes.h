// BlueprintGeneratedClass Activate_Ability1ActionTraits.Activate_Ability1ActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UActivate_Ability1ActionTraits_C : UActionTraits {
};

