// UserDefinedStruct MapRelationshipInstance.MapRelationshipInstance
// Size: 0x50 (Inherited: 0x00)
struct FMapRelationshipInstance {
	struct TMap<enum class MapID, struct UAkAudioEvent*> RelatedMaps_24_6887B605417EBF9480564A9C19BF46F4; // 0x00(0x50)
};

