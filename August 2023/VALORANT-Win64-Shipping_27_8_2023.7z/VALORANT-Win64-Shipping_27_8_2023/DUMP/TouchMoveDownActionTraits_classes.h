// BlueprintGeneratedClass TouchMoveDownActionTraits.TouchMoveDownActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UTouchMoveDownActionTraits_C : UActionTraits {
};

