// BlueprintGeneratedClass BombPlantPing.BombPlantPing_C
// Size: 0x6d0 (Inherited: 0x6d0)
struct ABombPlantPing_C : ABasePing_C {
};

