// BlueprintGeneratedClass PreventSwitchingEquippablesBuff.PreventSwitchingEquippablesBuff_C
// Size: 0x990 (Inherited: 0x990)
struct UPreventSwitchingEquippablesBuff_C : UAresGameplayBuff {
};

