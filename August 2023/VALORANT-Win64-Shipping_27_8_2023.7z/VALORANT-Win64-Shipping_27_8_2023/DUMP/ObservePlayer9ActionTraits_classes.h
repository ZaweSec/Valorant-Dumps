// BlueprintGeneratedClass ObservePlayer9ActionTraits.ObservePlayer9ActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UObservePlayer9ActionTraits_C : UActionTraits {
};

