// BlueprintGeneratedClass FXC_AK_InstantEquip.FXC_AK_InstantEquip_C
// Size: 0x580 (Inherited: 0x580)
struct AFXC_AK_InstantEquip_C : AFXC_Gun_Equip_C {
};

