// BlueprintGeneratedClass MeleeEffectComponent.MeleeEffectComponent_C
// Size: 0x100 (Inherited: 0xf8)
struct UMeleeEffectComponent_C : UEffectComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xf8(0x08)

	void StartEffect(struct AActor* Target, struct UObject* Context, float StartTime, bool FirstPerson); // Function MeleeEffectComponent.MeleeEffectComponent_C.StartEffect // (Event|Public|BlueprintEvent) // @ game+0x3c7c9e0
	void Item Unequipped(); // Function MeleeEffectComponent.MeleeEffectComponent_C.Item Unequipped // (BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void ExecuteUbergraph_MeleeEffectComponent(int32_t EntryPoint); // Function MeleeEffectComponent.MeleeEffectComponent_C.ExecuteUbergraph_MeleeEffectComponent // (Final|UbergraphFunction|HasDefaults) // @ game+0x3c7c9e0
};

