// BlueprintGeneratedClass Magazine_Rifle_Carbine.Magazine_Rifle_Carbine_C
// Size: 0x588 (Inherited: 0x588)
struct AMagazine_Rifle_Carbine_C : AMagazine_Rifle_AK_C {
};

