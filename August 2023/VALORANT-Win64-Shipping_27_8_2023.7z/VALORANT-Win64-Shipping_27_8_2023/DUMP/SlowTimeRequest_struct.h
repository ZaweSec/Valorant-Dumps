// UserDefinedStruct SlowTimeRequest.SlowTimeRequest
// Size: 0x18 (Inherited: 0x00)
struct FSlowTimeRequest {
	float TimeSlowGoal_3_9A7317E749E074B30B1C53AB677765E5; // 0x00(0x04)
	float TimeSlowRemaining_13_7232B6F14F210DBDC94545A69D7BF248; // 0x04(0x04)
	float TimeSlowSpeed_9_5089773D41A36455585727963988774E; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct AActor* Requestor_12_A0EF8A8B469CBB891164E0B557D98909; // 0x10(0x08)
};

