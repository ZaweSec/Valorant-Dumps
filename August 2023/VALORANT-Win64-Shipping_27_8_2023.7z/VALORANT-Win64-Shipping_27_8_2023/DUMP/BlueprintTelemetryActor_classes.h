// BlueprintGeneratedClass BlueprintTelemetryActor.BlueprintTelemetryActor_C
// Size: 0x3d8 (Inherited: 0x3d0)
struct ABlueprintTelemetryActor_C : AActor {
	struct USceneComponent* DefaultSceneRoot; // 0x3d0(0x08)
};

