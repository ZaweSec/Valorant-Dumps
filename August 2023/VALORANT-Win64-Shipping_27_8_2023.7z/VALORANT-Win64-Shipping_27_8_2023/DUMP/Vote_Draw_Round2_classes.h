// BlueprintGeneratedClass Vote_Draw_Round2.Vote_Draw_Round2_C
// Size: 0x580 (Inherited: 0x580)
struct AVote_Draw_Round2_C : AVote_Draw_Base_C {
};

