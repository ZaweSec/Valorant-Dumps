// BlueprintGeneratedClass FXC_Carbine_InstantEquip.FXC_Carbine_InstantEquip_C
// Size: 0x580 (Inherited: 0x580)
struct AFXC_Carbine_InstantEquip_C : AFXC_Gun_Equip_C {
};

