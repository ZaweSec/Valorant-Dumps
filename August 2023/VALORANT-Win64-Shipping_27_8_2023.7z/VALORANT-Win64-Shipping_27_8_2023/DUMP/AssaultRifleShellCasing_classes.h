// BlueprintGeneratedClass AssaultRifleShellCasing.AssaultRifleShellCasing_C
// Size: 0x570 (Inherited: 0x570)
struct AAssaultRifleShellCasing_C : ABaseShellCasing_C {
};

