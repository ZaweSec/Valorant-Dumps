// BlueprintGeneratedClass FXC_Melee_Tactical_Attack_Alt.FXC_Melee_Tactical_Attack_Alt_C
// Size: 0x580 (Inherited: 0x580)
struct AFXC_Melee_Tactical_Attack_Alt_C : AFXC_Melee_Tactical_Attack_C {
};

