// BlueprintGeneratedClass Projectile_LeverSniperRifle.Projectile_LeverSniperRifle_C
// Size: 0x540 (Inherited: 0x540)
struct AProjectile_LeverSniperRifle_C : AProjectile_Gun_C {
};

