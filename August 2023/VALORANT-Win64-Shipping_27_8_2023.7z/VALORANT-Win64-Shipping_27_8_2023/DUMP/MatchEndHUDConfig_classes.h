// BlueprintGeneratedClass MatchEndHUDConfig.MatchEndHUDConfig_C
// Size: 0xc0 (Inherited: 0xc0)
struct UMatchEndHUDConfig_C : UGameStateHUDConfig {
};

