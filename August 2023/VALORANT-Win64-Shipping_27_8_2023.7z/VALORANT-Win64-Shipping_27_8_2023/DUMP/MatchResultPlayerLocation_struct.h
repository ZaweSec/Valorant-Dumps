// UserDefinedStruct MatchResultPlayerLocation.MatchResultPlayerLocation
// Size: 0x20 (Inherited: 0x00)
struct FMatchResultPlayerLocation {
	struct FMatchResultMapLocation location_8_A9B1780A47FFCD05F8D1C98DA886EA2D; // 0x00(0x08)
	float viewRadians_7_D233027D4DF11E18F2CE91824AE2EB91; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FString subject_6_89F6A32F4B8473E7969911A9A289064B; // 0x10(0x10)
};

