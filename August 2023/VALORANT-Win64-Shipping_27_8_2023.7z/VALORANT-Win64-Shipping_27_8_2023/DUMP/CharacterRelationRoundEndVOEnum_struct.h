// UserDefinedEnum CharacterRelationRoundEndVOEnum.CharacterRelationRoundEndVOEnum
enum class CharacterRelationRoundEndVOEnum : uint8 {
	NewEnumerator8 = 0,
	NewEnumerator5 = 1,
	CharacterRelationRoundEndVOEnum_MAX = 2
};

