// UserDefinedEnum BombDefusingState.BombDefusingState
enum class BombDefusingState : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator3 = 2,
	BombDefusingState_MAX = 3
};

