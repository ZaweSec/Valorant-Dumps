// UserDefinedEnum MapID.MapID
enum class MapID : uint8 {
	NewEnumerator3 = 0,
	NewEnumerator4 = 1,
	NewEnumerator0 = 2,
	NewEnumerator1 = 3,
	NewEnumerator2 = 4,
	NewEnumerator6 = 5,
	NewEnumerator7 = 6,
	NewEnumerator8 = 7,
	NewEnumerator9 = 8,
	NewEnumerator10 = 9,
	NewEnumerator11 = 10,
	MapID_MAX = 11
};

