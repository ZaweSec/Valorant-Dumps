// UserDefinedEnum CharacterRelationEmoteVOEnum.CharacterRelationEmoteVOEnum
enum class CharacterRelationEmoteVOEnum : uint8 {
	NewEnumerator5 = 0,
	CharacterRelationEmoteVOEnum_MAX = 1
};

