// BlueprintGeneratedClass RoundEndHUDConfig.RoundEndHUDConfig_C
// Size: 0xc0 (Inherited: 0xc0)
struct URoundEndHUDConfig_C : UGameStateHUDConfig {
};

