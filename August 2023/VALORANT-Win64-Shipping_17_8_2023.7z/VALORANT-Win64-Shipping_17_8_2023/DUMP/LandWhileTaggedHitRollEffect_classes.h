// BlueprintGeneratedClass LandWhileTaggedHitRollEffect.LandWhileTaggedHitRollEffect_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct ULandWhileTaggedHitRollEffect_C : UMatineeCameraShake {
};

