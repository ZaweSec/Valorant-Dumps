// BlueprintGeneratedClass VoteOption_Draw_ContinueMatch.VoteOption_Draw_ContinueMatch_C
// Size: 0x168 (Inherited: 0x160)
struct UVoteOption_Draw_ContinueMatch_C : UGameplayVoteOptionBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x160(0x08)

	void AuthUpdateVotesNeeded(); // Function VoteOption_Draw_ContinueMatch.VoteOption_Draw_ContinueMatch_C.AuthUpdateVotesNeeded // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void OnSelected(); // Function VoteOption_Draw_ContinueMatch.VoteOption_Draw_ContinueMatch_C.OnSelected // (Event|Public|BlueprintEvent) // @ game+0x3c7c9e0
	void ExecuteUbergraph_VoteOption_Draw_ContinueMatch(int32_t EntryPoint); // Function VoteOption_Draw_ContinueMatch.VoteOption_Draw_ContinueMatch_C.ExecuteUbergraph_VoteOption_Draw_ContinueMatch // (Final|UbergraphFunction) // @ game+0x3c7c9e0
};

