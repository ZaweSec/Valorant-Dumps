// BlueprintGeneratedClass FXC_Impact_Gun_Heavy.FXC_Impact_Gun_Heavy_C
// Size: 0x678 (Inherited: 0x678)
struct AFXC_Impact_Gun_Heavy_C : AFXC_Impact_Base_C {
};

