// UserDefinedEnum Enum_AbilityInputs.Enum_AbilityInputs
enum class Enum_AbilityInputs : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator4 = 3,
	NewEnumerator5 = 4,
	NewEnumerator3 = 5,
	Enum_MAX = 6
};

