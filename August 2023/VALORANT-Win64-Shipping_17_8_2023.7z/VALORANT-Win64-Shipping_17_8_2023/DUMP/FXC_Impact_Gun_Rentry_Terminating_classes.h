// BlueprintGeneratedClass FXC_Impact_Gun_Rentry_Terminating.FXC_Impact_Gun_Rentry_Terminating_C
// Size: 0x678 (Inherited: 0x678)
struct AFXC_Impact_Gun_Rentry_Terminating_C : AFXC_Impact_Base_C {
};

