// UserDefinedEnum VOTacEnum.VOTacEnum
enum class VOTacEnum : uint8 {
	NewEnumerator3 = 0,
	NewEnumerator6 = 1,
	NewEnumerator10 = 2,
	NewEnumerator11 = 3,
	NewEnumerator12 = 4,
	NewEnumerator13 = 5,
	NewEnumerator14 = 6,
	NewEnumerator17 = 7,
	NewEnumerator18 = 8,
	NewEnumerator19 = 9,
	NewEnumerator20 = 10,
	NewEnumerator21 = 11,
	VOTacEnum_MAX = 12
};

