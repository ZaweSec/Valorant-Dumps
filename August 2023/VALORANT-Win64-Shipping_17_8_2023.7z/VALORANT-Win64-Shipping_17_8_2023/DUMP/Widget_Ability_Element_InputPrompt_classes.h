// WidgetBlueprintGeneratedClass Widget_Ability_Element_InputPrompt.Widget_Ability_Element_InputPrompt_C
// Size: 0x328 (Inherited: 0x2c8)
struct UWidget_Ability_Element_InputPrompt_C : UDesignableUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c8(0x08)
	struct UImage* ActionIcon; // 0x2d0(0x08)
	struct UOverlay* RootOverlay; // 0x2d8(0x08)
	struct UWidget_Ability_Element_InputPrompt_NoActionIcon_C* Widget_Ability_Element_InputPrompt_NoActionIcon; // 0x2e0(0x08)
	struct FStruct_Widget_Ability_Input CurrentInputStruct; // 0x2e8(0x38)
	struct UActionBindSet* Action Bind Set; // 0x320(0x08)

	void Construct(); // Function Widget_Ability_Element_InputPrompt.Widget_Ability_Element_InputPrompt_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3c7c9e0
	void SetupInputPrompt(struct FStruct_Widget_Ability_Input InputStruct); // Function Widget_Ability_Element_InputPrompt.Widget_Ability_Element_InputPrompt_C.SetupInputPrompt // (BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void Destruct(); // Function Widget_Ability_Element_InputPrompt.Widget_Ability_Element_InputPrompt_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3c7c9e0
	void OnActionBindingChanged(struct UActionBindSet* ActionBindSet, int32_t BindIndex, enum class EActionBindChangeSource ChangeSource, struct FName Character); // Function Widget_Ability_Element_InputPrompt.Widget_Ability_Element_InputPrompt_C.OnActionBindingChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void ExecuteUbergraph_Widget_Ability_Element_InputPrompt(int32_t EntryPoint); // Function Widget_Ability_Element_InputPrompt.Widget_Ability_Element_InputPrompt_C.ExecuteUbergraph_Widget_Ability_Element_InputPrompt // (Final|UbergraphFunction|HasDefaults) // @ game+0x3c7c9e0
};

