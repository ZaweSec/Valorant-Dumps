// UserDefinedStruct PlatformSpecificText.PlatformSpecificText
// Size: 0x38 (Inherited: 0x00)
struct FPlatformSpecificText {
	struct UTextBlock* TextBlockRef_2_2CEDA8E94661FEA25529828A474DD2BF; // 0x00(0x08)
	struct FText DesktopTextValue_5_C3A37B6F49A28CFDF8E4538CCA3BE2D7; // 0x08(0x18)
	struct FText ConsoleTextValue_7_7BC69907489AC88B4C96BF867FFA5BDB; // 0x20(0x18)
};

