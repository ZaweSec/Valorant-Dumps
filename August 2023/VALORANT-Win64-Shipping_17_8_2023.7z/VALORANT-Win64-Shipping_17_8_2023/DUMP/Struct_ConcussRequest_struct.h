// UserDefinedStruct Struct_ConcussRequest.Struct_ConcussRequest
// Size: 0x08 (Inherited: 0x00)
struct FStruct_ConcussRequest {
	float StartTime_2_4F29D4E1496B2629A7D15C976139758C; // 0x00(0x04)
	float Duration_4_034DCF344DD79907770560AFA38E59D7; // 0x04(0x04)
};

