// BlueprintGeneratedClass KillBannerNotificationType.KillBannerNotificationType_C
// Size: 0x70 (Inherited: 0x70)
struct UKillBannerNotificationType_C : UBaseGameplayNotificationType_C {
};

