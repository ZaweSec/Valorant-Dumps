// BlueprintGeneratedClass CountdownPing_GoHere.CountdownPing_GoHere_C
// Size: 0x6f8 (Inherited: 0x6f0)
struct ACountdownPing_GoHere_C : ACountdownPing_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x6f0(0x08)

	void ReceiveBeginPlay(); // Function CountdownPing_GoHere.CountdownPing_GoHere_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x3c7c9e0
	void ExecuteUbergraph_CountdownPing_GoHere(int32_t EntryPoint); // Function CountdownPing_GoHere.CountdownPing_GoHere_C.ExecuteUbergraph_CountdownPing_GoHere // (Final|UbergraphFunction) // @ game+0x3c7c9e0
};

