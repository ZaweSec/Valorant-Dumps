// Enum RGILatencyMarkers.ERGILatencyIntervalType
enum class ERGILatencyIntervalType : uint8 {
	Work = 0,
	Slop = 1,
	Count = 2,
	ERGILatencyIntervalType_MAX = 3
};

// Enum RGILatencyMarkers.ERGILatencyMarkerType
enum class ERGILatencyMarkerType : uint8 {
	SimulationStart = 0,
	SimulationEnd = 1,
	RenderSubmitStart = 2,
	RenderSubmitEnd = 3,
	PresentStart = 4,
	PresentEnd = 5,
	InputSample = 6,
	TriggerFlash = 7,
	DrawSceneCommandEnqueued = 8,
	DrawSceneCommandExecutionStart = 9,
	PresentUnblocked = 10,
	WaitForFrameEventCompletion = 11,
	RenderFenceStart = 12,
	RenderFenceEnd = 13,
	VALRenderSyncStart = 14,
	VALRenderSyncEnd = 15,
	Count = 16,
	ERGILatencyMarkerType_MAX = 17
};

// ScriptStruct RGILatencyMarkers.RGILatencyInterval
// Size: 0x03 (Inherited: 0x00)
struct FRGILatencyInterval {
	enum class ERGILatencyIntervalType IntervalType; // 0x00(0x01)
	enum class ERGILatencyMarkerType BeginMarker; // 0x01(0x01)
	enum class ERGILatencyMarkerType EndMarker; // 0x02(0x01)
};

