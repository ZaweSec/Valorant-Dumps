// WidgetBlueprintGeneratedClass HeadShot_Parent.HeadShot_Parent_C
// Size: 0x2d0 (Inherited: 0x2c8)
struct UHeadShot_Parent_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c8(0x08)

	void TriggerHeadshot(); // Function HeadShot_Parent.HeadShot_Parent_C.TriggerHeadshot // (BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void ExecuteUbergraph_HeadShot_Parent(int32_t EntryPoint); // Function HeadShot_Parent.HeadShot_Parent_C.ExecuteUbergraph_HeadShot_Parent // (Final|UbergraphFunction) // @ game+0x3c7c9e0
};

