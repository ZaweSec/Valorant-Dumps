// UserDefinedStruct Struct_AbilityChargeImages.Struct_AbilityChargeImages
// Size: 0x58 (Inherited: 0x00)
struct FStruct_AbilityChargeImages {
	int32_t MaxCharges_9_81DFAE5B4D49030608610D988C21A5AD; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TMap<int32_t, struct FStruct_AbilityChargeToTexture> ChargeTextures_13_7D875B7143ED8F064B25D281197B8B03; // 0x08(0x50)
};

