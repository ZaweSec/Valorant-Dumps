// BlueprintGeneratedClass BPAresGameInstance.BPAresGameInstance_C
// Size: 0x2b0 (Inherited: 0x2b0)
struct UBPAresGameInstance_C : UAresGameInstance {
};

