// UserDefinedEnum AbilitiesVOEnum.AbilitiesVOEnum
enum class AbilitiesVOEnum : uint8 {
	NewEnumerator16 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	NewEnumerator9 = 4,
	NewEnumerator10 = 5,
	NewEnumerator30 = 6,
	NewEnumerator31 = 7,
	NewEnumerator11 = 8,
	NewEnumerator17 = 9,
	NewEnumerator18 = 10,
	NewEnumerator19 = 11,
	NewEnumerator20 = 12,
	NewEnumerator21 = 13,
	NewEnumerator22 = 14,
	NewEnumerator23 = 15,
	NewEnumerator24 = 16,
	NewEnumerator25 = 17,
	NewEnumerator26 = 18,
	NewEnumerator27 = 19,
	NewEnumerator29 = 20,
	NewEnumerator28 = 21,
	AbilitiesVOEnum_MAX = 22
};

