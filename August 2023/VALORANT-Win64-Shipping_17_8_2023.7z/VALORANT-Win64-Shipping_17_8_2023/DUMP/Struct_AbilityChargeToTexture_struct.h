// UserDefinedStruct Struct_AbilityChargeToTexture.Struct_AbilityChargeToTexture
// Size: 0x10 (Inherited: 0x00)
struct FStruct_AbilityChargeToTexture {
	struct TArray<struct UTexture2D*> TextureArray_16_7D875B7143ED8F064B25D281197B8B03; // 0x00(0x10)
};

