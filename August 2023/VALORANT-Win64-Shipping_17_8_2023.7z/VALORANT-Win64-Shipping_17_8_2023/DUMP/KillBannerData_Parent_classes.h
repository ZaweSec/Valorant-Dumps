// BlueprintGeneratedClass KillBannerData_Parent.KillBannerData_Parent_C
// Size: 0xe0 (Inherited: 0x30)
struct UKillBannerData_Parent_C : UKillBannerData {
	struct FKillBannerStruct KillBannerData; // 0x30(0xb0)
};

