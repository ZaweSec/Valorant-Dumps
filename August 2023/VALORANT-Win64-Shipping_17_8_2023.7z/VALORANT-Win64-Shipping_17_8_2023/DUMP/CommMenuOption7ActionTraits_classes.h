// BlueprintGeneratedClass CommMenuOption7ActionTraits.CommMenuOption7ActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UCommMenuOption7ActionTraits_C : UActionTraits {
};

