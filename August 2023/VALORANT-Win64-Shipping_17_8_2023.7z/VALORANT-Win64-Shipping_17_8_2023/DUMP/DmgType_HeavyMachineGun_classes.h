// BlueprintGeneratedClass DmgType_HeavyMachineGun.DmgType_HeavyMachineGun_C
// Size: 0x170 (Inherited: 0x170)
struct UDmgType_HeavyMachineGun_C : UDmgType_HeavyMachineGunBase_C {
};

