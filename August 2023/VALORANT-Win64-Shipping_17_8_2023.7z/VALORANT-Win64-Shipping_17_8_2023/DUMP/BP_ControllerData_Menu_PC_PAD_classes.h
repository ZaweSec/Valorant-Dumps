// BlueprintGeneratedClass BP_ControllerData_Menu_PC_PAD.BP_ControllerData_Menu_PC_PAD_C
// Size: 0xc0 (Inherited: 0xc0)
struct UBP_ControllerData_Menu_PC_PAD_C : UCommonInputBaseControllerData {
};

