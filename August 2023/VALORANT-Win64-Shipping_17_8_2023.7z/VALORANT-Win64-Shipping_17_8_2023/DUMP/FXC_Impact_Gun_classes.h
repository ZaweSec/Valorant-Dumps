// BlueprintGeneratedClass FXC_Impact_Gun.FXC_Impact_Gun_C
// Size: 0x678 (Inherited: 0x678)
struct AFXC_Impact_Gun_C : AFXC_Impact_Base_C {
};

