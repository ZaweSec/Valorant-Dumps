// BlueprintGeneratedClass Magazine_Pistol_BasePistol.Magazine_Pistol_BasePistol_C
// Size: 0x588 (Inherited: 0x588)
struct AMagazine_Pistol_BasePistol_C : ABaseMagazine_C {
};

