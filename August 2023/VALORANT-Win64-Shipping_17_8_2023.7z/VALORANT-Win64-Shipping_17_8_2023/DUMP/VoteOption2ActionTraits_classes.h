// BlueprintGeneratedClass VoteOption2ActionTraits.VoteOption2ActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UVoteOption2ActionTraits_C : UActionTraits {
};

