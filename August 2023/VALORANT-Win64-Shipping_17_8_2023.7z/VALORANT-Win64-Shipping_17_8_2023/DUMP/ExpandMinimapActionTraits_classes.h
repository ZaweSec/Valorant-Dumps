// BlueprintGeneratedClass ExpandMinimapActionTraits.ExpandMinimapActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UExpandMinimapActionTraits_C : UActionTraits {
};

