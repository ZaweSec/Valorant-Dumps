// BlueprintGeneratedClass CommMenuOption4ActionTraits.CommMenuOption4ActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UCommMenuOption4ActionTraits_C : UActionTraits {
};

