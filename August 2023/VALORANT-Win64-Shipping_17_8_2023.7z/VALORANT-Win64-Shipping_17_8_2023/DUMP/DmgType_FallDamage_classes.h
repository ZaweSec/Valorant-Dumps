// BlueprintGeneratedClass DmgType_FallDamage.DmgType_FallDamage_C
// Size: 0x167 (Inherited: 0x167)
struct UDmgType_FallDamage_C : UDmgType_Base_C {
};

