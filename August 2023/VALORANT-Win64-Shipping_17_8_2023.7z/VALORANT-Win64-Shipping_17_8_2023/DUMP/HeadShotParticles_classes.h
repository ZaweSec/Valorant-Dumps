// WidgetBlueprintGeneratedClass HeadShotParticles.HeadShotParticles_C
// Size: 0x2e8 (Inherited: 0x2c8)
struct UHeadShotParticles_C : UUserWidget {
	struct UAnimatedSpriteWidget_C* AnimatedSpriteWidget; // 0x2c8(0x08)
	struct UAnimatedSpriteWidget_C* AnimatedSpriteWidget_C_2; // 0x2d0(0x08)
	struct UAnimatedSpriteWidget_C* AnimatedSpriteWidget_C_3; // 0x2d8(0x08)
	struct UAnimatedSpriteWidget_C* AnimatedSpriteWidget_C_4; // 0x2e0(0x08)

	void SetColor(struct FLinearColor Color); // Function HeadShotParticles.HeadShotParticles_C.SetColor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void BeginAnimation(); // Function HeadShotParticles.HeadShotParticles_C.BeginAnimation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
};

