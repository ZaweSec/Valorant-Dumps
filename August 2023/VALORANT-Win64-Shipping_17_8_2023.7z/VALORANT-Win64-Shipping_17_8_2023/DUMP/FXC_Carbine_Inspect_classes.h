// BlueprintGeneratedClass FXC_Carbine_Inspect.FXC_Carbine_Inspect_C
// Size: 0x582 (Inherited: 0x582)
struct AFXC_Carbine_Inspect_C : AFXC_Gun_Emote_C {
};

