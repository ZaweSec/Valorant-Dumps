// BlueprintGeneratedClass FXC_Carbine_FastEquip.FXC_Carbine_FastEquip_C
// Size: 0x580 (Inherited: 0x580)
struct AFXC_Carbine_FastEquip_C : AFXC_Gun_Equip_C {
};

