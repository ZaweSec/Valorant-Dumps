// BlueprintGeneratedClass Vote_Draw_Round3.Vote_Draw_Round3_C
// Size: 0x580 (Inherited: 0x580)
struct AVote_Draw_Round3_C : AVote_Draw_Base_C {
};

