// BlueprintGeneratedClass BaseShooterCamera.BaseShooterCamera_C
// Size: 0x2f20 (Inherited: 0x2f20)
struct ABaseShooterCamera_C : AShooterCamera {
};

