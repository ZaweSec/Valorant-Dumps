// BlueprintGeneratedClass FXC_Impact_Melee_5.FXC_Impact_Melee_4_C
// Size: 0x654 (Inherited: 0x654)
struct AFXC_Impact_Melee_4_C : AFXC_Impact_Melee_C {
};

