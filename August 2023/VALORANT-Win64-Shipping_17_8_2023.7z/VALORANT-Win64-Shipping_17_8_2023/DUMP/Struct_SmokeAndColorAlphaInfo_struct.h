// UserDefinedStruct Struct_SmokeAndColorAlphaInfo.Struct_SmokeAndColorAlphaInfo
// Size: 0x24 (Inherited: 0x00)
struct FStruct_SmokeAndColorAlphaInfo {
	float Alpha_6_28C2CE404B411892116FD8BA97973F3C; // 0x00(0x04)
	struct FLinearColor ColorMain_13_87DB8F5F481416DDC07C0090FA5FAC66; // 0x04(0x10)
	struct FLinearColor ColorFringe_14_1EBF493248A2A8B7D15FA7AF8496DC2A; // 0x14(0x10)
};

