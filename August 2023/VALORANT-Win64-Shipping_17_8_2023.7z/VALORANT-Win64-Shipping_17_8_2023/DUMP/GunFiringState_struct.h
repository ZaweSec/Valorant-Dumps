// UserDefinedEnum GunFiringState.GunFiringState
enum class GunFiringState : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	GunFiringState_MAX = 3
};

