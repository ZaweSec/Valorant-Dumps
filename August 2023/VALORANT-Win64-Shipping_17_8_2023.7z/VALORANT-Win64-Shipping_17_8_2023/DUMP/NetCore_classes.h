// Class NetCore.NetAnalyticsAggregatorConfig
// Size: 0x40 (Inherited: 0x30)
struct UNetAnalyticsAggregatorConfig : UObject {
	struct TArray<struct FNetAnalyticsDataConfig> NetAnalyticsData; // 0x30(0x10)
};

