// BlueprintGeneratedClass ObservePlayer3ActionTraits.ObservePlayer3ActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UObservePlayer3ActionTraits_C : UActionTraits {
};

