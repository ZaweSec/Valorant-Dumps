// BlueprintGeneratedClass PickedUpBombNotificationType.PickedUpBombNotificationType_C
// Size: 0x88 (Inherited: 0x80)
struct UPickedUpBombNotificationType_C : UBaseBombEventNotificationType_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x80(0x08)

	void HandleBombPickedUp(struct AShooterCharacter* NewBombHolder); // Function PickedUpBombNotificationType.PickedUpBombNotificationType_C.HandleBombPickedUp // (BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void ExecuteUbergraph_PickedUpBombNotificationType(int32_t EntryPoint); // Function PickedUpBombNotificationType.PickedUpBombNotificationType_C.ExecuteUbergraph_PickedUpBombNotificationType // (Final|UbergraphFunction) // @ game+0x3c7c9e0
};

