// UserDefinedEnum InWorldTeamVisionActorState.InWorldTeamVisionActorState
enum class InWorldTeamVisionActorState : uint8 {
	NewEnumerator4 = 0,
	NewEnumerator3 = 1,
	NewEnumerator0 = 2,
	NewEnumerator2 = 3,
	InWorldTeamVisionActorState_MAX = 4
};

