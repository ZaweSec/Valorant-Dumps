// BlueprintGeneratedClass FXC_Impact_Melee_3.FXC_Impact_Melee_2_C
// Size: 0x654 (Inherited: 0x654)
struct AFXC_Impact_Melee_2_C : AFXC_Impact_Melee_C {
};

