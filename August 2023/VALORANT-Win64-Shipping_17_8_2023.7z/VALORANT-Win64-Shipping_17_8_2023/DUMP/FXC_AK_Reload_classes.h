// BlueprintGeneratedClass FXC_AK_Reload.FXC_AK_Reload_C
// Size: 0x588 (Inherited: 0x588)
struct AFXC_AK_Reload_C : AFXC_Gun_Reload_C {
};

