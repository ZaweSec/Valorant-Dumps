// BlueprintGeneratedClass ObservePlayer10ActionTraits.ObservePlayer10ActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UObservePlayer10ActionTraits_C : UActionTraits {
};

