// BlueprintGeneratedClass FXC_Ascender_MoveDown.FXC_Ascender_MoveDown_C
// Size: 0x550 (Inherited: 0x540)
struct AFXC_Ascender_MoveDown_C : AEffectContainer {
	struct UComp_FXC_AudioLoop_C* Comp_FXC_AudioLoop; // 0x540(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x548(0x08)
};

