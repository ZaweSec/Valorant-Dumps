// BlueprintGeneratedClass FXC_DefuseBomb_DefuserStop.FXC_DefuseBomb_DefuserStop_C
// Size: 0x550 (Inherited: 0x540)
struct AFXC_DefuseBomb_DefuserStop_C : AEffectContainer {
	struct UComp_FXC_PlayAnimation_ShooterCharacter_C* Comp_FXC_PlayAnimation_ShooterCharacter; // 0x540(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x548(0x08)
};

