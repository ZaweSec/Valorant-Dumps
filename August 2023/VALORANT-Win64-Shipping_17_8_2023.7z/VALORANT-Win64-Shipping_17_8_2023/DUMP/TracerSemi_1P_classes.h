// BlueprintGeneratedClass TracerSemi_1P.TracerSemi_1P_C
// Size: 0x668 (Inherited: 0x668)
struct ATracerSemi_1P_C : ABaseDetachedTracer_C {
};

