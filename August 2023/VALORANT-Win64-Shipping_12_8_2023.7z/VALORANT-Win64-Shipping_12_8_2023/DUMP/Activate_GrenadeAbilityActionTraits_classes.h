// BlueprintGeneratedClass Activate_GrenadeAbilityActionTraits.Activate_GrenadeAbilityActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UActivate_GrenadeAbilityActionTraits_C : UActionTraits {
};

