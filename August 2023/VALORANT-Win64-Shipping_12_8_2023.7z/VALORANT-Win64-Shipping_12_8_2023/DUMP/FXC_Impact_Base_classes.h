// BlueprintGeneratedClass FXC_Impact_Base.FXC_Impact_Base_C
// Size: 0x678 (Inherited: 0x670)
struct AFXC_Impact_Base_C : AAresImpactEffect {
	struct USceneComponent* DefaultSceneRoot; // 0x670(0x08)
};

