// BlueprintGeneratedClass UIDirector.UIDirector_C
// Size: 0x60 (Inherited: 0x58)
struct UUIDirector_C : UAresUIDirector {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x58(0x08)

	void ReceiveBeginPlay(); // Function UIDirector.UIDirector_C.ReceiveBeginPlay // (BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void ReceiveTick(float DeltaSeconds); // Function UIDirector.UIDirector_C.ReceiveTick // (BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void ExecuteUbergraph_UIDirector(int32_t EntryPoint); // Function UIDirector.UIDirector_C.ExecuteUbergraph_UIDirector // (Final|UbergraphFunction) // @ game+0x3c7c9e0
};

