// BlueprintGeneratedClass WallPen_VeryLow.WallPen_VeryLow_C
// Size: 0x48 (Inherited: 0x48)
struct UWallPen_VeryLow_C : UAresWallPenetration {
};

