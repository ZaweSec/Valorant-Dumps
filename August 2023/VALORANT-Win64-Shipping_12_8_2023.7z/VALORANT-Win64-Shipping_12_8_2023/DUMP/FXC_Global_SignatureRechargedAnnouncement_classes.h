// BlueprintGeneratedClass FXC_Global_SignatureRechargedAnnouncement.FXC_Global_SignatureRechargedAnnouncement_C
// Size: 0x550 (Inherited: 0x540)
struct AFXC_Global_SignatureRechargedAnnouncement_C : AEffectContainer {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x540(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x548(0x08)

	void StartEffect(struct AActor* Target, struct UObject* Context, float StartTime, bool FirstPerson); // Function FXC_Global_SignatureRechargedAnnouncement.FXC_Global_SignatureRechargedAnnouncement_C.StartEffect // (Event|Public|BlueprintEvent) // @ game+0x3c7c9e0
	void ExecuteUbergraph_FXC_Global_SignatureRechargedAnnouncement(int32_t EntryPoint); // Function FXC_Global_SignatureRechargedAnnouncement.FXC_Global_SignatureRechargedAnnouncement_C.ExecuteUbergraph_FXC_Global_SignatureRechargedAnnouncement // (Final|UbergraphFunction) // @ game+0x3c7c9e0
};

