// BlueprintGeneratedClass VOEmoteNoActionTraits.VOEmoteNoActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UVOEmoteNoActionTraits_C : UActionTraits {
};

