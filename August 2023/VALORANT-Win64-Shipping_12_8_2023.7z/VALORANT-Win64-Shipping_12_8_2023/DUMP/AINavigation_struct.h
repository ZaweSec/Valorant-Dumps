// Enum AINavigation.ENavAreaFlag
enum class ENavAreaFlag : uint8 {
	Default = 0,
	Jump = 1,
	Crouch = 2,
	Teleport = 3,
	Drop = 4,
	Fly = 5,
	ENavAreaFlag_MAX = 6
};

// ScriptStruct AINavigation.NavQuerierClassOverride
// Size: 0x20 (Inherited: 0x00)
struct FNavQuerierClassOverride {
	struct FString QuerierClassName; // 0x00(0x10)
	struct TArray<struct FNavigationFilterArea> Overrides; // 0x10(0x10)
};

