// BlueprintGeneratedClass FXC_AK_Equip.FXC_AK_Equip_C
// Size: 0x580 (Inherited: 0x580)
struct AFXC_AK_Equip_C : AFXC_Gun_Equip_C {
};

