// BlueprintGeneratedClass InRoundHUDConfig.InRoundHUDConfig_C
// Size: 0xc0 (Inherited: 0xc0)
struct UInRoundHUDConfig_C : UGameStateHUDConfig {
};

