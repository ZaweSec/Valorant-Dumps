// BlueprintGeneratedClass WallPenGlobals.WallPenGlobals_C
// Size: 0x8a0 (Inherited: 0x8a0)
struct UWallPenGlobals_C : UAresWallPenetrationGlobals {
};

