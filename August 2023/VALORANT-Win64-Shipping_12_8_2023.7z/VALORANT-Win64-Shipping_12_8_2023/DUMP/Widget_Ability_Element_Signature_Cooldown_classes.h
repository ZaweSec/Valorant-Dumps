// WidgetBlueprintGeneratedClass Widget_Ability_Element_Signature_Cooldown.Widget_Ability_Element_Signature_Cooldown_C
// Size: 0x440 (Inherited: 0x3e0)
struct UWidget_Ability_Element_Signature_Cooldown_C : UWidget_Ability_Parent_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3e0(0x08)
	struct UWidgetAnimation* SignatureCharge; // 0x3e8(0x08)
	struct UWidgetAnimation* Equipped; // 0x3f0(0x08)
	struct UWidgetAnimation* Ready; // 0x3f8(0x08)
	struct UWidgetAnimation* Normal; // 0x400(0x08)
	struct UTextBlock* CooldownSeconds; // 0x408(0x08)
	float CooldownUpdateRate; // 0x410(0x04)
	char pad_414[0x4]; // 0x414(0x04)
	struct FTimerHandle CooldownUpdateHandle; // 0x418(0x08)
	struct UActorComponent* CooldownInterface; // 0x420(0x08)
	struct UAbilityRechargeCooldownComponent* RechargeCooldownComponent; // 0x428(0x08)
	float MinRechargeCooldownDisplayTime; // 0x430(0x04)
	float RemainingCooldownTime; // 0x434(0x04)
	struct FTimerHandle ManualCooldownTimer; // 0x438(0x08)

	void CooldownComplete(); // Function Widget_Ability_Element_Signature_Cooldown.Widget_Ability_Element_Signature_Cooldown_C.CooldownComplete // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void UpdateManualCooldown(); // Function Widget_Ability_Element_Signature_Cooldown.Widget_Ability_Element_Signature_Cooldown_C.UpdateManualCooldown // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void ManualCooldown(float TimeRemaining, bool IsInitialCall); // Function Widget_Ability_Element_Signature_Cooldown.Widget_Ability_Element_Signature_Cooldown_C.ManualCooldown // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void OnStartWidget(); // Function Widget_Ability_Element_Signature_Cooldown.Widget_Ability_Element_Signature_Cooldown_C.OnStartWidget // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3c7c9e0
	void Update Cooldown(); // Function Widget_Ability_Element_Signature_Cooldown.Widget_Ability_Element_Signature_Cooldown_C.Update Cooldown // (BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void OnCooldownStarted(struct UEquippableEventBase* Event); // Function Widget_Ability_Element_Signature_Cooldown.Widget_Ability_Element_Signature_Cooldown_C.OnCooldownStarted // (BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void UpdateRechargeCooldown(struct UAbilityRechargeCooldownComponent* CooldownComponent); // Function Widget_Ability_Element_Signature_Cooldown.Widget_Ability_Element_Signature_Cooldown_C.UpdateRechargeCooldown // (BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void CallRechargeCooldownUpdate(); // Function Widget_Ability_Element_Signature_Cooldown.Widget_Ability_Element_Signature_Cooldown_C.CallRechargeCooldownUpdate // (BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void OnActivateWidget(); // Function Widget_Ability_Element_Signature_Cooldown.Widget_Ability_Element_Signature_Cooldown_C.OnActivateWidget // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3c7c9e0
	void OnStopWidget(); // Function Widget_Ability_Element_Signature_Cooldown.Widget_Ability_Element_Signature_Cooldown_C.OnStopWidget // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3c7c9e0
	void OnDeactivateWidget(); // Function Widget_Ability_Element_Signature_Cooldown.Widget_Ability_Element_Signature_Cooldown_C.OnDeactivateWidget // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x3c7c9e0
	void ExecuteUbergraph_Widget_Ability_Element_Signature_Cooldown(int32_t EntryPoint); // Function Widget_Ability_Element_Signature_Cooldown.Widget_Ability_Element_Signature_Cooldown_C.ExecuteUbergraph_Widget_Ability_Element_Signature_Cooldown // (Final|UbergraphFunction|HasDefaults) // @ game+0x3c7c9e0
};

