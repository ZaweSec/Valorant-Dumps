// BlueprintGeneratedClass EquippableEvent_CooldownStarted.EquippableEvent_CooldownStarted_C
// Size: 0x44 (Inherited: 0x40)
struct UEquippableEvent_CooldownStarted_C : UEquippableEventBase {
	float Duration; // 0x40(0x04)
};

