// Class ImgMediaEngine.ImgMediaPlaybackComponent
// Size: 0x110 (Inherited: 0xe8)
struct UImgMediaPlaybackComponent : UActorComponent {
	float Width; // 0xe8(0x04)
	float LODBias; // 0xec(0x04)
	char pad_F0[0x20]; // 0xf0(0x20)
};

