// BlueprintGeneratedClass EquippablePickupProjectile.EquippablePickupProjectile_C
// Size: 0x584 (Inherited: 0x510)
struct AEquippablePickupProjectile_C : AAresDroppedEquippable {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)
	struct URoundPersistenceComponent* RoundPersistence; // 0x518(0x08)
	struct UProjectileStopOnFloorComponent* ProjectileStopOnFloor; // 0x520(0x08)
	struct USphereComponent* Collision; // 0x528(0x08)
	struct USpawnActorProjectileEffectComponent* SpawnActorProjectileEffect; // 0x530(0x08)
	struct UProjectileBounceComponent* ProjectileBounce; // 0x538(0x08)
	struct UFiniteSpeedMovementComponent* FiniteSpeedMovement; // 0x540(0x08)
	struct AAresEquippable* MyEquippable_1; // 0x548(0x08)
	struct FRotator SpinSpeed; // 0x550(0x0c)
	struct FVector InitialStartLocation; // 0x55c(0x0c)
	float BombOffMapCheckDelay_Seconds; // 0x568(0x04)
	char pad_56C[0x4]; // 0x56c(0x04)
	struct UObject* BounceSound; // 0x570(0x08)
	struct FVector LastKnownOwnerWalkingLocation; // 0x578(0x0c)

	void StopGunSkinVO(struct UAresAudioComponent* AresAudioComponent, struct AGun_C* Gun, struct UAudBasePawnVOComponent_C* AudBasePawnVOComponent); // Function EquippablePickupProjectile.EquippablePickupProjectile_C.StopGunSkinVO // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void ReceiveBeginPlay(); // Function EquippablePickupProjectile.EquippablePickupProjectile_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x3c7c9e0
	void BndEvt__SpawnActorProjectileEffect_K2Node_ComponentBoundEvent_0_OnSpawnActorSignature__DelegateSignature(struct AActor* Actor); // Function EquippablePickupProjectile.EquippablePickupProjectile_C.BndEvt__SpawnActorProjectileEffect_K2Node_ComponentBoundEvent_0_OnSpawnActorSignature__DelegateSignature // (BlueprintEvent) // @ game+0x3c7c9e0
	void BndEvt__ProjectileBounce_K2Node_ComponentBoundEvent_1_OnProjectileBounceDelegate__DelegateSignature(struct FHitResult& ImpactResult, struct FVector& ImpactVelocity); // Function EquippablePickupProjectile.EquippablePickupProjectile_C.BndEvt__ProjectileBounce_K2Node_ComponentBoundEvent_1_OnProjectileBounceDelegate__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x3c7c9e0
	void AuthInitialize(struct AAresEquippable* DroppedEquippable, struct FVector DropVector); // Function EquippablePickupProjectile.EquippablePickupProjectile_C.AuthInitialize // (BlueprintAuthorityOnly|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3c7c9e0
	void ReceiveTick(float DeltaSeconds); // Function EquippablePickupProjectile.EquippablePickupProjectile_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x3c7c9e0
	void ExecuteUbergraph_EquippablePickupProjectile(int32_t EntryPoint); // Function EquippablePickupProjectile.EquippablePickupProjectile_C.ExecuteUbergraph_EquippablePickupProjectile // (Final|UbergraphFunction|HasDefaults) // @ game+0x3c7c9e0
};

