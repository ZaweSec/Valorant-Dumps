// BlueprintGeneratedClass DmgType_PistolBase.DmgType_PistolBase_C
// Size: 0x170 (Inherited: 0x170)
struct UDmgType_PistolBase_C : UDmgType_GunBase_C {
};

