// BlueprintGeneratedClass Buff_Assist_Concuss.Buff_Assist_Concuss_C
// Size: 0x990 (Inherited: 0x990)
struct UBuff_Assist_Concuss_C : UAresGameplayBuff {
};

