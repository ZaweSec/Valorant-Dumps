// BlueprintGeneratedClass VoteOption0ActionTraits.VoteOption0ActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UVoteOption0ActionTraits_C : UActionTraits {
};

