// BlueprintGeneratedClass Buff_Downed_DeathResist.Buff_Downed_DeathResist_C
// Size: 0x990 (Inherited: 0x990)
struct UBuff_Downed_DeathResist_C : UAresGameplayBuff {
};

