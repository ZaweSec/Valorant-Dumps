// BlueprintGeneratedClass FXC_CompleteOrb_AtLocation.FXC_CompleteOrb_AtLocation_C
// Size: 0x550 (Inherited: 0x540)
struct AFXC_CompleteOrb_AtLocation_C : AEffectContainer {
	struct UParticleSystemComponent* ParticleSystem; // 0x540(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x548(0x08)
};

