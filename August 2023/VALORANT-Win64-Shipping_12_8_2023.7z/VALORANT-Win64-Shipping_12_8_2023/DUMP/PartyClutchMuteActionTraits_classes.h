// BlueprintGeneratedClass PartyClutchMuteActionTraits.PartyClutchMuteActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UPartyClutchMuteActionTraits_C : UActionTraits {
};

