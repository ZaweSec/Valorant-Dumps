// BlueprintGeneratedClass Vote_Draw_Round1.Vote_Draw_Round1_C
// Size: 0x580 (Inherited: 0x580)
struct AVote_Draw_Round1_C : AVote_Draw_Base_C {
};

