// BlueprintGeneratedClass NeedSupportPing.NeedSupportPing_C
// Size: 0x6d0 (Inherited: 0x6d0)
struct ANeedSupportPing_C : ABasePing_C {
};

