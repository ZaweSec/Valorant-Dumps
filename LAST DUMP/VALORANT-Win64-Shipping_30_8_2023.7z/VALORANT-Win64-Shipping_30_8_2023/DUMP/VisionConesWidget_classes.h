// WidgetBlueprintGeneratedClass VisionConesWidget.VisionConesWidget_C
// Size: 0x340 (Inherited: 0x340)
struct UVisionConesWidget_C : UAresVisionConesWidget {
};

