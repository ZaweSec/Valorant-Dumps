// BlueprintGeneratedClass Init.Init_C
// Size: 0x3d8 (Inherited: 0x3d8)
struct AInit_C : ALevelScriptActor {
};

