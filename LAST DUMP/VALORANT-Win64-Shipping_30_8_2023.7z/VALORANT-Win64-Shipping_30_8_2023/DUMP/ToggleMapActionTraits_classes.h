// BlueprintGeneratedClass ToggleMapActionTraits.ToggleMapActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UToggleMapActionTraits_C : UActionTraits {
};

