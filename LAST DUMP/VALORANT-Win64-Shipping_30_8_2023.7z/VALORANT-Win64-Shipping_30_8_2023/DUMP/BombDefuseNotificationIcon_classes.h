// WidgetBlueprintGeneratedClass BombDefuseNotificationIcon.BombDefuseNotificationIcon_C
// Size: 0x338 (Inherited: 0x338)
struct UBombDefuseNotificationIcon_C : UBombIconNotificationWidget_C {
};

