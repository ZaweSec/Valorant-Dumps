// UserDefinedStruct MaterialList.MaterialList
// Size: 0x10 (Inherited: 0x00)
struct FMaterialList {
	struct TArray<struct UMaterialInterface*> Mat_3_ED211C8E443D3D813E871AB20914FA3F; // 0x00(0x10)
};

