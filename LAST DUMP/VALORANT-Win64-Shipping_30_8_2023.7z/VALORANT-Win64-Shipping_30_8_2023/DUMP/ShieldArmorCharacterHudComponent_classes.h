// BlueprintGeneratedClass ShieldArmorCharacterHudComponent.ShieldArmorCharacterHudComponent_C
// Size: 0x138 (Inherited: 0x100)
struct UShieldArmorCharacterHudComponent_C : UCharacterHudComponent {
	struct FSlateColor armorTextColor; // 0x100(0x28)
	struct UTexture* ArmorIcon; // 0x128(0x08)
	struct UTexture* ArmorIcon_Teemo; // 0x130(0x08)

	void GetCharacterHudDrawValues(struct FCharacterHudDrawValues& Out); // Function ShieldArmorCharacterHudComponent.ShieldArmorCharacterHudComponent_C.GetCharacterHudDrawValues // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3cb77f0
};

