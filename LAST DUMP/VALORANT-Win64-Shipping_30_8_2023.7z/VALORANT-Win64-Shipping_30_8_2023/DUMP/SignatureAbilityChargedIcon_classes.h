// WidgetBlueprintGeneratedClass SignatureAbilityChargedIcon.SignatureAbilityChargedIcon_C
// Size: 0x358 (Inherited: 0x358)
struct USignatureAbilityChargedIcon_C : UBaseAbilityChargedIcon_C {
};

