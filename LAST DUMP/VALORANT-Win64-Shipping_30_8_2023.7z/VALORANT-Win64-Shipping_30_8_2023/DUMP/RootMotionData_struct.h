// UserDefinedStruct RootMotionData.RootMotionData
// Size: 0x10 (Inherited: 0x00)
struct FRootMotionData {
	struct FVector Velocity_2_5798AAB44F803ACA13528B8ED9CB2867; // 0x00(0x0c)
	float Duration_5_27A183084E4207E9A98D9CBEC79BE20A; // 0x0c(0x04)
};

