// BlueprintGeneratedClass UseRemoveCleanseObjectActionTraits.UseRemoveCleanseObjectActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UUseRemoveCleanseObjectActionTraits_C : UActionTraits {
};

