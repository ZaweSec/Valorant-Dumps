// BlueprintGeneratedClass CommMenuOption5ActionTraits.CommMenuOption5ActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UCommMenuOption5ActionTraits_C : UActionTraits {
};

