// BlueprintGeneratedClass Comp_FXC_HUD_WarningMessage_PreRound.Comp_FXC_HUD_WarningMessage_PreRound_C
// Size: 0x1a8 (Inherited: 0x134)
struct UComp_FXC_HUD_WarningMessage_PreRound_C : UComp_FXC_HUD_C {
	char pad_134[0x4]; // 0x134(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x138(0x08)
	int32_t LifeSpan; // 0x140(0x04)
	char pad_144[0x4]; // 0x144(0x04)
	struct FText MessageText; // 0x148(0x18)
	struct FText SubText; // 0x160(0x18)
	struct UAkAudioEvent* AkEvent; // 0x178(0x08)
	bool Continuous; // 0x180(0x01)
	char pad_181[0x3]; // 0x181(0x03)
	float PulseTime; // 0x184(0x04)
	bool HideExistingWarnings; // 0x188(0x01)
	bool LoopAudio; // 0x189(0x01)
	bool PlayIntroAndOutro; // 0x18a(0x01)
	char pad_18B[0x5]; // 0x18b(0x05)
	struct FText Message Two Text; // 0x190(0x18)

	void SetupHUD_Event(struct UUserWidget* InHUD); // Function Comp_FXC_HUD_WarningMessage_PreRound.Comp_FXC_HUD_WarningMessage_PreRound_C.SetupHUD_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x3cb77f0
	void ManualRemoveHUD(); // Function Comp_FXC_HUD_WarningMessage_PreRound.Comp_FXC_HUD_WarningMessage_PreRound_C.ManualRemoveHUD // (BlueprintCallable|BlueprintEvent) // @ game+0x3cb77f0
	void ExecuteUbergraph_Comp_FXC_HUD_WarningMessage_PreRound(int32_t EntryPoint); // Function Comp_FXC_HUD_WarningMessage_PreRound.Comp_FXC_HUD_WarningMessage_PreRound_C.ExecuteUbergraph_Comp_FXC_HUD_WarningMessage_PreRound // (Final|UbergraphFunction|HasDefaults) // @ game+0x3cb77f0
};

