// BlueprintGeneratedClass NotifyState_HideEquippable.NotifyState_HideEquippable_C
// Size: 0x38 (Inherited: 0x38)
struct UNotifyState_HideEquippable_C : UAnimNotifyState {

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function NotifyState_HideEquippable.NotifyState_HideEquippable_C.Received_NotifyEnd // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3cb77f0
	void HideEquippable(struct USkeletalMeshComponent* Mesh, struct UAnimSequenceBase* Animation, bool Hidden); // Function NotifyState_HideEquippable.NotifyState_HideEquippable_C.HideEquippable // (Public|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3cb77f0
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function NotifyState_HideEquippable.NotifyState_HideEquippable_C.Received_NotifyBegin // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3cb77f0
};

