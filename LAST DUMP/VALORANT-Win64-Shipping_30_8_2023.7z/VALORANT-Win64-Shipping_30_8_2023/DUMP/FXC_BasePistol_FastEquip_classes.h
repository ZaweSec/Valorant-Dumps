// BlueprintGeneratedClass FXC_BasePistol_FastEquip.FXC_BasePistol_FastEquip_C
// Size: 0x580 (Inherited: 0x580)
struct AFXC_BasePistol_FastEquip_C : AFXC_Gun_Equip_C {
};

