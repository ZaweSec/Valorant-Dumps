// WidgetBlueprintGeneratedClass StaticRingNotificationWidget.StaticRingNotificationWidget_C
// Size: 0x348 (Inherited: 0x310)
struct UStaticRingNotificationWidget_C : UBaseGameplayNotificationWidget_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct UImage* RingImage; // 0x318(0x08)
	struct FSlateColor RingColor; // 0x320(0x28)

	void PreConstruct(bool IsDesignTime); // Function StaticRingNotificationWidget.StaticRingNotificationWidget_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3cb77f0
	void ExecuteUbergraph_StaticRingNotificationWidget(int32_t EntryPoint); // Function StaticRingNotificationWidget.StaticRingNotificationWidget_C.ExecuteUbergraph_StaticRingNotificationWidget // (Final|UbergraphFunction) // @ game+0x3cb77f0
};

