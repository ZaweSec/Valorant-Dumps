// BlueprintGeneratedClass FXC_Melee_Assassin_FastEquip.FXC_Melee_Assassin_FastEquip_C
// Size: 0x568 (Inherited: 0x558)
struct AFXC_Melee_Assassin_FastEquip_C : AFXC_Melee_Equip_C {
	struct UComp_FXC_AudioBasic_C* Comp_FXC_AudioBasic; // 0x558(0x08)
	struct UComp_FXC_PlayAnimation_ShooterCharacter_C* Core_Melee_S0_FastEquip_Animation; // 0x560(0x08)
};

