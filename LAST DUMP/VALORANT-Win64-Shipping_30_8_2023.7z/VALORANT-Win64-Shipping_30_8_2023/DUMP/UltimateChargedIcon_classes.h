// WidgetBlueprintGeneratedClass UltimateChargedIcon.UltimateChargedIcon_C
// Size: 0x358 (Inherited: 0x358)
struct UUltimateChargedIcon_C : UBaseAbilityChargedIcon_C {
};

