// BlueprintGeneratedClass FXC_JumpLaunch.FXC_JumpLaunch_C
// Size: 0x578 (Inherited: 0x578)
struct AFXC_JumpLaunch_C : AFXC_GroundSound_C {
};

