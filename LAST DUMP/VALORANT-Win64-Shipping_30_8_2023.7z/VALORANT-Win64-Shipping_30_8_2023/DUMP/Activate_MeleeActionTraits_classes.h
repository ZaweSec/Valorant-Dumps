// BlueprintGeneratedClass Activate_MeleeActionTraits.Activate_MeleeActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UActivate_MeleeActionTraits_C : UActionTraits {
};

