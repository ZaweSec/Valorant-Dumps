// BlueprintGeneratedClass BaseMapPrimaryAsset.BaseMapPrimaryAsset_C
// Size: 0xd1 (Inherited: 0xd0)
struct UBaseMapPrimaryAsset_C : UMapDataAsset {
	enum class MapID MapID; // 0xd0(0x01)
};

