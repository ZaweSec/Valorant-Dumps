// BlueprintGeneratedClass SniperTracerTrailLever.SniperTracerTrailLever_C
// Size: 0x648 (Inherited: 0x640)
struct ASniperTracerTrailLever_C : AAresContrailTracer {
	struct UAudioComponent* Audio; // 0x640(0x08)
};

