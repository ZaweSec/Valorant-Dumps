// BlueprintGeneratedClass FXC_BasePistol_InstantEquip.FXC_BasePistol_InstantEquip_C
// Size: 0x580 (Inherited: 0x580)
struct AFXC_BasePistol_InstantEquip_C : AFXC_Gun_Equip_C {
};

