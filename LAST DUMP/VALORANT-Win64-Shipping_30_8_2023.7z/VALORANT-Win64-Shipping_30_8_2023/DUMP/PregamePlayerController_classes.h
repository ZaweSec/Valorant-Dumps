// BlueprintGeneratedClass PregamePlayerController.PregamePlayerController_C
// Size: 0x9b8 (Inherited: 0x9b8)
struct APregamePlayerController_C : APregamePlayerController {
};

