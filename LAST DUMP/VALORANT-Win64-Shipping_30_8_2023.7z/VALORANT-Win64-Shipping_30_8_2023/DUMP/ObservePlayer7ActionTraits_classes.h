// BlueprintGeneratedClass ObservePlayer7ActionTraits.ObservePlayer7ActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UObservePlayer7ActionTraits_C : UActionTraits {
};

