// BlueprintGeneratedClass FXC_Melee_Tactical_FastEquip.FXC_Melee_Tactical_FastEquip_C
// Size: 0x568 (Inherited: 0x568)
struct AFXC_Melee_Tactical_FastEquip_C : AFXC_Melee_Assassin_FastEquip_C {
};

