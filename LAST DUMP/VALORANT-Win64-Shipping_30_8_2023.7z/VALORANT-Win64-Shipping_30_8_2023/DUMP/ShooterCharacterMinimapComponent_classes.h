// BlueprintGeneratedClass ShooterCharacterMinimapComponent.ShooterCharacterMinimapComponent_C
// Size: 0x540 (Inherited: 0x540)
struct UShooterCharacterMinimapComponent_C : UShooterCharacterMinimapComponent {
};

