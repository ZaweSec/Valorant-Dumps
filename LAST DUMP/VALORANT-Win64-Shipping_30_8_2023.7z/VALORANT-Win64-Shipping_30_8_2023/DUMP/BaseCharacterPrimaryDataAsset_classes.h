// BlueprintGeneratedClass BaseCharacterPrimaryDataAsset.BaseCharacterPrimaryDataAsset_C
// Size: 0x1c9 (Inherited: 0x1c8)
struct UBaseCharacterPrimaryDataAsset_C : UCharacterDataAsset {
	enum class CharacterID CharacterID; // 0x1c8(0x01)
};

