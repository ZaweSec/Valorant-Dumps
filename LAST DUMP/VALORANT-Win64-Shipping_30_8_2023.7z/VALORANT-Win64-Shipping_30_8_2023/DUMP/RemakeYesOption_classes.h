// BlueprintGeneratedClass RemakeYesOption.RemakeYesOption_C
// Size: 0x168 (Inherited: 0x160)
struct URemakeYesOption_C : UGameplayVoteOptionBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x160(0x08)

	void OnSelected(); // Function RemakeYesOption.RemakeYesOption_C.OnSelected // (Event|Public|BlueprintEvent) // @ game+0x3cb77f0
	void ExecuteUbergraph_RemakeYesOption(int32_t EntryPoint); // Function RemakeYesOption.RemakeYesOption_C.ExecuteUbergraph_RemakeYesOption // (Final|UbergraphFunction|HasDefaults) // @ game+0x3cb77f0
};

