// BlueprintGeneratedClass ToggleMouseCursorActionTraits.ToggleMouseCursorActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UToggleMouseCursorActionTraits_C : UActionTraits {
};

