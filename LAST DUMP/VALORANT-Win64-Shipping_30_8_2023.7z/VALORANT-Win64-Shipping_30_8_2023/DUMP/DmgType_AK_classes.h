// BlueprintGeneratedClass DmgType_AK.DmgType_AK_C
// Size: 0x170 (Inherited: 0x170)
struct UDmgType_AK_C : UDmgType_RifleBase_C {
};

