// UserDefinedStruct MatchResultPlayerRoundScores.MatchResultPlayerRoundScores
// Size: 0x54 (Inherited: 0x00)
struct FMatchResultPlayerRoundScores {
	struct TMap<struct FString, int32_t> PlayerScores_4_E5741E1746A48B4BE359D28202741B2E; // 0x00(0x50)
	int32_t Round_8_21F2C6754706411B29D2418475C06659; // 0x50(0x04)
};

