// WidgetBlueprintGeneratedClass SignatureAbilityChargedBanner.SignatureAbilityChargedBanner_C
// Size: 0x368 (Inherited: 0x368)
struct USignatureAbilityChargedBanner_C : UTextBannerNotificationWidget_C {
};

