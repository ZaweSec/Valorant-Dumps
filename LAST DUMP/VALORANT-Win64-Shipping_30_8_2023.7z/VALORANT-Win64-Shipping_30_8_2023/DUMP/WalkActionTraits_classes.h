// BlueprintGeneratedClass WalkActionTraits.WalkActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UWalkActionTraits_C : UActionTraits {
};

