// BlueprintGeneratedClass BasePistolPurchase.BasePistolPurchase_C
// Size: 0xa8 (Inherited: 0xa8)
struct UBasePistolPurchase_C : UAresPurchasableEquippable {
};

