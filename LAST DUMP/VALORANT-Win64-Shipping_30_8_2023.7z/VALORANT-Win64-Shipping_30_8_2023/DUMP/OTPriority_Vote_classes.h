// BlueprintGeneratedClass OTPriority_Vote.OTPriority_Vote_C
// Size: 0x590 (Inherited: 0x559)
struct AOTPriority_Vote_C : AGameplayVoteBase_C {
	char pad_559[0x7]; // 0x559(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x560(0x08)
	struct UOTPriority_VoteOption_StartAttacker_C* OTPriority_VoteOption_StartAttacker; // 0x568(0x08)
	struct UOTPriority_VoteOption_StartDefender_C* OTPriority_VoteOption_StartDefender; // 0x570(0x08)
	struct FText OnVoteStartedEnemyNotification; // 0x578(0x18)

	struct TArray<struct AShooterPlayerState*> GenerateParticipants(struct AShooterPlayerState* RequestingPlayer); // Function OTPriority_Vote.OTPriority_Vote_C.GenerateParticipants // (BlueprintAuthorityOnly|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3cb77f0
	void AuthOnStarted(); // Function OTPriority_Vote.OTPriority_Vote_C.AuthOnStarted // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x3cb77f0
	void ExecuteUbergraph_OTPriority_Vote(int32_t EntryPoint); // Function OTPriority_Vote.OTPriority_Vote_C.ExecuteUbergraph_OTPriority_Vote // (Final|UbergraphFunction|HasDefaults) // @ game+0x3cb77f0
};

