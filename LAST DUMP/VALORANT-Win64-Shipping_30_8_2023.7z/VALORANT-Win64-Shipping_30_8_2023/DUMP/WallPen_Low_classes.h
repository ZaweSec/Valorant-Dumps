// BlueprintGeneratedClass WallPen_Low.WallPen_Low_C
// Size: 0x48 (Inherited: 0x48)
struct UWallPen_Low_C : UAresWallPenetration {
};

