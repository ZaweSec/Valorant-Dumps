// BlueprintGeneratedClass FXC_Gun_BombDefused.FXC_Gun_BombDefused_C
// Size: 0x548 (Inherited: 0x540)
struct AFXC_Gun_BombDefused_C : AEffectContainer {
	struct USceneComponent* DefaultSceneRoot; // 0x540(0x08)
};

