// BlueprintGeneratedClass NextWeaponActionTraits.NextWeaponActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UNextWeaponActionTraits_C : UActionTraits {
};

