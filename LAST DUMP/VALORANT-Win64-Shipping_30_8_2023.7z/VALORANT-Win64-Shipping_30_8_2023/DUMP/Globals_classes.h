// BlueprintGeneratedClass Globals.Globals_C
// Size: 0x840 (Inherited: 0x828)
struct UGlobals_C : UShooterGameGlobals {
	float HealAssistMoneyPerHP; // 0x828(0x04)
	char pad_82C[0x4]; // 0x82c(0x04)
	struct FMulticastInlineDelegate NewEventDispatcher_1; // 0x830(0x10)

	void NewEventDispatcher_0__DelegateSignature(); // Function Globals.Globals_C.NewEventDispatcher_0__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x3cb77f0
};

