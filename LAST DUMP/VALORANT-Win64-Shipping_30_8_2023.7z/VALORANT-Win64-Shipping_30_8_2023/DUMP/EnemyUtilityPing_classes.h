// BlueprintGeneratedClass EnemyUtilityPing.EnemyUtilityPing_C
// Size: 0x6d0 (Inherited: 0x6d0)
struct AEnemyUtilityPing_C : ABasePing_C {
};

