// BlueprintGeneratedClass DmgType_ACR.DmgType_ACR_C
// Size: 0x170 (Inherited: 0x170)
struct UDmgType_ACR_C : UDmgType_RifleBase_C {
};

