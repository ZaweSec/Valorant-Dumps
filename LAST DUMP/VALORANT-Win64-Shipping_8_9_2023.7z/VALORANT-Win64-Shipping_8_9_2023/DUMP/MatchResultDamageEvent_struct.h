// UserDefinedStruct MatchResultDamageEvent.MatchResultDamageEvent
// Size: 0x38 (Inherited: 0x00)
struct FMatchResultDamageEvent {
	int32_t round_11_CFF62C074EBF487B150B848F754D33A5; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString attacker_10_530D54CA48FA7B48495579BB0F92E80B; // 0x08(0x10)
	struct FString victim_9_3BA971BB4EEF730E63DF46B3F6A9D355; // 0x18(0x10)
	int32_t damage_8_953F5B63400A3C9B09C000A71BFDF982; // 0x28(0x04)
	int32_t headshots_15_75D0622A43B550033CF4959F27CF1B1C; // 0x2c(0x04)
	int32_t bodyshots_18_835197AF44B5589B5AFE9885CF0221EC; // 0x30(0x04)
	int32_t legshots_19_9344AED04C9707BA03D28EBD88800E0A; // 0x34(0x04)
};

