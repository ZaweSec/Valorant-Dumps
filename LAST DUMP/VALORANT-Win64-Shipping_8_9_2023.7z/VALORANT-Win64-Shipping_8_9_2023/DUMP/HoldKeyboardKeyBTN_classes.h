// WidgetBlueprintGeneratedClass HoldKeyboardKeyBTN.HoldKeyboardKeyBTN_C
// Size: 0x311 (Inherited: 0x2d8)
struct UHoldKeyboardKeyBTN_C : UCoordinatedHUDElement {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d8(0x08)
	struct UProgressBar* holdBar; // 0x2e0(0x08)
	struct UInvalidationBox* InvalidationBox_HoldKeyboardKeyBTN; // 0x2e8(0x08)
	struct UKeyboardKeyBTN_C* KeyboardKeyBTN; // 0x2f0(0x08)
	struct FName ActionMapping; // 0x2f8(0x0c)
	char pad_304[0x4]; // 0x304(0x04)
	struct FTimerHandle HoldTimer; // 0x308(0x08)
	bool isHeld; // 0x310(0x01)

	void UseKeyPressed(); // Function HoldKeyboardKeyBTN.HoldKeyboardKeyBTN_C.UseKeyPressed // (BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void holdComplete(); // Function HoldKeyboardKeyBTN.HoldKeyboardKeyBTN_C.holdComplete // (BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void UseKeyReleased(); // Function HoldKeyboardKeyBTN.HoldKeyboardKeyBTN_C.UseKeyReleased // (BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void Construct(); // Function HoldKeyboardKeyBTN.HoldKeyboardKeyBTN_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3ce0540
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function HoldKeyboardKeyBTN.HoldKeyboardKeyBTN_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3ce0540
	void ExecuteUbergraph_HoldKeyboardKeyBTN(int32_t EntryPoint); // Function HoldKeyboardKeyBTN.HoldKeyboardKeyBTN_C.ExecuteUbergraph_HoldKeyboardKeyBTN // (Final|UbergraphFunction|HasDefaults) // @ game+0x3ce0540
};

