// BlueprintGeneratedClass DmgType_LeverSniperRifle.DmgType_LeverSniperRifle_C
// Size: 0x170 (Inherited: 0x170)
struct UDmgType_LeverSniperRifle_C : UDmgType_SniperRifleBase_C {
};

