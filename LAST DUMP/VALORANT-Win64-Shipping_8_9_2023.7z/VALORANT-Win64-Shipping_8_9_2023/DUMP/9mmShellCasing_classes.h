// BlueprintGeneratedClass 9mmShellCasing.9mmShellCasing_C
// Size: 0x570 (Inherited: 0x570)
struct A9mmShellCasing_C : ABaseShellCasing_C {
};

