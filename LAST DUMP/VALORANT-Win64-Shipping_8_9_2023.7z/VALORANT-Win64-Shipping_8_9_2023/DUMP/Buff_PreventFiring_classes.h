// BlueprintGeneratedClass Buff_PreventFiring.Buff_PreventFiring_C
// Size: 0x990 (Inherited: 0x990)
struct UBuff_PreventFiring_C : UAresGameplayBuff {
};

