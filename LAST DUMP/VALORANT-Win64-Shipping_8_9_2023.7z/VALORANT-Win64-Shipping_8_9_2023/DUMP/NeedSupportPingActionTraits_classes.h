// BlueprintGeneratedClass NeedSupportPingActionTraits.NeedSupportPingActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UNeedSupportPingActionTraits_C : UActionTraits {
};

