// BlueprintGeneratedClass FXC_Carbine_Equip.FXC_Carbine_Equip_C
// Size: 0x580 (Inherited: 0x580)
struct AFXC_Carbine_Equip_C : AFXC_Gun_Equip_C {
};

