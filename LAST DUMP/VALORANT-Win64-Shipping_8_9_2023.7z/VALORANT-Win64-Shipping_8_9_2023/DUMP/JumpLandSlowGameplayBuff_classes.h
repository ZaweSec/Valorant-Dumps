// BlueprintGeneratedClass JumpLandSlowGameplayBuff.JumpLandSlowGameplayBuff_C
// Size: 0x990 (Inherited: 0x990)
struct UJumpLandSlowGameplayBuff_C : UAresGameplayBuff {
};

