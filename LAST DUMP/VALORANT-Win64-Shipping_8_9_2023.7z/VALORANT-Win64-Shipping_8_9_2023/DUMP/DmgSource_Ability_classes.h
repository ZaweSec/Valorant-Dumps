// BlueprintGeneratedClass DmgSource_Ability.DmgSource_Ability_C
// Size: 0x3d8 (Inherited: 0x3d0)
struct ADmgSource_Ability_C : ADamageSource {
	struct USceneComponent* DefaultSceneRoot; // 0x3d0(0x08)
};

