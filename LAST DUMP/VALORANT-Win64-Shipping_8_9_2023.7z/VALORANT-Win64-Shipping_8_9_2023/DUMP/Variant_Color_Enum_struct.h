// UserDefinedEnum Variant_Color_Enum.Variant_Color_Enum
enum class Variant_Color_Enum : uint8 {
	NewEnumerator4 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	NewEnumerator3 = 4,
	Variant_Color_MAX = 5
};

