// UserDefinedEnum EIconPromptType.EIconPromptType
enum class EIconPromptType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	EIconPromptType_MAX = 3
};

