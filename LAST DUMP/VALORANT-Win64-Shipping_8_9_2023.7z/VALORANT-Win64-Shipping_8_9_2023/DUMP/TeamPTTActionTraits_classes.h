// BlueprintGeneratedClass TeamPTTActionTraits.TeamPTTActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UTeamPTTActionTraits_C : UActionTraits {
};

