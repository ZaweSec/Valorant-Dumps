// BlueprintGeneratedClass OTPriority_VoteOption_StartAttacker.OTPriority_VoteOption_StartAttacker_C
// Size: 0x198 (Inherited: 0x160)
struct UOTPriority_VoteOption_StartAttacker_C : UGameplayVoteOptionBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x160(0x08)
	struct FText SelectedAllyNotificationText; // 0x168(0x18)
	struct FText SelectedEnemyNotificationText; // 0x180(0x18)

	void AuthUpdateVotesNeeded(); // Function OTPriority_VoteOption_StartAttacker.OTPriority_VoteOption_StartAttacker_C.AuthUpdateVotesNeeded // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void OnSelected(); // Function OTPriority_VoteOption_StartAttacker.OTPriority_VoteOption_StartAttacker_C.OnSelected // (Event|Public|BlueprintEvent) // @ game+0x3ce0540
	void ExecuteUbergraph_OTPriority_VoteOption_StartAttacker(int32_t EntryPoint); // Function OTPriority_VoteOption_StartAttacker.OTPriority_VoteOption_StartAttacker_C.ExecuteUbergraph_OTPriority_VoteOption_StartAttacker // (Final|UbergraphFunction|HasDefaults) // @ game+0x3ce0540
};

