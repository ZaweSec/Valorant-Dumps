// BlueprintGeneratedClass ActionTraitsManager.ActionTraitsManager_C
// Size: 0x90 (Inherited: 0x90)
struct UActionTraitsManager_C : UActionTraitsManager {
};

