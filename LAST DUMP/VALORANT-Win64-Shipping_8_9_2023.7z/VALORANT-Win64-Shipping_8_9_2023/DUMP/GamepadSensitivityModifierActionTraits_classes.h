// BlueprintGeneratedClass GamepadSensitivityModifierActionTraits.GamepadSensitivityModifierActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UGamepadSensitivityModifierActionTraits_C : UActionTraits {
};

