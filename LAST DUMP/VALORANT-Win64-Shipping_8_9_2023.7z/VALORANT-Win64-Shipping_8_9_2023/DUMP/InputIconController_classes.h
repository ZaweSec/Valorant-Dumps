// WidgetBlueprintGeneratedClass InputIconController.InputIconController_C
// Size: 0x330 (Inherited: 0x2c8)
struct UInputIconController_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c8(0x08)
	struct UBorder* GamepadInputIconContainer; // 0x2d0(0x08)
	struct UGamepadInputPromptSwitcher_C* GamepadInputPromptSwitcher; // 0x2d8(0x08)
	struct UOverlay* KeyboardMouseIconContainer; // 0x2e0(0x08)
	struct FMulticastInlineDelegate OnIconChange; // 0x2e8(0x10)
	bool PreConstructShowGamepad; // 0x2f8(0x01)
	char pad_2F9[0x7]; // 0x2f9(0x07)
	struct TArray<struct FPlatformSpecificText> PlatformSpecificText; // 0x300(0x10)
	struct FMulticastInlineDelegate OnInputPress; // 0x310(0x10)
	struct FMulticastInlineDelegate OnInputReleased; // 0x320(0x10)

	void CreateKeyTextLabel(struct FName ActionName, struct UPanelWidget* Object Container, struct UTextBlock*& TextBox); // Function InputIconController.InputIconController_C.CreateKeyTextLabel // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void CreateHoldKeyboardBTN(struct UHoldKeyboardKeyBTN_C*& HoldKeyboardBTN); // Function InputIconController.InputIconController_C.CreateHoldKeyboardBTN // (Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void CreateKeyboardBTN(struct UKeyboardKeyBTN_C*& KeyboardKeyBTN); // Function InputIconController.InputIconController_C.CreateKeyboardBTN // (Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void CreateSharedKeyPrompt(struct UShared_Keyboard_Prompt_C*& SharedKeyboardPrompt); // Function InputIconController.InputIconController_C.CreateSharedKeyPrompt // (Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void CreateSharedMousePrompt(struct UShared_Mouse_Prompt_C*& SharedMousePromptWidget); // Function InputIconController.InputIconController_C.CreateSharedMousePrompt // (Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void GetKeyBinding(struct FName BindingName, struct FText& DisplayName); // Function InputIconController.InputIconController_C.GetKeyBinding // (Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x3ce0540
	void GetMouseBinding(struct FName Action Name, enum class Enum_AbilityInputs& MouseBinding); // Function InputIconController.InputIconController_C.GetMouseBinding // (Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x3ce0540
	void EventOnIconChange(); // Function InputIconController.InputIconController_C.EventOnIconChange // (BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void Construct(); // Function InputIconController.InputIconController_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3ce0540
	void PreConstruct(bool IsDesignTime); // Function InputIconController.InputIconController_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3ce0540
	void OnInitialized(); // Function InputIconController.InputIconController_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3ce0540
	void ExecuteUbergraph_InputIconController(int32_t EntryPoint); // Function InputIconController.InputIconController_C.ExecuteUbergraph_InputIconController // (Final|UbergraphFunction|HasDefaults) // @ game+0x3ce0540
	void OnInputReleased__DelegateSignature(); // Function InputIconController.InputIconController_C.OnInputReleased__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void OnInputPress__DelegateSignature(); // Function InputIconController.InputIconController_C.OnInputPress__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void OnIconChange__DelegateSignature(); // Function InputIconController.InputIconController_C.OnIconChange__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
};

