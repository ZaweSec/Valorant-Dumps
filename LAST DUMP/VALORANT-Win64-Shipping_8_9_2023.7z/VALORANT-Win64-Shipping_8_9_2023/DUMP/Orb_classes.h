// BlueprintGeneratedClass Orb.Orb_C
// Size: 0x418 (Inherited: 0x408)
struct AOrb_C : AGameObject {
	struct FMulticastInlineDelegate OrbClaimed; // 0x408(0x10)

	void OrbClaimed__DelegateSignature(struct AShooterCharacter* Claimer); // Function Orb.Orb_C.OrbClaimed__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
};

