// BlueprintGeneratedClass VOEmotePingActionTraits.VOEmotePingActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UVOEmotePingActionTraits_C : UActionTraits {
};

