// UserDefinedStruct MatchResultRoundStayedInSpawnEvent.MatchResultRoundStayedInSpawnEvent
// Size: 0x18 (Inherited: 0x00)
struct FMatchResultRoundStayedInSpawnEvent {
	int32_t RoundNum_2_37864B1945DDCF280C8C67AF73ACBA4C; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString Subject_5_198527AF4711E59A1730A5AE810B019F; // 0x08(0x10)
};

