// BlueprintGeneratedClass FXC_JumpLand.FXC_JumpLand_C
// Size: 0x578 (Inherited: 0x578)
struct AFXC_JumpLand_C : AFXC_GroundSound_C {
};

