// BlueprintGeneratedClass BPAresSettingsManager.BPAresSettingsManager_C
// Size: 0x420 (Inherited: 0x420)
struct UBPAresSettingsManager_C : UAresSettingsManager {
};

