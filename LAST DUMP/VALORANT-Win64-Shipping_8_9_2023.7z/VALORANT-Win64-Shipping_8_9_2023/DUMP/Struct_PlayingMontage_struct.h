// UserDefinedStruct Struct_PlayingMontage.Struct_PlayingMontage
// Size: 0x1c (Inherited: 0x00)
struct FStruct_PlayingMontage {
	struct UAnimInstance* Instance_2_C16A491D4997ACDE29EFF8850CEB97B9; // 0x00(0x08)
	struct UAnimMontage* Montage_5_AACFE19D4BA9A165B89F60B76FCA522D; // 0x08(0x08)
	float StartedGameTime_15_87F498224CF413476FBF42A0682B3781; // 0x10(0x04)
	float StartedMontageTime_16_CA1018C6412551D499BFC1B5BEC299EB; // 0x14(0x04)
	float PlayRate_12_63788576405D1089EBBEC5B039E999AA; // 0x18(0x04)
};

