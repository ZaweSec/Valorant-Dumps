// BlueprintGeneratedClass ModeToggleActionTraits.ModeToggleActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UModeToggleActionTraits_C : UActionTraits {
};

