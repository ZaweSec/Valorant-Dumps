// UserDefinedEnum FiringParticleFrequencyEnum.FiringParticleFrequencyEnum
enum class FiringParticleFrequencyEnum : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	FiringParticleFrequencyEnum_MAX = 2
};

