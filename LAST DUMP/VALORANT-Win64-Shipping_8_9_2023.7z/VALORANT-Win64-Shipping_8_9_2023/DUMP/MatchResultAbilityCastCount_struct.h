// UserDefinedStruct MatchResultAbilityCastCount.MatchResultAbilityCastCount
// Size: 0x60 (Inherited: 0x00)
struct FMatchResultAbilityCastCount {
	struct TMap<enum class EAresItemSlot, int32_t> abilityCounts_20_CB6936D8421227488F2CB086B9D11507; // 0x00(0x50)
	struct FString subject_15_88E168344FF47E2293741C989E105357; // 0x50(0x10)
};

