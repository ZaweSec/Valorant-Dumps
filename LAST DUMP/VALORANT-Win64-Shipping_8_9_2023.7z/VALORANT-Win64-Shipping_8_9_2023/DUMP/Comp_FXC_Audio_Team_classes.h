// BlueprintGeneratedClass Comp_FXC_Audio_Team.Comp_FXC_Audio_Team_C
// Size: 0x1a1 (Inherited: 0x1a0)
struct UComp_FXC_Audio_Team_C : UComp_FXC_Audio_Switch_C {
	enum class EAresAlliance TeamRule; // 0x1a0(0x01)

	void ValidContext(struct UObject* Context, bool& Valid); // Function Comp_FXC_Audio_Team.Comp_FXC_Audio_Team_C.ValidContext // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x3ce0540
};

