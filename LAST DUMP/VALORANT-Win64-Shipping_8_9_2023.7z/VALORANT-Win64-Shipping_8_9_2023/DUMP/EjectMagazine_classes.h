// BlueprintGeneratedClass EjectMagazine.EjectMagazine_C
// Size: 0x40 (Inherited: 0x40)
struct UEjectMagazine_C : UAnimNotify {

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function EjectMagazine.EjectMagazine_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3ce0540
};

