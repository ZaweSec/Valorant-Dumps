// BlueprintGeneratedClass TogglePlayerLoadoutVisibilityActionTraits.TogglePlayerLoadoutVisibilityActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UTogglePlayerLoadoutVisibilityActionTraits_C : UActionTraits {
};

