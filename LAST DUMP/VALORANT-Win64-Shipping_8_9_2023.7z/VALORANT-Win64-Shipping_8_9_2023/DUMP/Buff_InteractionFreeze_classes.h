// BlueprintGeneratedClass Buff_InteractionFreeze.Buff_InteractionFreeze_C
// Size: 0x990 (Inherited: 0x990)
struct UBuff_InteractionFreeze_C : UAresGameplayBuff {
};

