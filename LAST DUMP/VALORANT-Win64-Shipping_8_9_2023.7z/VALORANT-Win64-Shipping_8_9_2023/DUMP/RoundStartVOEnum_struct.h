// UserDefinedEnum RoundStartVOEnum.RoundStartVOEnum
enum class RoundStartVOEnum : uint8 {
	NewEnumerator9 = 0,
	NewEnumerator0 = 1,
	NewEnumerator7 = 2,
	NewEnumerator2 = 3,
	NewEnumerator3 = 4,
	NewEnumerator5 = 5,
	NewEnumerator6 = 6,
	NewEnumerator8 = 7,
	RoundStartVOEnum_MAX = 8
};

