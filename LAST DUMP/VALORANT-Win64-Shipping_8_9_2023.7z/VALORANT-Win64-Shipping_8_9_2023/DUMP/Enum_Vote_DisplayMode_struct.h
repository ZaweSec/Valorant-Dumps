// UserDefinedEnum Enum_Vote_DisplayMode.Enum_Vote_DisplayMode
enum class Enum_Vote_DisplayMode : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator3 = 3,
	Enum_Vote_MAX = 4
};

