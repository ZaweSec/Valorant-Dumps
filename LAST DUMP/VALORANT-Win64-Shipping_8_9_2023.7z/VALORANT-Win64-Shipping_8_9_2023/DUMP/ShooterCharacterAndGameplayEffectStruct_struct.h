// UserDefinedStruct ShooterCharacterAndGameplayEffectStruct.ShooterCharacterAndGameplayEffectStruct
// Size: 0x10 (Inherited: 0x00)
struct FShooterCharacterAndGameplayEffectStruct {
	struct AShooterCharacter* ShooterCharacter_2_6CE07D3C4CAB7810FE1F128730B06855; // 0x00(0x08)
	struct FActiveGameplayEffectHandle GameplayEffectHandle_5_9F15646242FF4EFC2665069A6342F4A8; // 0x08(0x08)
};

