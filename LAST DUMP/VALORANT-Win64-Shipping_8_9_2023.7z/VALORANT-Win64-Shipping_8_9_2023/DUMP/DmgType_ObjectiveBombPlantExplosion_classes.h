// BlueprintGeneratedClass DmgType_ObjectiveBombPlantExplosion.DmgType_ObjectiveBombPlantExplosion_C
// Size: 0x167 (Inherited: 0x167)
struct UDmgType_ObjectiveBombPlantExplosion_C : UDmgType_Base_C {
};

