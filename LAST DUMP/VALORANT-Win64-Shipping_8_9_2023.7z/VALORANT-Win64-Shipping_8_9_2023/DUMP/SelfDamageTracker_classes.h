// BlueprintGeneratedClass SelfDamageTracker.SelfDamageTracker_C
// Size: 0x460 (Inherited: 0x450)
struct ASelfDamageTracker_C : ABehaviorScoreTrackerBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x450(0x08)
	float TotalDamageToSelf; // 0x458(0x04)
	float TotalDamageToEnemies; // 0x45c(0x04)

	float CalculateFactor(enum class EMatchCompletionState CompletionState); // Function SelfDamageTracker.SelfDamageTracker_C.CalculateFactor // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void BeginTracking(); // Function SelfDamageTracker.SelfDamageTracker_C.BeginTracking // (Event|Public|BlueprintEvent) // @ game+0x3ce0540
	void ExecuteUbergraph_SelfDamageTracker(int32_t EntryPoint); // Function SelfDamageTracker.SelfDamageTracker_C.ExecuteUbergraph_SelfDamageTracker // (Final|UbergraphFunction) // @ game+0x3ce0540
};

