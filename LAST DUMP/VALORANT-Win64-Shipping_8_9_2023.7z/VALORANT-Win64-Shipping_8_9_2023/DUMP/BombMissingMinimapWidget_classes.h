// WidgetBlueprintGeneratedClass BombMissingMinimapWidget.BombMissingMinimapWidget_C
// Size: 0x3c8 (Inherited: 0x3c0)
struct UBombMissingMinimapWidget_C : UMissingMinimapWidget_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3c0(0x08)

	void Construct(); // Function BombMissingMinimapWidget.BombMissingMinimapWidget_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3ce0540
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function BombMissingMinimapWidget.BombMissingMinimapWidget_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3ce0540
	void ReceiveSetState(); // Function BombMissingMinimapWidget.BombMissingMinimapWidget_C.ReceiveSetState // (Event|Public|BlueprintEvent) // @ game+0x3ce0540
	void ExecuteUbergraph_BombMissingMinimapWidget(int32_t EntryPoint); // Function BombMissingMinimapWidget.BombMissingMinimapWidget_C.ExecuteUbergraph_BombMissingMinimapWidget // (Final|UbergraphFunction|HasDefaults) // @ game+0x3ce0540
};

