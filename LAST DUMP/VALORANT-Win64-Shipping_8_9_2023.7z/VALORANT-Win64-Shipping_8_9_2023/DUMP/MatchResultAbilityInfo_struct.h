// UserDefinedStruct MatchResultAbilityInfo.MatchResultAbilityInfo
// Size: 0x2c (Inherited: 0x00)
struct FMatchResultAbilityInfo {
	enum class EAresItemSlot AbilitySlot_12_711C2843408D9EE7418E4988A8640032; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FName AbilityType_25_711F19E74BFCB1338F0B40ABFBB74391; // 0x04(0x0c)
	float Value_15_4819929F43889FB712DC8F8B4F011B57; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FString Subject_24_7334C8224D58E0CF389CF5BA0E0AE50E; // 0x18(0x10)
	int32_t Round_22_573F749F492464704A05E1892196D179; // 0x28(0x04)
};

