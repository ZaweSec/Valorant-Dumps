// Class NiagaraShader.NiagaraScriptBase
// Size: 0x30 (Inherited: 0x30)
struct UNiagaraScriptBase : UObject {
};

