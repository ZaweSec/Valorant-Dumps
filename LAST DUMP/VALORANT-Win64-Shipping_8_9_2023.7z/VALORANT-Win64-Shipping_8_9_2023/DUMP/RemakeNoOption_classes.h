// BlueprintGeneratedClass RemakeNoOption.RemakeNoOption_C
// Size: 0x168 (Inherited: 0x160)
struct URemakeNoOption_C : UGameplayVoteOptionBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x160(0x08)

	void OnSelected(); // Function RemakeNoOption.RemakeNoOption_C.OnSelected // (Event|Public|BlueprintEvent) // @ game+0x3ce0540
	void ExecuteUbergraph_RemakeNoOption(int32_t EntryPoint); // Function RemakeNoOption.RemakeNoOption_C.ExecuteUbergraph_RemakeNoOption // (Final|UbergraphFunction|HasDefaults) // @ game+0x3ce0540
};

