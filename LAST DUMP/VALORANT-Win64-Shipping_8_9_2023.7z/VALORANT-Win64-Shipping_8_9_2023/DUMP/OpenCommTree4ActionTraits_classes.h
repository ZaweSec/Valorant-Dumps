// BlueprintGeneratedClass OpenCommTree4ActionTraits.OpenCommTree4ActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UOpenCommTree4ActionTraits_C : UActionTraits {
};

