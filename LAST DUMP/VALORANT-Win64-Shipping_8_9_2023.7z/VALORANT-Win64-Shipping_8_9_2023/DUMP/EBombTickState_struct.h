// UserDefinedEnum EBombTickState.EBombTickState
enum class EBombTickState : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator4 = 3,
	NewEnumerator5 = 4,
	NewEnumerator3 = 5,
	EBombTickState_MAX = 6
};

