// BlueprintGeneratedClass Magazine_Rifle_AK.Magazine_Rifle_AK_C
// Size: 0x588 (Inherited: 0x588)
struct AMagazine_Rifle_AK_C : ABaseMagazine_C {
};

