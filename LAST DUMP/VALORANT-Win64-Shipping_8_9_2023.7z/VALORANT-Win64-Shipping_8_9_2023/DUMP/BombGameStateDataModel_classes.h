// BlueprintGeneratedClass BombGameStateDataModel.BombGameStateDataModel_C
// Size: 0x579 (Inherited: 0x570)
struct UBombGameStateDataModel_C : UShooterGameStateDataModel {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x570(0x08)
	enum class EAresBombStates BombState; // 0x578(0x01)

	void InitializeModel(struct AShooterGameState* InGameState); // Function BombGameStateDataModel.BombGameStateDataModel_C.InitializeModel // (Event|Public|BlueprintEvent) // @ game+0x3ce0540
	void OnBombStateChanged(enum class EAresBombStates BombState); // Function BombGameStateDataModel.BombGameStateDataModel_C.OnBombStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void OnBombDefuseStart(struct AShooterCharacter* Defuser); // Function BombGameStateDataModel.BombGameStateDataModel_C.OnBombDefuseStart // (BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void OnBombDefuseStop(); // Function BombGameStateDataModel.BombGameStateDataModel_C.OnBombDefuseStop // (BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void OnBombPlantStart(struct AShooterCharacter* Planter, enum class BombSiteEnum PlantSite); // Function BombGameStateDataModel.BombGameStateDataModel_C.OnBombPlantStart // (BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void OnBombPlantCancelled(enum class BombSiteEnum PlantSite); // Function BombGameStateDataModel.BombGameStateDataModel_C.OnBombPlantCancelled // (BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void OnBombPlanted(struct FVector PlantLocation, struct AShooterCharacter* BombPlanter, enum class BombSiteEnum PlantSite); // Function BombGameStateDataModel.BombGameStateDataModel_C.OnBombPlanted // (BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void OnBombCheckpointReached(struct AShooterCharacter* Defuser, int32_t CheckpointNumber, float DefuseProgress); // Function BombGameStateDataModel.BombGameStateDataModel_C.OnBombCheckpointReached // (BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
	void ExecuteUbergraph_BombGameStateDataModel(int32_t EntryPoint); // Function BombGameStateDataModel.BombGameStateDataModel_C.ExecuteUbergraph_BombGameStateDataModel // (Final|UbergraphFunction) // @ game+0x3ce0540
};

