// UserDefinedStruct Material_Array_Struct.Material_Array_Struct
// Size: 0x30 (Inherited: 0x00)
struct FMaterial_Array_Struct {
	struct FString Slot_10_CD2A29974A464C4ACC7981966380C35E; // 0x00(0x10)
	struct TArray<struct UMaterialInterface*> 1PMaterials_7_2D5E4E564F5BC4E78033CF8553E54769; // 0x10(0x10)
	struct TArray<struct UMaterialInterface*> 3PMaterials_9_53934E6C4BAB61AE7C81368F436BEA67; // 0x20(0x10)
};

