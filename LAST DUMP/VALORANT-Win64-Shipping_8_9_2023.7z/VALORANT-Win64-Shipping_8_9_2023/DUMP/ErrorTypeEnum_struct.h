// UserDefinedEnum ErrorTypeEnum.ErrorTypeEnum
enum class ErrorTypeEnum : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	ErrorTypeEnum_MAX = 3
};

