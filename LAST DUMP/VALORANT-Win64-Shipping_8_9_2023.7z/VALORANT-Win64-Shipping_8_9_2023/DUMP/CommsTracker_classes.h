// BlueprintGeneratedClass CommsTracker.CommsTracker_C
// Size: 0x450 (Inherited: 0x450)
struct ACommsTracker_C : ABehaviorScoreTrackerBase_C {

	float CalculateFactor(enum class EMatchCompletionState CompletionState); // Function CommsTracker.CommsTracker_C.CalculateFactor // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3ce0540
};

