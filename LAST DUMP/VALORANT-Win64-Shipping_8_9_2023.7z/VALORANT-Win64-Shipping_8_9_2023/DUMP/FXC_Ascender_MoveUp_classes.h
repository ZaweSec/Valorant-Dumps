// BlueprintGeneratedClass FXC_Ascender_MoveUp.FXC_Ascender_MoveUp_C
// Size: 0x550 (Inherited: 0x540)
struct AFXC_Ascender_MoveUp_C : AEffectContainer {
	struct UComp_FXC_AudioLoop_C* Comp_FXC_AudioLoop; // 0x540(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x548(0x08)
};

