// BlueprintGeneratedClass FXC_RedDot_Close.FXC_RedDot_Close_C
// Size: 0x578 (Inherited: 0x578)
struct AFXC_RedDot_Close_C : AFXC_RedDot_Open_C {
};

