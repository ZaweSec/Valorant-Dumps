// BlueprintGeneratedClass FXC_BasePistol_AltFire.FXC_BasePistol_AltFire_C
// Size: 0x598 (Inherited: 0x590)
struct AFXC_BasePistol_AltFire_C : AFXC_Gun_Fire_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x590(0x08)

	void ReceiveBeginPlay(); // Function FXC_BasePistol_AltFire.FXC_BasePistol_AltFire_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x3ce0540
	void StartEffect(struct AActor* Target, struct UObject* Context, float StartTime, bool FirstPerson); // Function FXC_BasePistol_AltFire.FXC_BasePistol_AltFire_C.StartEffect // (Event|Public|BlueprintEvent) // @ game+0x3ce0540
	void ExecuteUbergraph_FXC_BasePistol_AltFire(int32_t EntryPoint); // Function FXC_BasePistol_AltFire.FXC_BasePistol_AltFire_C.ExecuteUbergraph_FXC_BasePistol_AltFire // (Final|UbergraphFunction) // @ game+0x3ce0540
};

