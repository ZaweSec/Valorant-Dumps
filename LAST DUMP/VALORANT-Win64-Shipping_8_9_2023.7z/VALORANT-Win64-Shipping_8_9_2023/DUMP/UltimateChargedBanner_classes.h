// WidgetBlueprintGeneratedClass UltimateChargedBanner.UltimateChargedBanner_C
// Size: 0x368 (Inherited: 0x368)
struct UUltimateChargedBanner_C : UTextBannerNotificationWidget_C {
};

