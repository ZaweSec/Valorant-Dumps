// BlueprintGeneratedClass AssaultRifle_ACR.AssaultRifle_ACR_C
// Size: 0x1380 (Inherited: 0x1371)
struct AAssaultRifle_ACR_C : AGun_Zoomable_C {
	char pad_1371[0x7]; // 0x1371(0x07)
	struct UComp_Gun_ZoomFiringRateModifier_C* Comp_Gun_ZoomFiringRateModifier; // 0x1378(0x08)
};

