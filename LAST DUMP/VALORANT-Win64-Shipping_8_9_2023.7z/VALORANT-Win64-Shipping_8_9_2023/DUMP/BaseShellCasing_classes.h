// BlueprintGeneratedClass BaseShellCasing.BaseShellCasing_C
// Size: 0x570 (Inherited: 0x570)
struct ABaseShellCasing_C : ABaseEjectable_C {
};

