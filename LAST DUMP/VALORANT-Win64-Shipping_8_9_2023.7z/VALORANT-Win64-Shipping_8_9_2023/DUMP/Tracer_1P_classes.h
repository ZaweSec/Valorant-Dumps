// BlueprintGeneratedClass Tracer_1P.Tracer_1P_C
// Size: 0x668 (Inherited: 0x668)
struct ATracer_1P_C : ABaseDetachedTracer_C {
};

