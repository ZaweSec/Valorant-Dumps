// BlueprintGeneratedClass UseAscenderObjectActionTraits.UseAscenderObjectActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UUseAscenderObjectActionTraits_C : UActionTraits {
};

