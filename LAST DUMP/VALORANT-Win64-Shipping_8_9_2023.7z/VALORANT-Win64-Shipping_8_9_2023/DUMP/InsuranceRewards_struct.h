// UserDefinedStruct InsuranceRewards.InsuranceRewards
// Size: 0x10 (Inherited: 0x00)
struct FInsuranceRewards {
	struct AOwnerExclusivePlayerInfo* Player_6_B12DF65443A4BE84324DAA8FAAC358D9; // 0x00(0x08)
	int32_t Energy_7_5B22F9A04079612506C13CB397878BC5; // 0x08(0x04)
	int32_t Money_10_8348FC1C4A944814737AA69D007A93C3; // 0x0c(0x04)
};

