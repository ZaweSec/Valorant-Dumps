// BlueprintGeneratedClass OpenCommTree3ActionTraits.OpenCommTree3ActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UOpenCommTree3ActionTraits_C : UActionTraits {
};

