// UserDefinedStruct AkSwitch.AkSwitch
// Size: 0x20 (Inherited: 0x00)
struct FAkSwitch {
	struct FString Group_4_2284C73E48C4CFE92376BB9EBCB23D16; // 0x00(0x10)
	struct FString State_5_0CB1F7E342A29E59B5B9D880FA5BEB5A; // 0x10(0x10)
};

