// BlueprintGeneratedClass ObservePlayer10ActionTraits.ObservePlayer10ActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UObservePlayer10ActionTraits_C : UActionTraits {
};

