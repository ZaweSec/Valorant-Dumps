// BlueprintGeneratedClass OpenCommTree3ActionTraits.OpenCommTree3ActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UOpenCommTree3ActionTraits_C : UActionTraits {
};

