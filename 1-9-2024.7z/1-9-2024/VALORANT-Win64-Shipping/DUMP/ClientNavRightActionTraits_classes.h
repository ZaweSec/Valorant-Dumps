// BlueprintGeneratedClass ClientNavRightActionTraits.ClientNavRightActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UClientNavRightActionTraits_C : UActionTraits {
};

