// UserDefinedEnum Aud_SizeSelector.Aud_SizeSelector
enum class Aud_SizeSelector : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	Aud_MAX = 3
};

