// BlueprintGeneratedClass CautionPingActionTraits.CautionPingActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UCautionPingActionTraits_C : UActionTraits {
};

