// BlueprintGeneratedClass WatchingHerePingActionTraits.WatchingHerePingActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UWatchingHerePingActionTraits_C : UActionTraits {
};

