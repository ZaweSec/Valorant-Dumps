// BlueprintGeneratedClass MoveForwardActionTraits.MoveForwardActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UMoveForwardActionTraits_C : UActionTraits {
};

