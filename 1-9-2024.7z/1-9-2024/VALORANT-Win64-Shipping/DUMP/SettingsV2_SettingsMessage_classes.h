// WidgetBlueprintGeneratedClass SettingsV2_SettingsMessage.SettingsV2_SettingsMessage_C
// Size: 0x2f0 (Inherited: 0x2c8)
struct USettingsV2_SettingsMessage_C : UDesignableUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c8(0x08)
	struct UTextBlock* SectionNameText; // 0x2d0(0x08)
	struct FText SectionName; // 0x2d8(0x18)

	void Construct(); // Function SettingsV2_SettingsMessage.SettingsV2_SettingsMessage_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3fa0360
	void OnSynchronizeProperties(); // Function SettingsV2_SettingsMessage.SettingsV2_SettingsMessage_C.OnSynchronizeProperties // (Event|Public|BlueprintEvent) // @ game+0x3fa0360
	void ExecuteUbergraph_SettingsV2_SettingsMessage(int32_t EntryPoint); // Function SettingsV2_SettingsMessage.SettingsV2_SettingsMessage_C.ExecuteUbergraph_SettingsV2_SettingsMessage // (Final|UbergraphFunction) // @ game+0x3fa0360
};

