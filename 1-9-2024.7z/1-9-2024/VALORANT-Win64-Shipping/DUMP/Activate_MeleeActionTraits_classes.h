// BlueprintGeneratedClass Activate_MeleeActionTraits.Activate_MeleeActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UActivate_MeleeActionTraits_C : UActionTraits {
};

