// Class RGIQRCode.RGIQRCode
// Size: 0x30 (Inherited: 0x30)
struct URGIQRCode : UObject {

	struct UTexture2D* GetQrCodeTextureFromString(struct FString Input); // Function RGIQRCode.RGIQRCode.GetQrCodeTextureFromString // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x2237410
};

