// UserDefinedEnum SharedButtonStyles.SharedButtonStyles
enum class SharedButtonStyles : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	SharedButtonStyles_MAX = 2
};

