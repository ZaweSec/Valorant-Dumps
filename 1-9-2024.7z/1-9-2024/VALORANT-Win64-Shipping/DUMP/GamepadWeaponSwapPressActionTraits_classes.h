// BlueprintGeneratedClass GamepadWeaponSwapPressActionTraits.GamepadWeaponSwapPressActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UGamepadWeaponSwapPressActionTraits_C : UActionTraits {
};

