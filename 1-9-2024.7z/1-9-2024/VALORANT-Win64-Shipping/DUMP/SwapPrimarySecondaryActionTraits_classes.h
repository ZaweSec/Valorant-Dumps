// BlueprintGeneratedClass SwapPrimarySecondaryActionTraits.SwapPrimarySecondaryActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct USwapPrimarySecondaryActionTraits_C : UActionTraits {
};

