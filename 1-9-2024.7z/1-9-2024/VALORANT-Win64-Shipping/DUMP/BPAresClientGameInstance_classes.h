// BlueprintGeneratedClass BPAresClientGameInstance.BPAresClientGameInstance_C
// Size: 0x850 (Inherited: 0x850)
struct UBPAresClientGameInstance_C : UAresClientGameInstance {
};

