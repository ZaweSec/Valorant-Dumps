// BlueprintGeneratedClass Activate_UltimateActionTraits.Activate_UltimateActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UActivate_UltimateActionTraits_C : UActionTraits {
};

