// BlueprintGeneratedClass CommMenuOption4ActionTraits.CommMenuOption4ActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UCommMenuOption4ActionTraits_C : UActionTraits {
};

