// WidgetBlueprintGeneratedClass SettingsV2_Subheader.SettingsV2_Subheader_C
// Size: 0x2f0 (Inherited: 0x2c8)
struct USettingsV2_Subheader_C : UDesignableUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c8(0x08)
	struct UTextBlock* SectionNameText; // 0x2d0(0x08)
	struct FText SectionName; // 0x2d8(0x18)

	void Construct(); // Function SettingsV2_Subheader.SettingsV2_Subheader_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3fa0360
	void OnSynchronizeProperties(); // Function SettingsV2_Subheader.SettingsV2_Subheader_C.OnSynchronizeProperties // (Event|Public|BlueprintEvent) // @ game+0x3fa0360
	void ExecuteUbergraph_SettingsV2_Subheader(int32_t EntryPoint); // Function SettingsV2_Subheader.SettingsV2_Subheader_C.ExecuteUbergraph_SettingsV2_Subheader // (Final|UbergraphFunction|HasDefaults) // @ game+0x3fa0360
};

