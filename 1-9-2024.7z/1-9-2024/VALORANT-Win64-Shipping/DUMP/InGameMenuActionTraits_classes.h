// BlueprintGeneratedClass InGameMenuActionTraits.InGameMenuActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UInGameMenuActionTraits_C : UActionTraits {
};

