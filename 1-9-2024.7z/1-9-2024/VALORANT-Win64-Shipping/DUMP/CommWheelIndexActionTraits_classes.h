// BlueprintGeneratedClass CommWheelIndexActionTraits.CommWheelIndexActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UCommWheelIndexActionTraits_C : UActionTraits {
};

