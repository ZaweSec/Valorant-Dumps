// BlueprintGeneratedClass WhisperChatActionTraits.WhisperChatActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UWhisperChatActionTraits_C : UActionTraits {
};

