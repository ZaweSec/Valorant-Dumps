// BlueprintGeneratedClass ObservePlayer1ActionTraits.ObservePlayer1ActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UObservePlayer1ActionTraits_C : UActionTraits {
};

