// BlueprintGeneratedClass OpenCommMenuActionTraits.OpenCommMenuActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UOpenCommMenuActionTraits_C : UActionTraits {
};

