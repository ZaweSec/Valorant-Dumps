// BlueprintGeneratedClass GamepadSensitivityModifierActionTraits.GamepadSensitivityModifierActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UGamepadSensitivityModifierActionTraits_C : UActionTraits {
};

