// BlueprintGeneratedClass ObservePlayer7ActionTraits.ObservePlayer7ActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UObservePlayer7ActionTraits_C : UActionTraits {
};

