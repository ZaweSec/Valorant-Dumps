// BlueprintGeneratedClass ClientNavDownActionTraits.ClientNavDownActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UClientNavDownActionTraits_C : UActionTraits {
};

