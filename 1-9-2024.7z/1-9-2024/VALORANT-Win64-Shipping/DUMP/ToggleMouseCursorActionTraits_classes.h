// BlueprintGeneratedClass ToggleMouseCursorActionTraits.ToggleMouseCursorActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UToggleMouseCursorActionTraits_C : UActionTraits {
};

