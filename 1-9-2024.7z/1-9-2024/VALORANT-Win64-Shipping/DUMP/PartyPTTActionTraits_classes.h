// BlueprintGeneratedClass PartyPTTActionTraits.PartyPTTActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UPartyPTTActionTraits_C : UActionTraits {
};

