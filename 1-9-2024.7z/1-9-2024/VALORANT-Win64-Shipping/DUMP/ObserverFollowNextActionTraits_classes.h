// BlueprintGeneratedClass ObserverFollowNextActionTraits.ObserverFollowNextActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UObserverFollowNextActionTraits_C : UActionTraits {
};

