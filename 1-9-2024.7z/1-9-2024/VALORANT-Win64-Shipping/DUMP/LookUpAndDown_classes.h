// BlueprintGeneratedClass LookUpAndDown.LookUpAndDown_C
// Size: 0x128 (Inherited: 0x128)
struct ULookUpAndDown_C : UActionTraits {
};

