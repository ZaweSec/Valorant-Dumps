// BlueprintGeneratedClass ObserverFollowPrevActionTraits.ObserverFollowPrevActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UObserverFollowPrevActionTraits_C : UActionTraits {
};

