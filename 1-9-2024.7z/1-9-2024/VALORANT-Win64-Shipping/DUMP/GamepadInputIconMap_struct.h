// UserDefinedStruct GamepadInputIconMap.GamepadInputIconMap
// Size: 0x28 (Inherited: 0x00)
struct FGamepadInputIconMap {
	struct FKey Key_4_8DF0E89F4E1E7DDBEF4C28AB69A1C627; // 0x00(0x20)
	struct UTexture2D* Icon_10_9904B6404056D8087CA8198DD90881EB; // 0x20(0x08)
};

