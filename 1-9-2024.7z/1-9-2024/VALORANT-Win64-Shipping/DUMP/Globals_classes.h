// BlueprintGeneratedClass Globals.Globals_C
// Size: 0x870 (Inherited: 0x858)
struct UGlobals_C : UShooterGameGlobals {
	float HealAssistMoneyPerHP; // 0x858(0x04)
	char pad_85C[0x4]; // 0x85c(0x04)
	struct FMulticastInlineDelegate NewEventDispatcher_1; // 0x860(0x10)

	void NewEventDispatcher_0__DelegateSignature(); // Function Globals.Globals_C.NewEventDispatcher_0__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x3fa0360
};

