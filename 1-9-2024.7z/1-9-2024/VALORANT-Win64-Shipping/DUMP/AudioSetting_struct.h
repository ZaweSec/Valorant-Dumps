// UserDefinedStruct AudioSetting.AudioSetting
// Size: 0x1c (Inherited: 0x00)
struct FAudioSetting {
	struct FText SettingName_2_442BF97E4E4EA6F24ED304AB16E7B71A; // 0x00(0x18)
	int32_t SettingValue_5_BEAA827940A637AB28B2C98876E09F49; // 0x18(0x04)
};

