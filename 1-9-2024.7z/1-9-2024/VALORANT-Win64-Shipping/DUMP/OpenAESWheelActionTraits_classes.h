// BlueprintGeneratedClass OpenAESWheelActionTraits.OpenAESWheelActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UOpenAESWheelActionTraits_C : UActionTraits {
};

