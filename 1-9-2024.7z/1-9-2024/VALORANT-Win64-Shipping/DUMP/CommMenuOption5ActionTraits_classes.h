// BlueprintGeneratedClass CommMenuOption5ActionTraits.CommMenuOption5ActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UCommMenuOption5ActionTraits_C : UActionTraits {
};

