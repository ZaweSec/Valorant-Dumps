// BlueprintGeneratedClass CommMenuOption7ActionTraits.CommMenuOption7ActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UCommMenuOption7ActionTraits_C : UActionTraits {
};

