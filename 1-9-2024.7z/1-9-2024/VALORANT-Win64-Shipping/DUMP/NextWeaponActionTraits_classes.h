// BlueprintGeneratedClass NextWeaponActionTraits.NextWeaponActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UNextWeaponActionTraits_C : UActionTraits {
};

