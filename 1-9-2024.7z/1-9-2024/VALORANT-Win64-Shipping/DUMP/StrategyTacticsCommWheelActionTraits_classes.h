// BlueprintGeneratedClass StrategyTacticsCommWheelActionTraits.StrategyTacticsCommWheelActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UStrategyTacticsCommWheelActionTraits_C : UActionTraits {
};

