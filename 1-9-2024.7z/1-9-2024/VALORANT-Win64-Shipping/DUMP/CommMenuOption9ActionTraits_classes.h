// BlueprintGeneratedClass CommMenuOption9ActionTraits.CommMenuOption9ActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UCommMenuOption9ActionTraits_C : UActionTraits {
};

