// BlueprintGeneratedClass Activate_LevelActionTraits.Activate_LevelActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UActivate_LevelActionTraits_C : UActionTraits {
};

