// BlueprintGeneratedClass DPIScalingRules.DPIScalingRules_C
// Size: 0x40 (Inherited: 0x40)
struct UDPIScalingRules_C : UAresDPICustomScalingRule {
};

