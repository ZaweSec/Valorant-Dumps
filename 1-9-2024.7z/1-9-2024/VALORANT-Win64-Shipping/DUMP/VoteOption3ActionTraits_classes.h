// BlueprintGeneratedClass VoteOption3ActionTraits.VoteOption3ActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UVoteOption3ActionTraits_C : UActionTraits {
};

