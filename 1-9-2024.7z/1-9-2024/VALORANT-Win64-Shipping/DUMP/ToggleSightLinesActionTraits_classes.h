// BlueprintGeneratedClass ToggleSightLinesActionTraits.ToggleSightLinesActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UToggleSightLinesActionTraits_C : UActionTraits {
};

