// BlueprintGeneratedClass PregamePlayerController.PregamePlayerController_C
// Size: 0xa00 (Inherited: 0xa00)
struct APregamePlayerController_C : APregamePlayerController {
};

