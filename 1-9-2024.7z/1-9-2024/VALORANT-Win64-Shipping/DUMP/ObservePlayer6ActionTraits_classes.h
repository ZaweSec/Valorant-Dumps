// BlueprintGeneratedClass ObservePlayer6ActionTraits.ObservePlayer6ActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UObservePlayer6ActionTraits_C : UActionTraits {
};

