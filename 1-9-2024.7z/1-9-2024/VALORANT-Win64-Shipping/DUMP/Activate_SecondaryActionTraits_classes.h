// BlueprintGeneratedClass Activate_SecondaryActionTraits.Activate_SecondaryActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UActivate_SecondaryActionTraits_C : UActionTraits {
};

