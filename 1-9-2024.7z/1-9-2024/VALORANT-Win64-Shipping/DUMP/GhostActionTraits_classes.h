// BlueprintGeneratedClass GhostActionTraits.GhostActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UGhostActionTraits_C : UActionTraits {
};

