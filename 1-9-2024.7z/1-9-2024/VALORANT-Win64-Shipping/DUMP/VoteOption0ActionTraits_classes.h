// BlueprintGeneratedClass VoteOption0ActionTraits.VoteOption0ActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UVoteOption0ActionTraits_C : UActionTraits {
};

