// BlueprintGeneratedClass OpenCommTree4ActionTraits.OpenCommTree4ActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UOpenCommTree4ActionTraits_C : UActionTraits {
};

