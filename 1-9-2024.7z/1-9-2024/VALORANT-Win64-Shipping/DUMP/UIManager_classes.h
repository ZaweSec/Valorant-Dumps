// BlueprintGeneratedClass UIManager.UIManager_C
// Size: 0x78 (Inherited: 0x70)
struct UUIManager_C : UAresUIManager {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x70(0x08)

	void ReceiveBeginPlay(); // Function UIManager.UIManager_C.ReceiveBeginPlay // (BlueprintCallable|BlueprintEvent) // @ game+0x3fa0360
	void ReceiveTick(float DeltaSeconds); // Function UIManager.UIManager_C.ReceiveTick // (BlueprintCallable|BlueprintEvent) // @ game+0x3fa0360
	void ExecuteUbergraph_UIManager(int32_t EntryPoint); // Function UIManager.UIManager_C.ExecuteUbergraph_UIManager // (Final|UbergraphFunction) // @ game+0x3fa0360
};

