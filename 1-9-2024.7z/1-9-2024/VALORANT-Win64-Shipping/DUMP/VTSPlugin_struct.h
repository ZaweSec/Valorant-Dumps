// Enum VTSPlugin.EVTSPlayerSynchronizationEventType
enum class EVTSPlayerSynchronizationEventType : uint8 {
	AutonomousHeartbeat = 0,
	RemoteHeartbeat = 1,
	TimeShift = 2,
	FixedTimeStepSizeChange = 3,
	Count = 4,
	EVTSPlayerSynchronizationEventType_MAX = 5
};

// Enum VTSPlugin.EVTSSerializeResult
enum class EVTSSerializeResult : uint8 {
	SuccessWithPayload = 0,
	SuccessEmptyPayload = 1,
	SerializationError = 2,
	EVTSSerializeResult_MAX = 3
};

// Enum VTSPlugin.EVTSVALHeartbeatDequeueHealth
enum class EVTSVALHeartbeatDequeueHealth : uint8 {
	Good = 0,
	ForwardPredictedGap = 1,
	ForwardPredicted = 2,
	NoBasis = 3,
	EVTSVALHeartbeatDequeueHealth_MAX = 4
};

// Enum VTSPlugin.EVTSVALHeartbeatEnqueueHealth
enum class EVTSVALHeartbeatEnqueueHealth : uint8 {
	Perfect = 0,
	Good = 1,
	Outdated = 2,
	Duplicate = 3,
	OverCapacity = 4,
	EVTSVALHeartbeatEnqueueHealth_MAX = 5
};

// Enum VTSPlugin.EVTSVALTimeShiftMonitorRemoteDelayCondition
enum class EVTSVALTimeShiftMonitorRemoteDelayCondition : uint8 {
	Optimal = 0,
	Average = 1,
	Poor = 2,
	EVTSVALTimeShiftMonitorRemoteDelayCondition_MAX = 3
};

// ScriptStruct VTSPlugin.VTSTimeStampIndex
// Size: 0x04 (Inherited: 0x00)
struct FVTSTimeStampIndex {
	uint32_t Value; // 0x00(0x04)
};

// ScriptStruct VTSPlugin.VTSPlayerSychronizationEvent
// Size: 0x14 (Inherited: 0x00)
struct FVTSPlayerSychronizationEvent {
	enum class EVTSPlayerSynchronizationEventType EventType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FVTSTimeStampIndex TimeStampIndex; // 0x04(0x04)
	uint32_t HeartbeatCount; // 0x08(0x04)
	float AutonomousTimeShiftAmount; // 0x0c(0x04)
	float FixedTimeStepSize; // 0x10(0x04)
};

// ScriptStruct VTSPlugin.VTSTBasicTestTestTrackingData
// Size: 0x28 (Inherited: 0x00)
struct FVTSTBasicTestTestTrackingData {
	bool TestPassed; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Description; // 0x08(0x10)
	struct TArray<struct FVTSTBasicTestTestParticipantTrackingData> ParticipantStates; // 0x18(0x10)
};

// ScriptStruct VTSPlugin.VTSTBasicTestTestParticipantTrackingData
// Size: 0x08 (Inherited: 0x00)
struct FVTSTBasicTestTestParticipantTrackingData {
	float LastLoadedValue; // 0x00(0x04)
	float LastDeltaTime; // 0x04(0x04)
};

// ScriptStruct VTSPlugin.VTSTimeStampDelegate
// Size: 0x18 (Inherited: 0x00)
struct FVTSTimeStampDelegate {
	char pad_0[0x18]; // 0x00(0x18)
};

