// BlueprintGeneratedClass ObservePlayer8ActionTraits.ObservePlayer8ActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UObservePlayer8ActionTraits_C : UActionTraits {
};

