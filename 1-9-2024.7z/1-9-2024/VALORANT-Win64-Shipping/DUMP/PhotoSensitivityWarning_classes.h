// WidgetBlueprintGeneratedClass PhotoSensitivityWarning.PhotoSensitivityWarning_C
// Size: 0x2f0 (Inherited: 0x2e0)
struct UPhotoSensitivityWarning_C : UPhotoSensitivityWarning_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2e0(0x08)
	struct USharedButtonMaster_C* Accept; // 0x2e8(0x08)

	struct FEventReply OnKeyUp(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function PhotoSensitivityWarning.PhotoSensitivityWarning_C.OnKeyUp // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3fa0360
	void BndEvt__Accept_K2Node_ComponentBoundEvent_0_Clicked__DelegateSignature(); // Function PhotoSensitivityWarning.PhotoSensitivityWarning_C.BndEvt__Accept_K2Node_ComponentBoundEvent_0_Clicked__DelegateSignature // (BlueprintEvent) // @ game+0x3fa0360
	void ExecuteUbergraph_PhotoSensitivityWarning(int32_t EntryPoint); // Function PhotoSensitivityWarning.PhotoSensitivityWarning_C.ExecuteUbergraph_PhotoSensitivityWarning // (Final|UbergraphFunction) // @ game+0x3fa0360
};

