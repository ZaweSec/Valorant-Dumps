// BlueprintGeneratedClass UncrouchActionTraits.UncrouchActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UUncrouchActionTraits_C : UActionTraits {
};

