// WidgetBlueprintGeneratedClass SettingsSubsectionBase.SettingsSubsectionBase_C
// Size: 0x2c8 (Inherited: 0x2c8)
struct USettingsSubsectionBase_C : UUserWidget {

	void UpdateCharacterForChildren(struct UPanelWidget* ContainerWidget, struct UCharacterHandle* NewCharacter); // Function SettingsSubsectionBase.SettingsSubsectionBase_C.UpdateCharacterForChildren // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3fa0360
	void AlternateChildColors(struct UPanelWidget* ContainerWidget, bool FirstRowIsLight); // Function SettingsSubsectionBase.SettingsSubsectionBase_C.AlternateChildColors // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3fa0360
};

