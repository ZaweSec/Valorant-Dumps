// BlueprintGeneratedClass Activate_Ability2ActionTraits.Activate_Ability2ActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UActivate_Ability2ActionTraits_C : UActionTraits {
};

