// UserDefinedStruct VOLanguageContainer.VOLanguageContainer
// Size: 0x30 (Inherited: 0x00)
struct FVOLanguageContainer {
	enum class VOLanguage VOLanguage_4_EA52DAD94CCF897BA04CC9823D518F11; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FText DisplayName_7_63ECF89E43D76EC2001C88BCF05F9D67; // 0x08(0x18)
	struct FString Directory_8_6EF64B534F67F770164623A4CA0C980B; // 0x20(0x10)
};

