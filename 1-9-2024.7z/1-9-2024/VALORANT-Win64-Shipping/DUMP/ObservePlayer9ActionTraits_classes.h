// BlueprintGeneratedClass ObservePlayer9ActionTraits.ObservePlayer9ActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UObservePlayer9ActionTraits_C : UActionTraits {
};

