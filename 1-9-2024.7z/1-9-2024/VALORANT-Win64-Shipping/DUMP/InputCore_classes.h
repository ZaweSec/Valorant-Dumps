// Class InputCore.InputCoreTypes
// Size: 0x30 (Inherited: 0x30)
struct UInputCoreTypes : UObject {
};

