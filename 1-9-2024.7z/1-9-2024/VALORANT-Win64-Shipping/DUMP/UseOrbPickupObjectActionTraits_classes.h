// BlueprintGeneratedClass UseOrbPickupObjectActionTraits.UseOrbPickupObjectActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UUseOrbPickupObjectActionTraits_C : UActionTraits {
};

