// BlueprintGeneratedClass UseAgentAbilityObjectActionTraits.UseAgentAbilityObjectActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UUseAgentAbilityObjectActionTraits_C : UActionTraits {
};

