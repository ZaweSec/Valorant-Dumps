// BlueprintGeneratedClass GamepadWeaponSwapTapActionTraits.GamepadWeaponSwapTapActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UGamepadWeaponSwapTapActionTraits_C : UActionTraits {
};

