// BlueprintGeneratedClass GamepadMoveDownActionTraits.GamepadMoveDownActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UGamepadMoveDownActionTraits_C : UActionTraits {
};

