// BlueprintGeneratedClass WallPen_High.WallPen_High_C
// Size: 0x48 (Inherited: 0x48)
struct UWallPen_High_C : UAresWallPenetration {
};

