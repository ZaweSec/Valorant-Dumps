// UserDefinedEnum VOLanguage.VOLanguage
enum class VOLanguage : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	VOLanguage_MAX = 3
};

