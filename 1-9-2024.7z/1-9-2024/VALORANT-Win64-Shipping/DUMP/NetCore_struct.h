// ScriptStruct NetCore.NetAnalyticsDataConfig
// Size: 0x10 (Inherited: 0x00)
struct FNetAnalyticsDataConfig {
	struct FName DataName; // 0x00(0x0c)
	bool bEnabled; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
};

