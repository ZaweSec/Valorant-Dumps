// BlueprintGeneratedClass SprayActionTraits.SprayActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct USprayActionTraits_C : UActionTraits {
};

