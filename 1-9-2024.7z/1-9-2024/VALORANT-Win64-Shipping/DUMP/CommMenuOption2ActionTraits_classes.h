// BlueprintGeneratedClass CommMenuOption2ActionTraits.CommMenuOption2ActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UCommMenuOption2ActionTraits_C : UActionTraits {
};

