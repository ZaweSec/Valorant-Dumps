// BlueprintGeneratedClass OpenCommTree2ActionTraits.OpenCommTree2ActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UOpenCommTree2ActionTraits_C : UActionTraits {
};

