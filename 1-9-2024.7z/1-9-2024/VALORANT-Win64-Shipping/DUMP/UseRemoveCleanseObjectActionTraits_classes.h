// BlueprintGeneratedClass UseRemoveCleanseObjectActionTraits.UseRemoveCleanseObjectActionTraits_C
// Size: 0x128 (Inherited: 0x128)
struct UUseRemoveCleanseObjectActionTraits_C : UActionTraits {
};

