// BlueprintGeneratedClass BP_AresMenuInputData.BP_AresMenuInputData_C
// Size: 0x60 (Inherited: 0x60)
struct UBP_AresMenuInputData_C : UCommonUIInputData {
};

