// BlueprintGeneratedClass DmgSource_World.DmgSource_World_C
// Size: 0x3d8 (Inherited: 0x3d0)
struct ADmgSource_World_C : ADamageSource {
	struct USceneComponent* DefaultSceneRoot; // 0x3d0(0x08)
};

