// BlueprintGeneratedClass Activate_Ability2ActionTraits.Activate_Ability2ActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UActivate_Ability2ActionTraits_C : UActionTraits {
};

