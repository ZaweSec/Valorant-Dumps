// WidgetBlueprintGeneratedClass PickedUpBombTextBanner.PickedUpBombTextBanner_C
// Size: 0x330 (Inherited: 0x320)
struct UPickedUpBombTextBanner_C : UBaseBombNotificationWidget_C {
	struct UImage* Background; // 0x320(0x08)
	struct UTextBlock* Text; // 0x328(0x08)
};

