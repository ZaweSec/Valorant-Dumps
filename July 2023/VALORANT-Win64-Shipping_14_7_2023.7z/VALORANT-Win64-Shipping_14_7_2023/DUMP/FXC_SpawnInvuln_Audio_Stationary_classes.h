// BlueprintGeneratedClass FXC_SpawnInvuln_Audio_Stationary.FXC_SpawnInvuln_Audio_Stationary_C
// Size: 0x550 (Inherited: 0x540)
struct AFXC_SpawnInvuln_Audio_Stationary_C : AEffectContainer {
	struct UComp_FXC_AudioLoop_ContextPerspective_C* Comp_FXC_AudioLoop_ContextPerspective; // 0x540(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x548(0x08)
};

