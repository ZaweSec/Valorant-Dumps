// UserDefinedEnum AnnouncerKillsVOEnum.AnnouncerKillsVOEnum
enum class AnnouncerKillsVOEnum : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator3 = 3,
	NewEnumerator4 = 4,
	NewEnumerator5 = 5,
	NewEnumerator6 = 6,
	NewEnumerator28 = 7,
	NewEnumerator7 = 8,
	NewEnumerator20 = 9,
	NewEnumerator10 = 10,
	NewEnumerator8 = 11,
	NewEnumerator9 = 12,
	NewEnumerator41 = 13,
	NewEnumerator43 = 14,
	NewEnumerator44 = 15,
	NewEnumerator45 = 16,
	NewEnumerator46 = 17,
	NewEnumerator47 = 18,
	NewEnumerator48 = 19,
	AnnouncerKillsVOEnum_MAX = 20
};

