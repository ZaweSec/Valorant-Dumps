// BlueprintGeneratedClass Interface_Widget_KeyboardPrompt.Interface_Widget_KeyboardPrompt_C
// Size: 0x30 (Inherited: 0x30)
struct UInterface_Widget_KeyboardPrompt_C : UInterface {

	void SetKeyText(struct FText InText); // Function Interface_Widget_KeyboardPrompt.Interface_Widget_KeyboardPrompt_C.SetKeyText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3ba6af0
};

