// BlueprintGeneratedClass FXC_Impact_Gun_Light.FXC_Impact_Gun_Light_C
// Size: 0x678 (Inherited: 0x678)
struct AFXC_Impact_Gun_Light_C : AFXC_Impact_Base_C {
};

