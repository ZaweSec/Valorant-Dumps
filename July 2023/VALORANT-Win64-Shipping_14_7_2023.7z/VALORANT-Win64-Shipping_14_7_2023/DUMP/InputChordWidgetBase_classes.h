// WidgetBlueprintGeneratedClass InputChordWidgetBase.InputChordWidgetBase_C
// Size: 0x2d0 (Inherited: 0x2c8)
struct UInputChordWidgetBase_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c8(0x08)

	void SetInputAction(struct FName ActionName); // Function InputChordWidgetBase.InputChordWidgetBase_C.SetInputAction // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3ba6af0
	void PreConstruct(bool IsDesignTime); // Function InputChordWidgetBase.InputChordWidgetBase_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3ba6af0
	void ExecuteUbergraph_InputChordWidgetBase(int32_t EntryPoint); // Function InputChordWidgetBase.InputChordWidgetBase_C.ExecuteUbergraph_InputChordWidgetBase // (Final|UbergraphFunction) // @ game+0x3ba6af0
};

