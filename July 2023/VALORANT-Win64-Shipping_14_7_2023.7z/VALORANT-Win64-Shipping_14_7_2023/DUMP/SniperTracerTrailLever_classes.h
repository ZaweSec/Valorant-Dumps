// BlueprintGeneratedClass SniperTracerTrailLever.SniperTracerTrailLever_C
// Size: 0x638 (Inherited: 0x630)
struct ASniperTracerTrailLever_C : AAresContrailTracer {
	struct UAudioComponent* Audio; // 0x630(0x08)
};

