// BlueprintGeneratedClass FXC_Ascender_Detach.FXC_Ascender_Detach_C
// Size: 0x550 (Inherited: 0x540)
struct AFXC_Ascender_Detach_C : AEffectContainer {
	struct UComp_FXC_AudioBasic_C* Comp_FXC_AudioBasic; // 0x540(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x548(0x08)
};

