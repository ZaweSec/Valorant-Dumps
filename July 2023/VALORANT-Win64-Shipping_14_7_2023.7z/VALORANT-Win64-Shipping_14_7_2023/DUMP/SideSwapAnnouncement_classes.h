// WidgetBlueprintGeneratedClass SideSwapAnnouncement.SideSwapAnnouncement_C
// Size: 0x2d0 (Inherited: 0x2c8)
struct USideSwapAnnouncement_C : UUserWidget {
	struct UWidgetAnimation* Display; // 0x2c8(0x08)
};

