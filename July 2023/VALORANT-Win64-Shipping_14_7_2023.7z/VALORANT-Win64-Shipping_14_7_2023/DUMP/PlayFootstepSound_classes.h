// BlueprintGeneratedClass PlayFootstepSound.PlayFootstepSound_C
// Size: 0x40 (Inherited: 0x40)
struct UPlayFootstepSound_C : UAnimNotify {

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function PlayFootstepSound.PlayFootstepSound_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3ba6af0
};

