// UserDefinedStruct GunSkinVFXMeshInfo.GunSkinVFXMeshInfo
// Size: 0x3c (Inherited: 0x00)
struct FGunSkinVFXMeshInfo {
	struct UStaticMesh* Mesh_2_F4F3A0874905DA0E7987EDB9EA823F16; // 0x00(0x08)
	struct FName AttachSocket_6_5BE0CAE14A9C7BB424A96CB1FE9F5DAF; // 0x08(0x0c)
	char pad_14[0x4]; // 0x14(0x04)
	struct UMaterialInterface* Material_9_2DB1229240DECB0BC013F4AAF45EA539; // 0x18(0x08)
	bool AttachToCosmeticMesh_12_05F00B944C95BB118A2E96B9C0AAB0B7; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
	struct FVector Offset_17_31AB75334559002C947D3CB9D35AAC45; // 0x24(0x0c)
	struct FRotator Rotation_18_3C7AD0914F2FC8A61C88F295F2E435B7; // 0x30(0x0c)
};

