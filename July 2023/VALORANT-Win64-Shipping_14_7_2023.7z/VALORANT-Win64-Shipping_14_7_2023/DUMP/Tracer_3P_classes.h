// BlueprintGeneratedClass Tracer_3P.Tracer_3P_C
// Size: 0x648 (Inherited: 0x648)
struct ATracer_3P_C : ABaseDetachedTracer_C {
};

