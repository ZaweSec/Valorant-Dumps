// BlueprintGeneratedClass BaseObserverPawn.BaseObserverPawn_C
// Size: 0x4b8 (Inherited: 0x4b8)
struct ABaseObserverPawn_C : AObserverPawn {
};

