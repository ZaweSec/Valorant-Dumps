// BlueprintGeneratedClass WallPenGlobals.WallPenGlobals_C
// Size: 0x868 (Inherited: 0x868)
struct UWallPenGlobals_C : UAresWallPenetrationGlobals {
};

