// WidgetBlueprintGeneratedClass HeadShot_Base.HeadShot_Base_C
// Size: 0x2e8 (Inherited: 0x2d0)
struct UHeadShot_Base_C : UHeadShot_Parent_C {
	struct UImage* Image_64; // 0x2d0(0x08)
	struct UImage* Image_117; // 0x2d8(0x08)
	struct UImage* Image_145; // 0x2e0(0x08)
};

