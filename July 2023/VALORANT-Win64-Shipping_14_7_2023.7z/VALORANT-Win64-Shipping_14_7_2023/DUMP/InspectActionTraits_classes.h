// BlueprintGeneratedClass InspectActionTraits.InspectActionTraits_C
// Size: 0xa0 (Inherited: 0xa0)
struct UInspectActionTraits_C : UActionTraits {
};

