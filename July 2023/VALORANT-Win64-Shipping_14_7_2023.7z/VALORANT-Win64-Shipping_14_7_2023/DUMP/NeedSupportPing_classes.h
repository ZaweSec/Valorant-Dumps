// BlueprintGeneratedClass NeedSupportPing.NeedSupportPing_C
// Size: 0x6c8 (Inherited: 0x6c8)
struct ANeedSupportPing_C : ABasePing_C {
};

