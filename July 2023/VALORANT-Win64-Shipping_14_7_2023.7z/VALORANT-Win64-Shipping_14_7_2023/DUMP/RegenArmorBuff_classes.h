// BlueprintGeneratedClass RegenArmorBuff.RegenArmorBuff_C
// Size: 0x990 (Inherited: 0x990)
struct URegenArmorBuff_C : UAresGameplayBuff {
};

