// UserDefinedEnum MatchVOEnum.MatchVOEnum
enum class MatchVOEnum : uint8 {
	NewEnumerator5 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	NewEnumerator7 = 4,
	NewEnumerator8 = 5,
	MatchVOEnum_MAX = 6
};

