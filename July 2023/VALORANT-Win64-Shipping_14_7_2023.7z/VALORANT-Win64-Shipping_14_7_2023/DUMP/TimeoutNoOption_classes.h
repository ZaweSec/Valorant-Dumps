// BlueprintGeneratedClass TimeoutNoOption.TimeoutNoOption_C
// Size: 0x168 (Inherited: 0x160)
struct UTimeoutNoOption_C : UGameplayVoteOptionBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x160(0x08)

	void OnSelected(); // Function TimeoutNoOption.TimeoutNoOption_C.OnSelected // (Event|Public|BlueprintEvent) // @ game+0x3ba6af0
	void ExecuteUbergraph_TimeoutNoOption(int32_t EntryPoint); // Function TimeoutNoOption.TimeoutNoOption_C.ExecuteUbergraph_TimeoutNoOption // (Final|UbergraphFunction|HasDefaults) // @ game+0x3ba6af0
};

