// BlueprintGeneratedClass SniperTracerTrailLever_3P.SniperTracerTrailLever_3P_C
// Size: 0x638 (Inherited: 0x630)
struct ASniperTracerTrailLever_3P_C : AAresContrailTracer {
	struct UAudioComponent* Audio; // 0x630(0x08)
};

