// BlueprintGeneratedClass UltPointOrb.UltPointOrb_C
// Size: 0x4dc (Inherited: 0x4cc)
struct AUltPointOrb_C : ABaseCollectableOrb_C {
	char pad_4CC[0x4]; // 0x4cc(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4d0(0x08)
	int32_t PlayerUltimatePointsReward; // 0x4d8(0x04)

	void GrantOrbEffect(struct AShooterCharacter* ShooterCharacter); // Function UltPointOrb.UltPointOrb_C.GrantOrbEffect // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3ba6af0
	void ExecuteUbergraph_UltPointOrb(int32_t EntryPoint); // Function UltPointOrb.UltPointOrb_C.ExecuteUbergraph_UltPointOrb // (Final|UbergraphFunction) // @ game+0x3ba6af0
};

