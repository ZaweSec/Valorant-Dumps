// BlueprintGeneratedClass LightArmorItem.LightArmorItem_C
// Size: 0x470 (Inherited: 0x461)
struct ALightArmorItem_C : ABasicArmorItem_C {
	char pad_461[0x7]; // 0x461(0x07)
	struct AShooterCharacter* MyCharacter; // 0x468(0x08)
};

