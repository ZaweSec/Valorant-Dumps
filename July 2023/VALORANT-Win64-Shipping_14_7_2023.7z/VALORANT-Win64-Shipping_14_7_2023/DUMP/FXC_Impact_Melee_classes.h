// BlueprintGeneratedClass FXC_Impact_Melee.FXC_Impact_Melee_C
// Size: 0x654 (Inherited: 0x654)
struct AFXC_Impact_Melee_C : AFXC_ImpactMelee_Base_C {
};

