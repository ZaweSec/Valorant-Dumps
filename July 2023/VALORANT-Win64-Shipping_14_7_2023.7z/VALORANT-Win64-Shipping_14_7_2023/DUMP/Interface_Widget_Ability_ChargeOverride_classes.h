// BlueprintGeneratedClass Interface_Widget_Ability_ChargeOverride.Interface_Widget_Ability_ChargeOverride_C
// Size: 0x30 (Inherited: 0x30)
struct UInterface_Widget_Ability_ChargeOverride_C : UInterface {

	void ChargeWidget_GetTempChargesToDisplay(int32_t& TempCharges); // Function Interface_Widget_Ability_ChargeOverride.Interface_Widget_Ability_ChargeOverride_C.ChargeWidget_GetTempChargesToDisplay // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3ba6af0
	void ChargeWidget_GetPermanentChargesToDisplay(int32_t& PermanentChargesToDisplay); // Function Interface_Widget_Ability_ChargeOverride.Interface_Widget_Ability_ChargeOverride_C.ChargeWidget_GetPermanentChargesToDisplay // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3ba6af0
	void ChargeWidget_GetMaxChargesToDisplay(int32_t& MaxCharges); // Function Interface_Widget_Ability_ChargeOverride.Interface_Widget_Ability_ChargeOverride_C.ChargeWidget_GetMaxChargesToDisplay // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3ba6af0
	void ChargeWidget_GetCurrentDisplayCharges(int32_t& CurrentCharges); // Function Interface_Widget_Ability_ChargeOverride.Interface_Widget_Ability_ChargeOverride_C.ChargeWidget_GetCurrentDisplayCharges // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3ba6af0
};

