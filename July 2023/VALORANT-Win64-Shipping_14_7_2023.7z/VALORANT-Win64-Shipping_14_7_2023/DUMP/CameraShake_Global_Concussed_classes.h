// BlueprintGeneratedClass CameraShake_Global_Concussed.CameraShake_Global_Concussed_C
// Size: 0x1e0 (Inherited: 0x1b0)
struct UCameraShake_Global_Concussed_C : UMatineeCameraShake {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1b0(0x08)
	struct UComp_Actor_Concussable_C* ConcussableComponent; // 0x1b8(0x08)
	float BaseYawAmplitude; // 0x1c0(0x04)
	float BaseRollAmplitude; // 0x1c4(0x04)
	float BasePitchAmplitude; // 0x1c8(0x04)
	char pad_1CC[0x4]; // 0x1cc(0x04)
	struct AShooterCharacter* ShooterCharacter; // 0x1d0(0x08)
	float CurrentYawOffset; // 0x1d8(0x04)
	float YawFrequency; // 0x1dc(0x04)

	float GetCurrentConcussLevel(); // Function CameraShake_Global_Concussed.CameraShake_Global_Concussed_C.GetCurrentConcussLevel // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x3ba6af0
	void GetScopeAdjustmentMultiplier(float& Multiplier); // Function CameraShake_Global_Concussed.CameraShake_Global_Concussed_C.GetScopeAdjustmentMultiplier // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x3ba6af0
	void BlueprintUpdateCameraShake(float DeltaTime, float Alpha, struct FMinimalViewInfo& POV, struct FMinimalViewInfo& ModifiedPOV); // Function CameraShake_Global_Concussed.CameraShake_Global_Concussed_C.BlueprintUpdateCameraShake // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3ba6af0
	void ReceivePlayShake(float Scale); // Function CameraShake_Global_Concussed.CameraShake_Global_Concussed_C.ReceivePlayShake // (Event|Public|BlueprintEvent) // @ game+0x3ba6af0
	void ExecuteUbergraph_CameraShake_Global_Concussed(int32_t EntryPoint); // Function CameraShake_Global_Concussed.CameraShake_Global_Concussed_C.ExecuteUbergraph_CameraShake_Global_Concussed // (Final|UbergraphFunction) // @ game+0x3ba6af0
};

