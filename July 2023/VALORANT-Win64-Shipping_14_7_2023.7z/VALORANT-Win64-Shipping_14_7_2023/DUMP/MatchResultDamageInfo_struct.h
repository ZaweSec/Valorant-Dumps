// UserDefinedStruct MatchResultDamageInfo.MatchResultDamageInfo
// Size: 0x21 (Inherited: 0x00)
struct FMatchResultDamageInfo {
	struct FString damageType_6_58B77E7C49F99324A2F0DEA4FB8EE2C6; // 0x00(0x10)
	struct FString damageItem_8_3AED95914326522481988995EE27FE53; // 0x10(0x10)
	bool isSecondaryFireMode_17_574CB32E4559BDDA297C65ACDB1AA14E; // 0x20(0x01)
};

