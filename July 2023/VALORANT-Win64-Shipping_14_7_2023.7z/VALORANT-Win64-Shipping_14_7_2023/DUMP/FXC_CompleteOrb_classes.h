// BlueprintGeneratedClass FXC_CompleteOrb.FXC_CompleteOrb_C
// Size: 0x550 (Inherited: 0x540)
struct AFXC_CompleteOrb_C : AEffectContainer {
	struct UComp_FXC_PlayAnimation_ShooterCharacter_C* Comp_FXC_PlayAnimation_ShooterCharacter; // 0x540(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x548(0x08)
};

